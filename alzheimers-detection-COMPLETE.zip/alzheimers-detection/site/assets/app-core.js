/* Cognisay shared frontend logic. Talks to the FastAPI backend. */
const API_BASE = window.COGNISAY_API_BASE || 'http://localhost:8000';

const Session = {
  get token(){ return sessionStorage.getItem('cog_token'); },
  set token(v){ v ? sessionStorage.setItem('cog_token', v) : sessionStorage.removeItem('cog_token'); },
  get user(){ const r = sessionStorage.getItem('cog_user'); return r ? JSON.parse(r) : null; },
  set user(u){ u ? sessionStorage.setItem('cog_user', JSON.stringify(u)) : sessionStorage.removeItem('cog_user'); },
  clear(){ this.token=null; this.user=null; },
  get isAuthed(){ return !!this.token; },
};

class ApiError extends Error { constructor(status,msg){ super(msg); this.status=status; } }

async function api(path, {method='GET', body=null, auth=true, isForm=false}={}){
  const headers={};
  if(auth && Session.token) headers['Authorization']=`Bearer ${Session.token}`;
  let payload=body;
  if(body && !isForm){ headers['Content-Type']='application/json'; payload=JSON.stringify(body); }
  let res;
  try{ res=await fetch(`${API_BASE}${path}`,{method,headers,body:payload}); }
  catch(e){ throw new ApiError(0,`Can't reach the server. Is the backend running at ${API_BASE}?`); }
  if(res.status===204) return null;
  let data=null; try{ data=await res.json(); }catch{}
  if(!res.ok){
    const d=(data&&data.detail)?data.detail:`Request failed (${res.status})`;
    throw new ApiError(res.status, typeof d==='string'?d:JSON.stringify(d));
  }
  return data;
}

function toast(msg,isErr=false){
  let el=document.querySelector('.toast');
  if(!el){ el=document.createElement('div'); el.className='toast'; document.body.appendChild(el); }
  el.textContent=msg; el.classList.toggle('err',isErr); el.classList.add('show');
  clearTimeout(el._t); el._t=setTimeout(()=>el.classList.remove('show'),3600);
}

function initReveal(){
  const items=document.querySelectorAll('.reveal');
  if(!('IntersectionObserver' in window)){ items.forEach(i=>i.classList.add('in')); return; }
  const io=new IntersectionObserver(es=>es.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }}),{threshold:.12});
  items.forEach(i=>io.observe(i));
}

async function requireAuth(redirect='login.html'){
  if(!Session.isAuthed){ window.location.href=redirect; return null; }
  try{ const me=await api('/api/v1/auth/me'); Session.user=me; return me; }
  catch(e){ Session.clear(); window.location.href=redirect; return null; }
}

function renderNavAuth(){
  const slot=document.querySelector('[data-nav-auth]');
  if(!slot) return;
  slot.innerHTML = Session.isAuthed
    ? `<a href="dashboard.html" class="btn btn-primary">Dashboard</a>`
    : `<a href="login.html" class="always" style="margin-right:4px;">Sign in</a><a href="signup.html" class="btn btn-primary">Get started</a>`;
}

document.addEventListener('DOMContentLoaded',()=>{ initReveal(); renderNavAuth(); });
