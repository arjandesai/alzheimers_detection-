/* ============================================================
   Bushido, shared frontend logic
   Talks to the FastAPI backend. Token is kept in memory + a
   session cookie fallback is NOT used; we use sessionStorage so
   a closed tab clears auth. (localStorage would persist a bearer
   token to disk, a worse posture for a health-adjacent app.)
   ============================================================ */

const API_BASE = window.BUSHIDO_API_BASE || 'http://localhost:8000';

const Session = {
  get token() { return sessionStorage.getItem('bushido_token'); },
  set token(v) { v ? sessionStorage.setItem('bushido_token', v) : sessionStorage.removeItem('bushido_token'); },
  get user() {
    const raw = sessionStorage.getItem('bushido_user');
    return raw ? JSON.parse(raw) : null;
  },
  set user(u) { u ? sessionStorage.setItem('bushido_user', JSON.stringify(u)) : sessionStorage.removeItem('bushido_user'); },
  clear() { this.token = null; this.user = null; },
  get isAuthed() { return !!this.token; },
};

async function api(path, { method = 'GET', body = null, auth = true, isForm = false } = {}) {
  const headers = {};
  if (auth && Session.token) headers['Authorization'] = `Bearer ${Session.token}`;
  let payload = body;
  if (body && !isForm) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }

  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, { method, headers, body: payload });
  } catch (networkErr) {
    // The backend isn't reachable. Be honest about it rather than failing silently.
    throw new ApiError(0, 'Cannot reach the server. Is the backend running at ' + API_BASE + '?');
  }

  if (res.status === 204) return null;
  let data = null;
  try { data = await res.json(); } catch { /* some endpoints return no body */ }

  if (!res.ok) {
    const detail = (data && data.detail) ? data.detail : `Request failed (${res.status})`;
    throw new ApiError(res.status, typeof detail === 'string' ? detail : JSON.stringify(detail));
  }
  return data;
}

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

/* ---- Toast ---- */
function toast(message, isError = false) {
  let el = document.querySelector('.toast');
  if (!el) { el = document.createElement('div'); el.className = 'toast'; document.body.appendChild(el); }
  el.textContent = message;
  el.classList.toggle('err', isError);
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 3600);
}

/* ---- Moving ink-wash background ---- */
function initMist() {
  if (document.querySelector('.mist-stage')) return;
  const stage = document.createElement('div');
  stage.className = 'mist-stage';
  stage.innerHTML = `
    <div class="mist-layer a"></div>
    <div class="mist-layer b"></div>
    <div class="mist-layer c"></div>`;
  document.body.prepend(stage);

  const grain = document.createElement('div');
  grain.className = 'grain';
  document.body.prepend(grain);

  // If a looping wallpaper video is provided, drop it in behind the mist.
  // Point BUSHIDO_WALLPAPER at your own file (e.g. 'assets/samurai.mp4').
  if (window.BUSHIDO_WALLPAPER) {
    const v = document.createElement('video');
    v.src = window.BUSHIDO_WALLPAPER;
    v.autoplay = true; v.loop = true; v.muted = true; v.playsInline = true;
    stage.prepend(v);
  }
}

/* ---- Scroll reveal ---- */
function initReveal() {
  const items = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window)) { items.forEach(i => i.classList.add('in')); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.12 });
  items.forEach(i => io.observe(i));
}

/* ---- Nav auth-state swap ---- */
function renderNavAuth() {
  const slot = document.querySelector('[data-nav-auth]');
  if (!slot) return;
  if (Session.isAuthed) {
    slot.innerHTML = `<a href="dashboard.html" class="btn btn-ink">The Dojo</a>`;
  } else {
    slot.innerHTML = `<a href="login.html" class="btn btn-outline">Enter</a>`;
  }
}

/* ---- Require auth / subscription helpers for gated pages ---- */
async function requireAuth(redirect = 'login.html') {
  if (!Session.isAuthed) { window.location.href = redirect; return null; }
  try {
    const me = await api('/api/v1/auth/me');
    Session.user = me;
    return me;
  } catch (e) {
    Session.clear();
    window.location.href = redirect;
    return null;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initMist();
  initReveal();
  renderNavAuth();
});
