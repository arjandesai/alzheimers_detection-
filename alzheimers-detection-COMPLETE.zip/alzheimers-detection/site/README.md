# Bushido, frontend

The samurai-skinned frontend for the digital biomarker platform. Five
static pages (`index`, `login`, `signup`, `pricing`, `dashboard`) that
talk to the FastAPI backend in `src/alzheimers_detection`.

## Running it

The pages are static HTML/CSS/JS, no build step. But most of them need
the backend running to do anything real (log in, pay, upload), so:

```bash
# 1. Start the backend (from the repo root)
pip install -e ".[dev,speech]"      # add ,ml only if training
export ALZDX_ENCRYPTION_KEY=$(python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
export ALZDX_JWT_SECRET_KEY=$(python -c "import secrets; print(secrets.token_urlsafe(48))")
uvicorn alzheimers_detection.api.main:app --reload      # serves on :8000

# 2. Serve the site on :8080 (any static server works)
cd site
python -m http.server 8080
# open http://localhost:8080
```

The frontend calls the API at `http://localhost:8000` by default. To point
it elsewhere, set a global before `app.js` loads, e.g. in each page's
`<head>`:

```html
<script>window.BUSHIDO_API_BASE = 'https://api.your-domain.com';</script>
```

`:8080` is already in the backend's CORS allow-list
(`core/config.py::api_cors_origins`) and in the Stripe redirect URLs
(`ALZDX_BILLING_SUCCESS_URL` / `_CANCEL_URL`).

## The moving wallpaper

The background is a procedural drifting ink-mist effect (pure CSS, in
`assets/style.css`) that works with no video at all. To drop in your own
looping video wallpaper behind the mist, put the file in `assets/` and
set a global before `app.js` runs:

```html
<script>window.BUSHIDO_WALLPAPER = 'assets/samurai.mp4';</script>
```

The video is rendered muted, looping, `object-fit: cover`, at reduced
opacity with a multiply blend so the ink-mist and paper grain still read
over it. Provide an MP4 (H.264) for the widest browser support.

## What needs the backend to actually work

| Feature | Works standalone? | Needs |
|---|---|---|
| Visual design, mist, transitions | Yes | nothing |
| Register / login | No | backend running |
| 2FA (TOTP) | No | backend + an authenticator app (Google Authenticator, Authy, 1Password, etc.) |
| Payment wall | No | backend + real Stripe keys (see `docs/BILLING.md`) |
| Image / video upload | No | backend + an active subscription on the account |

The payment wall is genuinely enforced server-side: `/api/v1/uploads/*`
and the speech analysis endpoint all sit behind
`require_active_subscription` (returns HTTP 402 without an active
subscription), and subscription state is only ever set by a
signature-verified Stripe webhook, never by the browser. So the paywall
cannot be bypassed by editing the frontend, it's the backend that says no.

## 2FA note

Two-factor uses TOTP (authenticator-app codes), not SMS, so it needs no
paid SMS provider and works offline once set up. The QR code on the
dashboard's "Second seal" flow is rendered via a public QR image service
purely for convenience; the `otpauth://` provisioning URI returned by the
backend is the source of truth, swap in a self-hosted QR generator if you
don't want that third-party image call. The TOTP secret is stored
encrypted at rest; recovery codes are stored only as bcrypt hashes.
