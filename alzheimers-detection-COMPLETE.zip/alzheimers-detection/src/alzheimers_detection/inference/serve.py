"""Serve the two trained models (speech + handwriting) for the app.

This loads the .joblib files produced by the training/save scripts and
runs predictions on incoming samples. It is deliberately conservative:

- It NEVER outputs a diagnosis. It outputs a probability-like score and a
  band ("typical" / "some markers outside typical range"), always wrapped
  with the not-a-diagnosis language from core.disclaimers.
- It refuses to predict when the input can't support the model. For
  handwriting especially, a browser canvas may only capture a subset of
  DARWIN's tablet features; if too many are missing, we return
  "insufficient_signal" rather than imputing zeros and pretending the
  result is meaningful.
- Fusion of the two modalities is a simple, transparent average of the
  two scores, only computed when BOTH are present. We do not invent a
  fused score from one modality.

Models are loaded lazily and cached, so the first request pays the load
cost and the rest are fast.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import numpy as np

from alzheimers_detection.core import disclaimers
from alzheimers_detection.core.config import get_settings


class ModelNotAvailable(RuntimeError):
    """Raised when a model file isn't present. The app surfaces this as a
    clear 'analysis is not configured on this server' message rather than
    a 500, so it's obvious the models just need to be dropped in."""


@dataclass
class ModelBundle:
    model: object
    meta: dict
    feature_order: list[str] | None  # for handwriting: the exact 450 names; for speech: None (positional)


def _models_dir() -> Path:
    # Configurable so deployment can point at wherever the .joblib files
    # live. Defaults to a 'models' folder at the project data dir.
    settings = get_settings()
    return Path(getattr(settings, "models_dir", settings.data_dir / "models"))


@lru_cache(maxsize=4)
def _load_bundle(modality: str) -> ModelBundle:
    import joblib

    mdir = _models_dir()
    model_path = mdir / f"{modality}_model.joblib"
    meta_path = mdir / f"{modality}_model_meta.json"
    if not model_path.exists():
        raise ModelNotAvailable(
            f"{modality} model not found at {model_path}. Train it and place the "
            f".joblib there (see docs). The app runs without it, that modality is "
            f"just unavailable until the file is present."
        )
    model = joblib.load(model_path)
    meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
    feature_order = meta.get("features") if isinstance(meta.get("features"), list) else None
    return ModelBundle(model=model, meta=meta, feature_order=feature_order)


def _score_to_band(score: float) -> str:
    """Map a probability-like score to a calm, non-alarmist band. Thresholds
    are intentionally wide; this is screening support, not a decision rule."""
    if score < 0.34:
        return "typical"
    if score < 0.66:
        return "some_markers"
    return "several_markers"


_BAND_LANGUAGE = {
    "typical": "The markers in this sample look broadly consistent with the "
               "cognitively-unimpaired reference group in the research this tool draws on.",
    "some_markers": "Some markers in this sample fall outside the typical reference "
                    "range. This is common and does not by itself indicate impairment.",
    "several_markers": "Several markers fall outside the typical reference range. "
                       "Consider discussing a full cognitive evaluation with a doctor.",
    "insufficient_signal": "Not enough usable signal was captured to produce a reliable reading.",
}


@dataclass
class PredictionResult:
    modality: str
    band: str
    score: float | None
    explanation: str
    disclaimer: str
    available: bool = True


def predict_speech(gemaps_features: dict[str, float]) -> PredictionResult:
    """Run the speech model on a dict of GeMAPS features (as produced from
    a recording). Feature order matches training: GeMAPS keys sorted
    alphabetically."""
    bundle = _load_bundle("speech")

    if not gemaps_features or len(gemaps_features) < 60:
        return PredictionResult(
            modality="speech", band="insufficient_signal", score=None,
            explanation=_BAND_LANGUAGE["insufficient_signal"],
            disclaimer=disclaimers.RESULT_FOOTER,
        )

    keys = sorted(gemaps_features.keys())
    x = np.array([[float(gemaps_features[k]) for k in keys]])
    score = float(bundle.model.predict_proba(x)[0, 1])
    band = _score_to_band(score)
    return PredictionResult(
        modality="speech", band=band, score=score,
        explanation=_BAND_LANGUAGE[band],
        disclaimer=disclaimers.RESULT_FOOTER,
    )


# For handwriting: how many of the model's expected features must be
# present (non-missing) before we're willing to predict at all. Below
# this, a browser canvas simply didn't capture enough of what DARWIN's
# tablet measured, and predicting would be dishonest.
_HANDWRITING_MIN_COVERAGE = 0.6


def predict_handwriting(features: dict[str, float]) -> PredictionResult:
    """Run the handwriting model. `features` maps DARWIN feature names to
    values captured/derived from the writing canvas. Missing features are
    allowed up to a point; past that we refuse rather than impute."""
    bundle = _load_bundle("handwriting")
    order = bundle.feature_order
    if not order:
        raise ModelNotAvailable("handwriting model metadata is missing its feature order.")

    present = [f for f in order if f in features and features[f] is not None]
    coverage = len(present) / len(order)
    if coverage < _HANDWRITING_MIN_COVERAGE:
        return PredictionResult(
            modality="handwriting", band="insufficient_signal", score=None,
            explanation=(
                f"{_BAND_LANGUAGE['insufficient_signal']} "
                f"(This input provided {len(present)} of {len(order)} handwriting "
                f"measurements; a stylus that records pressure and pen-in-air motion "
                f"is needed for a full reading.)"
            ),
            disclaimer=disclaimers.RESULT_FOOTER,
        )

    # Fill only the minority of genuinely-missing features with the training
    # median (carried in meta if available, else 0 as a last resort). This
    # is acceptable ONLY because coverage cleared the threshold above.
    medians = bundle.meta.get("feature_medians", {})
    x = np.array([[float(features.get(f, medians.get(f, 0.0))) for f in order]])
    score = float(bundle.model.predict_proba(x)[0, 1])
    band = _score_to_band(score)
    return PredictionResult(
        modality="handwriting", band=band, score=score,
        explanation=_BAND_LANGUAGE[band],
        disclaimer=disclaimers.RESULT_FOOTER,
    )


def fuse(speech: PredictionResult | None, handwriting: PredictionResult | None) -> dict:
    """Combine two modality results into a transparent summary. Only
    produces a fused score when BOTH modalities gave a usable score, a
    plain average, with the reasoning shown. Never fabricates a combined
    score from a single modality."""
    usable = [r for r in (speech, handwriting) if r and r.score is not None]
    out: dict = {
        "speech": _result_dict(speech),
        "handwriting": _result_dict(handwriting),
        "combined": None,
        "disclaimer": disclaimers.RESULT_FOOTER,
    }
    if len(usable) == 2:
        fused_score = float(np.mean([r.score for r in usable]))
        band = _score_to_band(fused_score)
        out["combined"] = {
            "score": fused_score,
            "band": band,
            "explanation": (
                "Combined reading (a simple average of the speech and handwriting "
                "markers). " + _BAND_LANGUAGE[band]
            ),
            "method": "mean of two modality scores",
        }
    elif len(usable) == 1:
        out["combined"] = {
            "score": None,
            "band": None,
            "explanation": "A combined reading needs both a speech and a handwriting "
                           "sample. Only one was usable here, so each is shown on its own.",
        }
    return out


def _result_dict(r: PredictionResult | None) -> dict | None:
    if r is None:
        return None
    return {
        "modality": r.modality,
        "band": r.band,
        "score": r.score,
        "explanation": r.explanation,
        "available": r.available,
    }
