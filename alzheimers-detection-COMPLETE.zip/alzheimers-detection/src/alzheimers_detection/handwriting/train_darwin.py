"""Train and honestly evaluate an Alzheimer's classifier on DARWIN handwriting features.

Two things are reported, deliberately:

1. A single train/test split result (held-out ~20%), training an MLP for
   the requested number of epochs (default 20). This is the "runs in a
   notebook, shows a number" result.

2. A stratified k-fold cross-validated accuracy (default 5-fold). On a
   dataset this small (174 participants), a single random split is high
   variance, one lucky/unlucky split can swing accuracy by 10+ points.
   Cross-validation gives a far more honest estimate of true performance,
   and it's what the DARWIN benchmark papers themselves report. Trust the
   CV number over the single-split number.

Honesty guardrail baked into the output: DARWIN's published benchmarks
(Cilia et al. 2022) land roughly in the mid-80s to ~90% accuracy with the
best models. If this script ever prints an accuracy above ~95%, that is a
signal to suspect a bug (e.g. label leakage, or the ID/class columns
accidentally included as features), NOT a cause for celebration. The
field's honest ceiling for AD detection is well below the 99% seen on
leaky Kaggle datasets.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--csv", type=Path, required=True, help="Path to DARWIN.csv")
    p.add_argument("--epochs", type=int, default=20, help="MLP training epochs for the single-split model (default 20)")
    p.add_argument("--folds", type=int, default=5, help="Cross-validation folds (default 5)")
    p.add_argument("--test-fraction", type=float, default=0.2)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--output-dir", type=Path, default=Path("./runs/darwin"))
    return p


def run(args: argparse.Namespace) -> dict:
    from sklearn.metrics import (
        accuracy_score,
        confusion_matrix,
        f1_score,
        precision_score,
        recall_score,
        roc_auc_score,
    )
    from sklearn.model_selection import StratifiedKFold
    from sklearn.neural_network import MLPClassifier
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler

    from alzheimers_detection.handwriting.darwin_dataset import (
        load_darwin_csv,
        stratified_participant_split,
    )

    data = load_darwin_csv(args.csv)
    n_ad = int((data.y == 1).sum())
    n_hc = int((data.y == 0).sum())
    print(f"[data] DARWIN loaded: {len(data.y)} participants ({n_ad} AD / {n_hc} healthy), "
          f"{data.X.shape[1]} features")

    def make_model() -> object:
        # StandardScaler is essential: DARWIN features span wildly
        # different units (milliseconds, pressure units, tremor indices).
        # A one-hidden-layer MLP suits a 174-sample, 450-feature problem;
        # anything deeper overfits immediately. max_iter honors the
        # requested epoch budget.
        return make_pipeline(
            StandardScaler(),
            MLPClassifier(
                hidden_layer_sizes=(64,),
                max_iter=args.epochs,
                alpha=1e-2,          # L2 regularization, important on a small/wide dataset
                random_state=args.seed,
                early_stopping=False,  # run the full requested epoch count
            ),
        )

    # --- 1. Single held-out split ---
    train_idx, test_idx = stratified_participant_split(data, test_fraction=args.test_fraction, seed=args.seed)
    model = make_model()
    # MLPClassifier warns if it hasn't converged in max_iter epochs; that
    # is expected and fine here (we deliberately cap epochs), so silence
    # just that warning rather than hiding real ones.
    import warnings
    from sklearn.exceptions import ConvergenceWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", ConvergenceWarning)
        model.fit(data.X[train_idx], data.y[train_idx])

    y_pred = model.predict(data.X[test_idx])
    y_prob = model.predict_proba(data.X[test_idx])[:, 1]
    y_true = data.y[test_idx]

    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = (int(x) for x in cm.ravel())
    single_split = {
        "epochs": args.epochs,
        "n_train": len(train_idx),
        "n_test": len(test_idx),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "auc": float(roc_auc_score(y_true, y_prob)),
        "confusion_matrix": {"tn": tn, "fp": fp, "fn": fn, "tp": tp},
    }
    print(f"\n[single split, {args.epochs} epochs] "
          f"accuracy={single_split['accuracy']:.3f} f1={single_split['f1']:.3f} "
          f"auc={single_split['auc']:.3f}  (n_test={len(test_idx)})")
    print(f"[single split] confusion matrix: {single_split['confusion_matrix']}")

    # --- 2. Cross-validation (the number to trust) ---
    skf = StratifiedKFold(n_splits=args.folds, shuffle=True, random_state=args.seed)
    fold_acc, fold_f1, fold_auc = [], [], []
    for fold, (tr, te) in enumerate(skf.split(data.X, data.y), start=1):
        m = make_model()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ConvergenceWarning)
            m.fit(data.X[tr], data.y[tr])
        pred = m.predict(data.X[te])
        prob = m.predict_proba(data.X[te])[:, 1]
        fold_acc.append(accuracy_score(data.y[te], pred))
        fold_f1.append(f1_score(data.y[te], pred, zero_division=0))
        fold_auc.append(roc_auc_score(data.y[te], prob))

    cv = {
        "folds": args.folds,
        "accuracy_mean": float(np.mean(fold_acc)),
        "accuracy_std": float(np.std(fold_acc)),
        "f1_mean": float(np.mean(fold_f1)),
        "auc_mean": float(np.mean(fold_auc)),
        "per_fold_accuracy": [float(a) for a in fold_acc],
    }
    print(f"\n[{args.folds}-fold CV, TRUST THIS] "
          f"accuracy = {cv['accuracy_mean']:.3f} +/- {cv['accuracy_std']:.3f}  "
          f"f1 = {cv['f1_mean']:.3f}  auc = {cv['auc_mean']:.3f}")

    # --- Honesty guardrail ---
    warning = None
    if cv["accuracy_mean"] > 0.95:
        warning = (
            "CV accuracy exceeds 0.95, which is ABOVE DARWIN's published benchmark range. "
            "Suspect a bug (label leakage, ID/class column leaking into features) before "
            "trusting this. The honest ceiling for AD detection is well below 99%."
        )
        print(f"\n[WARNING] {warning}")
    else:
        print(f"\n[sanity] CV accuracy is within the plausible published range for DARWIN "
              f"(~0.80-0.90). This is what an honest result looks like.")

    summary = {
        "dataset": "DARWIN",
        "n_participants": len(data.y),
        "n_ad": n_ad,
        "n_healthy": n_hc,
        "n_features": int(data.X.shape[1]),
        "single_split": single_split,
        "cross_validation": cv,
        "honesty_warning": warning,
        "note": "Tablet-dynamics features only. Not applicable to handwriting photos. "
                "Not a validated diagnostic. Research use only.",
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / "darwin_results.json").open("w") as f:
        json.dump(summary, f, indent=2)
    print(f"\n[done] wrote {args.output_dir / 'darwin_results.json'}")
    return summary


def main(argv: list[str] | None = None) -> int:
    args = _build_arg_parser().parse_args(argv)
    run(args)
    return 0


if __name__ == "__main__":
    import sys

    sys.exit(main())
