"""Loader for the DARWIN online-handwriting dataset.

DARWIN (Cilia, De Gregorio, De Stefano, Fontanella, Marcelli, Parziale,
"Diagnosing Alzheimer's disease from online handwriting: A novel dataset
and performance benchmarking", Engineering Applications of Artificial
Intelligence, Vol. 111, 2022) contains 174 participants (89 Alzheimer's
patients, 85 healthy controls). Each participant performed 25 handwriting
tasks on a digitizing tablet; 18 features were extracted per task, giving
450 feature columns plus an ID and a class label ('P' patient / 'H'
healthy).

CRITICAL, WHAT THIS DATA IS AND IS NOT:
These are TABLET-DERIVED DYNAMIC features, air_time (pen-in-air
duration), pressure, gmrt (generalized mean relative tremor), on-paper vs
in-air velocity, and so on. They are NOT images. A model trained on this
CANNOT be applied to a photograph of handwriting: a photo has no
pressure, no timing, no in-air trajectory. Any "upload a handwriting
photo and compare" feature is out of scope for this dataset and this
module does not pretend otherwise. Using a trained DARWIN model on a new
person requires reproducing the same tablet acquisition protocol.

This module ships NO data. The DARWIN CSV is obtained by the user
(publicly available via the dataset's authors / UCI-style distribution)
and pointed at via a path. One row per participant with a unique ID means
participant-level splitting is trivial and leakage-free, which is part of
why DARWIN's honest published benchmarks sit around 85-90% rather than
the inflated ~99% seen on augmentation-leaky image datasets.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


class DarwinLoadError(ValueError):
    pass


@dataclass
class DarwinData:
    X: np.ndarray            # (n_participants, 450) float feature matrix
    y: np.ndarray            # (n_participants,) int labels: 1 = patient (AD), 0 = healthy
    participant_ids: list[str]
    feature_names: list[str]


def load_darwin_csv(csv_path: Path) -> DarwinData:
    """Parse the DARWIN.csv file into feature matrix + labels.

    Uses only the stdlib csv module so this loader has no hard pandas
    dependency (the training script uses sklearn, but the loader stays
    lightweight and independently testable).
    """
    import csv

    csv_path = Path(csv_path)
    if not csv_path.exists():
        raise DarwinLoadError(
            f"DARWIN.csv not found at {csv_path}. This dataset is not shipped with the repo; "
            "obtain it from the dataset authors (Fontanella et al.) and pass its path. "
            "See docs/HANDWRITING.md."
        )

    with csv_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))

    if len(rows) < 2:
        raise DarwinLoadError("DARWIN.csv appears empty or headerless.")

    header = rows[0]
    if header[0] != "ID" or header[-1] != "class":
        raise DarwinLoadError(
            f"Unexpected DARWIN header. Expected first col 'ID' and last col 'class', "
            f"got first={header[0]!r} last={header[-1]!r}."
        )

    feature_names = header[1:-1]
    ids: list[str] = []
    X_rows: list[list[float]] = []
    y: list[int] = []

    for i, row in enumerate(rows[1:], start=2):
        if len(row) != len(header):
            raise DarwinLoadError(f"Row {i} has {len(row)} columns, expected {len(header)}.")
        ids.append(row[0])
        label = row[-1].strip().upper()
        if label not in ("P", "H"):
            raise DarwinLoadError(f"Row {i}: class must be 'P' or 'H', got {row[-1]!r}.")
        y.append(1 if label == "P" else 0)  # 1 = Alzheimer's patient, 0 = healthy
        try:
            X_rows.append([float(v) for v in row[1:-1]])
        except ValueError as e:
            raise DarwinLoadError(f"Row {i}: non-numeric feature value ({e}).") from e

    if len(set(ids)) != len(ids):
        raise DarwinLoadError("Duplicate participant IDs found; DARWIN should have one unique row per participant.")

    return DarwinData(
        X=np.array(X_rows, dtype=np.float64),
        y=np.array(y, dtype=np.int64),
        participant_ids=ids,
        feature_names=feature_names,
    )


def stratified_participant_split(
    data: DarwinData, test_fraction: float = 0.2, seed: int = 42
) -> tuple[np.ndarray, np.ndarray]:
    """Return (train_indices, test_indices), stratified by class.

    DARWIN is one-row-per-participant, so a row-level split IS already a
    participant-level split, there is no session leakage to worry about
    the way there is with repeated recordings or augmented images. We
    still stratify by class so train and test keep the ~51/49 patient/
    healthy balance.
    """
    rng = np.random.default_rng(seed)
    train_idx: list[int] = []
    test_idx: list[int] = []
    for cls in (0, 1):
        idx = np.where(data.y == cls)[0]
        rng.shuffle(idx)
        n_test = max(1, round(len(idx) * test_fraction))
        test_idx.extend(idx[:n_test].tolist())
        train_idx.extend(idx[n_test:].tolist())
    return np.array(sorted(train_idx)), np.array(sorted(test_idx))
