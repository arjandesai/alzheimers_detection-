"""Evaluate a trained checkpoint against a held-out manifest (e.g. the
official ADReSS test set, which is distributed separately from train).

USAGE:
    python -m alzheimers_detection.ml.evaluate \\
        --checkpoint ./runs/adress-fusion-v1/best_model.pt \\
        --manifest /path/to/adress_test_manifest.csv \\
        --cache-dir ./feature_cache_test

Prints accuracy/precision/recall/F1/AUC and a confusion matrix. Writes
the same to `<checkpoint_dir>/test_metrics.json` alongside the checkpoint.
Does not modify the checkpoint or retrain anything.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--checkpoint", type=Path, required=True)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--cache-dir", type=Path, default=Path("./feature_cache_eval"))
    p.add_argument("--device", type=str, default="cpu")
    return p


def evaluate(args: argparse.Namespace) -> dict:
    import torch

    from alzheimers_detection.ml.dataset import build_feature_cache, load_feature_matrix, load_manifest
    from alzheimers_detection.ml.model import build_model
    from alzheimers_detection.ml.train import _compute_metrics

    checkpoint = torch.load(args.checkpoint, map_location=args.device, weights_only=False)
    use_egemaps = checkpoint["use_egemaps"]
    use_clap = checkpoint["use_clap"]

    rows = load_manifest(args.manifest)
    build_feature_cache(rows, args.cache_dir, use_egemaps=use_egemaps, use_clap=use_clap, clap_device=args.device)
    X, y, ids = load_feature_matrix(rows, args.cache_dir, use_egemaps, use_clap)

    mean, std = checkpoint["feature_mean"], checkpoint["feature_std"]
    X = (X - mean) / std

    model = build_model(input_dim=checkpoint["input_dim"]).to(args.device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    with torch.inference_mode():
        logits = model(torch.from_numpy(X).to(args.device))
        probs = torch.softmax(logits, dim=1)[:, 1].cpu().tolist()
        preds = torch.argmax(logits, dim=1).cpu().tolist()

    metrics = _compute_metrics(avg_loss=float("nan"), labels=y.tolist(), preds=preds, probs=probs)
    del metrics["loss"]  # not meaningful without a loss function context here

    confusion = _confusion_matrix(y.tolist(), preds)
    result = {
        "n_samples": len(rows),
        "metrics": metrics,
        "confusion_matrix": confusion,  # {"tn":.., "fp":.., "fn":.., "tp":..}
        "checkpoint": str(args.checkpoint),
        "manifest": str(args.manifest),
    }

    print(f"[eval] n={len(rows)} acc={metrics['accuracy']:.3f} f1={metrics['f1']:.3f} "
          f"auc={metrics.get('auc', float('nan')):.3f}")
    print(f"[eval] confusion matrix: {confusion}")

    out_path = args.checkpoint.parent / "test_metrics.json"
    with out_path.open("w") as f:
        json.dump(result, f, indent=2, default=float)
    print(f"[eval] wrote {out_path}")

    return result


def _confusion_matrix(labels: list[int], preds: list[int]) -> dict:
    tn = sum(1 for l, p in zip(labels, preds) if l == 0 and p == 0)
    fp = sum(1 for l, p in zip(labels, preds) if l == 0 and p == 1)
    fn = sum(1 for l, p in zip(labels, preds) if l == 1 and p == 0)
    tp = sum(1 for l, p in zip(labels, preds) if l == 1 and p == 1)
    return {"tn": tn, "fp": fp, "fn": fn, "tp": tp}


def main(argv: list[str] | None = None) -> int:
    args = _build_arg_parser().parse_args(argv)
    evaluate(args)
    return 0


if __name__ == "__main__":
    import sys

    sys.exit(main())
