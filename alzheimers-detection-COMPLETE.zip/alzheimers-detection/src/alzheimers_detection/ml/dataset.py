"""Dataset loading for the trainable AD/control classifier.

Expects a "manifest" CSV the user builds themselves from data they have
approved local access to (ADReSS, ADReSSo, or the extended DementiaBank
Pitt Corpus). This module does NOT ship, download, or reference any
gated file paths -- see docs/DATASETS.md and docs/TRAINING.md.

Manifest format (CSV, header required):
    participant_id,file_path,label
    S001,/abs/or/relative/path/to/S001.wav,0
    S002,/abs/or/relative/path/to/S002.wav,1

`label` is 0 for control / healthy, 1 for AD, matching how ADReSS itself
is distributed (`cc` = control, `cd` = cognitive decline/dementia in the
original file naming).

Features are cached to disk as .npz per file (keyed by manifest row hash)
so re-running training after a code change doesn't re-run CLAP/openSMILE
extraction over the whole dataset every time -- extraction is the slow
part, not training a small MLP for 20 epochs.
"""

from __future__ import annotations

import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path

import numpy as np


class ManifestError(ValueError):
    pass


@dataclass
class ManifestRow:
    participant_id: str
    file_path: Path
    label: int


def load_manifest(manifest_path: Path) -> list[ManifestRow]:
    manifest_path = Path(manifest_path)
    if not manifest_path.exists():
        raise ManifestError(
            f"Manifest not found: {manifest_path}. This file is not shipped with the "
            "repo -- build it yourself from your own approved dataset access. "
            "See docs/TRAINING.md for the exact format."
        )

    rows: list[ManifestRow] = []
    with manifest_path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        required = {"participant_id", "file_path", "label"}
        if reader.fieldnames is None or not required.issubset(set(reader.fieldnames)):
            raise ManifestError(f"Manifest must have columns {sorted(required)}, got {reader.fieldnames}")
        for i, raw in enumerate(reader, start=2):  # start=2: line 1 is the header
            try:
                label = int(raw["label"])
            except ValueError as e:
                raise ManifestError(f"Row {i}: label must be 0 or 1, got {raw['label']!r}") from e
            if label not in (0, 1):
                raise ManifestError(f"Row {i}: label must be 0 or 1, got {label}")
            file_path = Path(raw["file_path"])
            if not file_path.is_absolute():
                file_path = manifest_path.parent / file_path
            rows.append(ManifestRow(participant_id=raw["participant_id"], file_path=file_path, label=label))

    if not rows:
        raise ManifestError(f"Manifest {manifest_path} has a header but no data rows.")
    return rows


def _cache_key(row: ManifestRow) -> str:
    return hashlib.sha1(f"{row.participant_id}:{row.file_path}".encode()).hexdigest()[:16]


def build_feature_cache(
    rows: list[ManifestRow],
    cache_dir: Path,
    use_egemaps: bool = True,
    use_clap: bool = True,
    clap_device: str = "cpu",
) -> None:
    """Extract and cache features for every row that isn't already cached.
    Safe to interrupt and re-run -- already-cached rows are skipped.
    """
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)

    clap_embedder = None
    if use_clap:
        from alzheimers_detection.speech.clap_features import ClapEmbedder

        clap_embedder = ClapEmbedder(device=clap_device)

    for row in rows:
        cache_path = cache_dir / f"{_cache_key(row)}.npz"
        if cache_path.exists():
            continue
        if not row.file_path.exists():
            raise ManifestError(f"Audio file listed in manifest not found: {row.file_path}")

        feats = {}
        if use_egemaps:
            from alzheimers_detection.speech.opensmile_features import extract_egemaps

            feats["egemaps"] = extract_egemaps(row.file_path)
        if use_clap:
            feats["clap"] = clap_embedder.embed_file(row.file_path)

        np.savez(cache_path, label=row.label, participant_id=row.participant_id, **feats)


def load_feature_matrix(
    rows: list[ManifestRow],
    cache_dir: Path,
    use_egemaps: bool = True,
    use_clap: bool = True,
) -> tuple[np.ndarray, np.ndarray, list[str]]:
    """Assemble (X, y, participant_ids) from cached per-file .npz feature
    files written by build_feature_cache. Concatenates egemaps + clap
    when both are requested, in that fixed order, so the feature vector
    layout is stable across training and inference.
    """
    cache_dir = Path(cache_dir)
    X, y, ids = [], [], []
    for row in rows:
        cache_path = cache_dir / f"{_cache_key(row)}.npz"
        if not cache_path.exists():
            raise ManifestError(
                f"No cached features for {row.participant_id} ({row.file_path}). "
                "Run build_feature_cache() first."
            )
        data = np.load(cache_path)
        parts = []
        if use_egemaps:
            parts.append(data["egemaps"])
        if use_clap:
            parts.append(data["clap"])
        if not parts:
            raise ValueError("At least one of use_egemaps/use_clap must be True.")
        X.append(np.concatenate(parts))
        y.append(int(data["label"]))
        ids.append(str(data["participant_id"]))

    return np.stack(X).astype(np.float32), np.array(y, dtype=np.int64), ids


def participant_level_split(
    rows: list[ManifestRow], val_fraction: float = 0.2, seed: int = 42
) -> tuple[list[ManifestRow], list[ManifestRow]]:
    """Split by participant, not by row, and stratified by label -- the
    ADReSS/DementiaBank literature is emphatic about this: splitting
    recordings from the same participant across train and validation
    leaks speaker identity and inflates apparent accuracy. This dataset
    format is one row per participant already (see manifest docstring),
    but this function still groups by participant_id defensively in case
    a manifest ever has multiple recordings per person.
    """
    rng = np.random.default_rng(seed)
    by_participant: dict[str, list[ManifestRow]] = {}
    for row in rows:
        by_participant.setdefault(row.participant_id, []).append(row)

    participants = list(by_participant.keys())
    labels = {pid: by_participant[pid][0].label for pid in participants}

    train_ids: list[str] = []
    val_ids: list[str] = []
    for label_value in (0, 1):
        group = [pid for pid in participants if labels[pid] == label_value]
        rng.shuffle(group)
        n_val = max(1, round(len(group) * val_fraction)) if group else 0
        val_ids.extend(group[:n_val])
        train_ids.extend(group[n_val:])

    train_rows = [r for pid in train_ids for r in by_participant[pid]]
    val_rows = [r for pid in val_ids for r in by_participant[pid]]
    return train_rows, val_rows
