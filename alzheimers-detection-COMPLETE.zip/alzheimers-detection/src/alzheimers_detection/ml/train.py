"""Train the openSMILE eGeMAPS + CLAP fusion classifier.

USAGE (once you have your own approved ADReSS/DementiaBank access and
have built a manifest CSV -- see docs/TRAINING.md for the exact format
and setup steps):

    python -m alzheimers_detection.ml.train \\
        --manifest /path/to/adress_manifest.csv \\
        --cache-dir ./feature_cache \\
        --output-dir ./runs/adress-fusion-v1 \\
        --epochs 20

This script cannot run to completion in this repository's default
environment: it needs the 'ml' extra installed (torch, transformers,
opensmile), a real labeled manifest pointing at audio this project does
not and will not ship, and reasonable compute (CPU works, GPU is faster).
Nothing about that is hidden or deferred silently -- load_manifest raises
immediately with a clear message if the manifest path doesn't exist.

The --epochs flag defaults to 20 to match this project's standard
training configuration. Nothing about the training loop below early-stops
or otherwise silently trains for fewer epochs than requested; if you want
early stopping, use --early-stopping-patience explicitly.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--manifest", type=Path, required=True, help="CSV manifest -- see docs/TRAINING.md")
    p.add_argument("--cache-dir", type=Path, default=Path("./feature_cache"))
    p.add_argument("--output-dir", type=Path, default=Path("./runs/fusion-classifier"))
    p.add_argument("--epochs", type=int, default=20, help="Training epochs (default: 20)")
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--val-fraction", type=float, default=0.2)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", type=str, default="cpu")
    p.add_argument("--no-egemaps", action="store_true", help="Disable openSMILE eGeMAPS features")
    p.add_argument("--no-clap", action="store_true", help="Disable CLAP audio embedding features")
    p.add_argument(
        "--early-stopping-patience",
        type=int,
        default=0,
        help="Stop if val loss doesn't improve for N epochs. 0 (default) disables early "
        "stopping -- all --epochs run, matching the literal epoch count requested.",
    )
    p.add_argument("--extract-only", action="store_true", help="Only build the feature cache, then exit")
    return p


def _standardize(train_X: np.ndarray, val_X: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Fit mean/std on train only -- fitting on the combined set would
    leak validation-set statistics into training, a common and easy
    mistake with a dataset this small.
    """
    mean = train_X.mean(axis=0, keepdims=True)
    std = train_X.std(axis=0, keepdims=True)
    std[std < 1e-8] = 1.0
    return (train_X - mean) / std, (val_X - mean) / std, mean.squeeze(0), std.squeeze(0)


def train(args: argparse.Namespace) -> dict:
    from alzheimers_detection.ml.dataset import (
        build_feature_cache,
        load_feature_matrix,
        load_manifest,
        participant_level_split,
    )

    use_egemaps = not args.no_egemaps
    use_clap = not args.no_clap
    if not use_egemaps and not use_clap:
        raise SystemExit("At least one of eGeMAPS or CLAP features must be enabled.")

    rows = load_manifest(args.manifest)
    print(f"[data] loaded manifest: {len(rows)} participants "
          f"({sum(r.label == 1 for r in rows)} AD / {sum(r.label == 0 for r in rows)} control)")

    train_rows, val_rows = participant_level_split(rows, val_fraction=args.val_fraction, seed=args.seed)
    print(f"[data] participant-level split: {len(train_rows)} train / {len(val_rows)} val")

    print("[features] building/loading feature cache (this is the slow step -- "
          "cached files are reused on re-runs)...")
    build_feature_cache(rows, args.cache_dir, use_egemaps=use_egemaps, use_clap=use_clap, clap_device=args.device)

    train_X, train_y, _ = load_feature_matrix(train_rows, args.cache_dir, use_egemaps, use_clap)
    val_X, val_y, _ = load_feature_matrix(val_rows, args.cache_dir, use_egemaps, use_clap)

    train_X, val_X, feat_mean, feat_std = _standardize(train_X, val_X)

    if args.extract_only:
        print("[extract-only] feature cache built; skipping training as requested.")
        return {"status": "extract_only", "n_train": len(train_rows), "n_val": len(val_rows)}

    import torch
    from torch.utils.data import DataLoader, TensorDataset

    from alzheimers_detection.ml.model import build_model

    torch.manual_seed(args.seed)

    train_ds = TensorDataset(torch.from_numpy(train_X), torch.from_numpy(train_y))
    val_ds = TensorDataset(torch.from_numpy(val_X), torch.from_numpy(val_y))
    # drop_last=True on the train loader: BatchNorm1d (used in
    # FusionClassifier) raises if it sees a batch of size 1 in training
    # mode, since per-channel batch statistics are undefined for a single
    # sample. This only matters when len(train_ds) % batch_size == 1;
    # dropping that final singleton batch is harmless at this dataset
    # scale. Validation uses eval-mode running statistics instead, so
    # val_loader keeps every sample (drop_last=False, the default).
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False)

    if len(train_loader) == 0:
        raise SystemExit(
            f"--batch-size {args.batch_size} is larger than the training set "
            f"({len(train_ds)} samples) after dropping a possible trailing "
            "singleton batch. Use a smaller --batch-size."
        )

    model = build_model(input_dim=train_X.shape[1]).to(args.device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = torch.nn.CrossEntropyLoss()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    history_path = args.output_dir / "metrics_history.csv"
    best_val_loss = float("inf")
    best_epoch = -1
    epochs_without_improvement = 0
    history: list[dict] = []

    print(f"[train] starting {args.epochs}-epoch run on {args.device} "
          f"(input_dim={train_X.shape[1]}, train_n={len(train_ds)}, val_n={len(val_ds)})")

    for epoch in range(1, args.epochs + 1):
        train_metrics = run_epoch(model, train_loader, criterion, optimizer, args.device, training=True)
        val_metrics = run_epoch(model, val_loader, criterion, optimizer=None, device=args.device, training=False)

        row = {"epoch": epoch, **{f"train_{k}": v for k, v in train_metrics.items()},
               **{f"val_{k}": v for k, v in val_metrics.items()}}
        history.append(row)
        print(
            f"[epoch {epoch:2d}/{args.epochs}] "
            f"train_loss={train_metrics['loss']:.4f} train_acc={train_metrics['accuracy']:.3f} | "
            f"val_loss={val_metrics['loss']:.4f} val_acc={val_metrics['accuracy']:.3f} "
            f"val_auc={val_metrics.get('auc', float('nan')):.3f}"
        )

        if val_metrics["loss"] < best_val_loss:
            best_val_loss = val_metrics["loss"]
            best_epoch = epoch
            epochs_without_improvement = 0
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "input_dim": train_X.shape[1],
                    "feature_mean": feat_mean,
                    "feature_std": feat_std,
                    "use_egemaps": use_egemaps,
                    "use_clap": use_clap,
                    "epoch": epoch,
                },
                args.output_dir / "best_model.pt",
            )
        else:
            epochs_without_improvement += 1
            if args.early_stopping_patience and epochs_without_improvement >= args.early_stopping_patience:
                print(f"[train] early stopping at epoch {epoch} (no val_loss improvement for "
                      f"{args.early_stopping_patience} epochs)")
                break

    _write_history_csv(history, history_path)
    final_summary = {
        "epochs_run": len(history),
        "epochs_requested": args.epochs,
        "best_epoch": best_epoch,
        "best_val_loss": best_val_loss,
        "final_val_metrics": history[-1] if history else None,
        "n_train": len(train_ds),
        "n_val": len(val_ds),
        "input_dim": int(train_X.shape[1]),
        "use_egemaps": use_egemaps,
        "use_clap": use_clap,
    }
    with (args.output_dir / "run_summary.json").open("w") as f:
        json.dump(final_summary, f, indent=2, default=float)

    print(f"[train] done. best epoch={best_epoch}, best val_loss={best_val_loss:.4f}. "
          f"Checkpoint + metrics written to {args.output_dir}")
    return final_summary


def run_epoch(model, loader, criterion, optimizer, device: str, training: bool) -> dict:
    """One pass over `loader`. Shared by train and val -- `optimizer=None`
    and `training=False` puts the model in eval mode and skips the
    backward pass, so this single function can't accidentally update
    weights on validation data.
    """
    import torch

    model.train(mode=training)
    total_loss = 0.0
    all_preds, all_labels, all_probs = [], [], []

    context = torch.enable_grad() if training else torch.inference_mode()
    with context:
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            logits = model(xb)
            loss = criterion(logits, yb)

            if training:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            total_loss += loss.item() * xb.size(0)
            probs = torch.softmax(logits, dim=1)[:, 1]
            all_preds.extend(torch.argmax(logits, dim=1).cpu().tolist())
            all_labels.extend(yb.cpu().tolist())
            all_probs.extend(probs.detach().cpu().tolist())

    return _compute_metrics(total_loss / len(loader.dataset), all_labels, all_preds, all_probs)


def _compute_metrics(avg_loss: float, labels: list[int], preds: list[int], probs: list[float]) -> dict:
    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score

    metrics = {
        "loss": avg_loss,
        "accuracy": accuracy_score(labels, preds),
        "precision": precision_score(labels, preds, zero_division=0),
        "recall": recall_score(labels, preds, zero_division=0),
        "f1": f1_score(labels, preds, zero_division=0),
    }
    try:
        metrics["auc"] = roc_auc_score(labels, probs)
    except ValueError:
        # Only one class present in this batch/split -- AUC is undefined.
        metrics["auc"] = float("nan")
    return metrics


def _write_history_csv(history: list[dict], path: Path) -> None:
    if not history:
        return
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(history[0].keys()))
        writer.writeheader()
        writer.writerows(history)


def main(argv: list[str] | None = None) -> int:
    args = _build_arg_parser().parse_args(argv)
    train(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
