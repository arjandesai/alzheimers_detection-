"""Classifier architecture.

Deliberately small. ADReSS-scale datasets are ~100-160 training
participants -- a large network over a 600-dim fused feature vector would
overfit within a handful of epochs on a dataset that size. This is a
3-layer MLP with batchnorm + dropout, not a transformer, on purpose.

Import is NOT lazy here on `torch` at module level, unlike the feature
extractors -- this module is the training code itself, so requiring torch
to import it is expected and correct (contrast with speech/clap_features.py,
which lazy-imports because it's reachable from the always-available
speech pipeline import graph).
"""

from __future__ import annotations

import torch
from torch import nn


class FusionClassifier(nn.Module):
    def __init__(self, input_dim: int, hidden_dims: tuple[int, ...] = (128, 32), num_classes: int = 2, dropout: float = 0.3):
        super().__init__()
        layers: list[nn.Module] = [nn.BatchNorm1d(input_dim)]
        prev_dim = input_dim
        for h in hidden_dims:
            layers += [nn.Linear(prev_dim, h), nn.ReLU(), nn.Dropout(dropout)]
            prev_dim = h
        layers.append(nn.Linear(prev_dim, num_classes))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def build_model(input_dim: int, num_classes: int = 2) -> FusionClassifier:
    return FusionClassifier(input_dim=input_dim, num_classes=num_classes)
