"""Model serving: load the trained speech + handwriting models and run
predictions honestly.

These models are trained OFFLINE (see the training scripts / notebooks) and
saved as .joblib files. This module loads them at startup and exposes a
narrow predict API. It deliberately does NOT retrain, and it fails loudly
if a model file is missing rather than silently returning fake scores.

Honesty rules baked in here:
  - Output is a probability + a coarse band, never a diagnosis.
  - The speech model's validated AUC (~0.89) and the handwriting model's
    CV accuracy (~0.87) are attached to every response so the caller can
    surface the tool's real, limited reliability.
  - The handwriting live-canvas path is flagged 'experimental' because
    browser-captured motion is an approximation of DARWIN's tablet data,
    not the exact validated feature set.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import numpy as np

from alzheimers_detection.core.config import get_settings


class ModelNotAvailable(RuntimeError):
    """Raised when a model file is missing. The API turns this into a clear
    503 so users know the feature isn't wired up, rather than getting a
    fabricated score."""


@dataclass
class Prediction:
    modality: str
    probability: float          # model's P(patterns consistent with AD group)
    band: str                   # "typical" | "some_markers" | "several_markers"
    validated_metric: str       # honest reliability note shown to the user
    experimental: bool          # True for the approximate handwriting-canvas path
    contributing_notes: list[str]


def _models_dir() -> Path:
    # Configurable so deployment can point at wherever the .joblib files live.
    return Path(get_settings().models_dir)


@lru_cache
def _load(modality: str):
    import joblib

    path = _models_dir() / f"{modality}_model.joblib"
    meta_path = _models_dir() / f"{modality}_model_meta.json"
    if not path.exists():
        raise ModelNotAvailable(
            f"{modality} model not found at {path}. Train it and place the .joblib there. "
            f"See docs/DEPLOY_MODELS.md."
        )
    model = joblib.load(path)
    meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
    return model, meta


def _band_from_probability(p: float) -> str:
    # Deliberately coarse and non-alarmist. Thresholds are screening-oriented:
    # we would rather say "worth discussing" than imply certainty.
    if p < 0.40:
        return "typical"
    if p < 0.65:
        return "some_markers"
    return "several_markers"


def predict_speech(gemaps_features: dict[str, float]) -> Prediction:
    """gemaps_features: the OpenSmile-GeMAPS dict (62 values) for one sample,
    same keys the model was trained on. We sort keys alphabetically to match
    the training-time feature order exactly."""
    model, meta = _load("speech")
    keys = sorted(gemaps_features.keys())
    x = np.array([[float(gemaps_features[k]) for k in keys]])
    prob = float(model.predict_proba(x)[0, 1])
    return Prediction(
        modality="speech",
        probability=prob,
        band=_band_from_probability(prob),
        validated_metric=f"Validated AUC ~{meta.get('validated_auc', 'n/a')} on EWA-DB "
                         f"(sensitivity ~{meta.get('validated_sensitivity', 'n/a')}).",
        experimental=False,
        contributing_notes=[],
    )


def predict_handwriting(features: dict[str, float], experimental: bool = True) -> Prediction:
    """features: handwriting motion features. If these are the exact 450
    DARWIN features, experimental=False; if they are browser-canvas
    approximations, experimental=True (the honest default for the live
    canvas), and the caller must surface that.
    """
    model, meta = _load("handwriting")
    expected = meta.get("features")
    if isinstance(expected, list):
        # Align to the exact training feature order; missing features -> NaN,
        # the model's imputer/scaler handles them, but we note the mismatch.
        missing = [f for f in expected if f not in features]
        x = np.array([[float(features.get(f, np.nan)) for f in expected]])
        notes = []
        if missing:
            notes.append(
                f"{len(missing)} of {len(expected)} validated features were not captured by "
                f"the browser canvas; result is an approximation."
            )
    else:
        x = np.array([[float(v) for v in features.values()]])
        notes = []

    prob = float(model.predict_proba(x)[0, 1])
    return Prediction(
        modality="handwriting",
        probability=prob,
        band=_band_from_probability(prob),
        validated_metric=f"Underlying model: ~{meta.get('validated_cv_accuracy', 'n/a')} "
                         f"cross-validated accuracy on DARWIN tablet data.",
        experimental=experimental,
        contributing_notes=notes,
    )


def fuse(predictions: list[Prediction]) -> dict:
    """Combine per-modality predictions into one screening view. Simple,
    honest average of probabilities (not a learned fusion, since no person
    has both DARWIN and EWA-DB data to train one). Documented as such."""
    if not predictions:
        return {}
    mean_p = float(np.mean([p.probability for p in predictions]))
    return {
        "combined_probability": mean_p,
        "combined_band": _band_from_probability(mean_p),
        "method": "unweighted average of per-modality probabilities "
                  "(not a trained fusion model; see docs)",
        "modalities_used": [p.modality for p in predictions],
        "any_experimental": any(p.experimental for p in predictions),
    }
