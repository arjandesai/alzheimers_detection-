"""Subscription billing endpoints.

Route split rationale: `/checkout-session` and `/portal` require a logged
-in user (they act on "my" subscription). `/webhook` is the opposite --
it must NOT require our own auth, because Stripe's servers call it, not
the user's browser. Its trust comes entirely from the signature check in
billing.construct_webhook_event, not from a bearer token.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from alzheimers_detection.api.deps import get_current_user, get_db
from alzheimers_detection.api.schemas import BillingPortalResponse, CheckoutSessionResponse
from alzheimers_detection.core import billing
from alzheimers_detection.core.audit import record_audit_event
from alzheimers_detection.core.models import User

router = APIRouter()


@router.post("/checkout-session", response_model=CheckoutSessionResponse)
def create_checkout_session(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.has_active_subscription:
        raise HTTPException(status_code=400, detail="You already have an active subscription.")
    try:
        url = billing.create_checkout_session(db, user)
    except billing.BillingNotConfigured as e:
        raise HTTPException(status_code=503, detail=str(e)) from e
    record_audit_event(db, action="checkout_session_created", user_id=user.id)
    return CheckoutSessionResponse(checkout_url=url)


@router.post("/portal", response_model=BillingPortalResponse)
def create_portal_session(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    try:
        url = billing.create_billing_portal_session(db, user)
    except billing.BillingNotConfigured as e:
        raise HTTPException(status_code=503, detail=str(e)) from e
    return BillingPortalResponse(portal_url=url)


@router.post("/webhook", status_code=200, include_in_schema=False)
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    signature = request.headers.get("stripe-signature", "")

    try:
        event = billing.construct_webhook_event(payload, signature)
    except billing.WebhookVerificationError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    except billing.BillingNotConfigured as e:
        raise HTTPException(status_code=503, detail=str(e)) from e

    event_type = event["type"]
    data_object = event["data"]["object"]

    if event_type in ("customer.subscription.updated", "customer.subscription.created"):
        customer_id = data_object.get("customer")
        user = db.query(User).filter(User.stripe_customer_id == customer_id).first()
        if user is not None:
            billing.sync_subscription_from_stripe_object(user, data_object)
            db.add(user)
            record_audit_event(
                db, action="subscription_updated", user_id=user.id,
                metadata={"stripe_status": data_object.get("status")},
            )

    elif event_type == "customer.subscription.deleted":
        customer_id = data_object.get("customer")
        user = db.query(User).filter(User.stripe_customer_id == customer_id).first()
        if user is not None:
            billing.mark_subscription_canceled(user)
            db.add(user)
            record_audit_event(db, action="subscription_canceled", user_id=user.id)

    elif event_type == "checkout.session.completed":
        user_id = data_object.get("client_reference_id")
        if user_id:
            record_audit_event(db, action="checkout_completed", user_id=user_id)

    # Always 200 on any recognized-but-unhandled event type, per Stripe's
    # guidance -- returning an error here causes Stripe to retry
    # indefinitely for events we intentionally don't act on.
    return {"received": True}
