"""Prediction endpoints: run the trained speech + handwriting models.

Gated behind an active subscription (same as uploads). Each endpoint takes
already-extracted features (GeMAPS for speech, motion features for
handwriting), runs the trained model via ml/serving.py, persists an
encrypted AnalysisRecord, and returns an honest banded result.

Feature EXTRACTION happens elsewhere: for speech, GeMAPS is extracted from
the uploaded audio (speech pipeline); for handwriting, the browser canvas
computes motion features client-side and posts them. This route is the
model-scoring step, not the extraction step.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from alzheimers_detection.api.deps import get_db, require_active_subscription
from alzheimers_detection.core.audit import record_audit_event
from alzheimers_detection.core.models import AnalysisRecord, User
from alzheimers_detection.ml import serving

router = APIRouter()


class SpeechFeatures(BaseModel):
    gemaps: dict[str, float] = Field(description="OpenSmile-GeMAPS features (62 values)")


class HandwritingFeatures(BaseModel):
    features: dict[str, float] = Field(description="Motion features from the writing canvas")
    experimental: bool = Field(
        default=True,
        description="True when features come from the browser canvas (an approximation of "
        "DARWIN's tablet data). The result surfaces this to the user.",
    )


def _prediction_response(pred: serving.Prediction) -> dict:
    return {
        "modality": pred.modality,
        "probability": round(pred.probability, 4),
        "band": pred.band,
        "band_label": {
            "typical": "Markers look typical",
            "some_markers": "Some markers worth noting",
            "several_markers": "Several markers worth discussing",
        }[pred.band],
        "validated_metric": pred.validated_metric,
        "experimental": pred.experimental,
        "contributing_notes": pred.contributing_notes,
        "disclaimer": "This is a research screening indicator, not a diagnosis. "
        "Only a doctor can evaluate cognitive health. If you have concerns, please consult one.",
    }


@router.post("/speech")
def predict_speech(
    body: SpeechFeatures,
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> dict:
    try:
        pred = serving.predict_speech(body.gemaps)
    except serving.ModelNotAvailable as e:
        raise HTTPException(status_code=503, detail=str(e)) from e

    resp = _prediction_response(pred)
    record = AnalysisRecord(user_id=user.id, modality="speech", status="complete", result_json=resp)
    db.add(record)
    db.flush()
    record_audit_event(db, action="prediction_speech", user_id=user.id,
                       resource_type="analysis_record", resource_id=record.id, metadata={"band": pred.band})
    resp["analysis_id"] = record.id
    return resp


@router.post("/handwriting")
def predict_handwriting(
    body: HandwritingFeatures,
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> dict:
    try:
        pred = serving.predict_handwriting(body.features, experimental=body.experimental)
    except serving.ModelNotAvailable as e:
        raise HTTPException(status_code=503, detail=str(e)) from e

    resp = _prediction_response(pred)
    record = AnalysisRecord(user_id=user.id, modality="handwriting", status="complete", result_json=resp)
    db.add(record)
    db.flush()
    record_audit_event(db, action="prediction_handwriting", user_id=user.id,
                       resource_type="analysis_record", resource_id=record.id, metadata={"band": pred.band})
    resp["analysis_id"] = record.id
    return resp


@router.get("/history")
def get_history(
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> list:
    records = (
        db.query(AnalysisRecord)
        .filter(AnalysisRecord.user_id == user.id)
        .order_by(AnalysisRecord.created_at.desc())
        .limit(50)
        .all()
    )
    return [
        {
            "id": r.id,
            "modality": r.modality,
            "created_at": r.created_at.isoformat(),
            "status": r.status,
            "result_json": r.result_json,
        }
        for r in records
    ]
    speech_probability: float | None = None
    handwriting_probability: float | None = None


@router.post("/combined")
def predict_combined(
    body: FusionRequest,
    user: User = Depends(require_active_subscription),
) -> dict:
    """Fuse two already-computed per-modality probabilities into one view.
    Kept stateless (takes probabilities, not raw data) so the frontend can
    combine the two results the user already has without re-running models."""
    preds = []
    if body.speech_probability is not None:
        preds.append(serving.Prediction("speech", body.speech_probability, "", "", False, []))
    if body.handwriting_probability is not None:
        preds.append(serving.Prediction("handwriting", body.handwriting_probability, "", "", True, []))
    if not preds:
        raise HTTPException(status_code=400, detail="Provide at least one modality probability.")

    result = serving.fuse(preds)
    result["disclaimer"] = (
        "Combined screening indicator from a simple average of two research models. "
        "Not a diagnosis. Consult a doctor with any concerns."
    )
    return result
