"""Speech analysis endpoint. Now gated by subscription and persisted."""

from __future__ import annotations

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from alzheimers_detection.api.deps import get_db, require_active_subscription
from alzheimers_detection.core.audit import record_audit_event
from alzheimers_detection.core.models import AnalysisRecord, User
from alzheimers_detection.speech.pipeline import analyze_audio_bytes
from alzheimers_detection.speech.schemas import SpeechAnalysisResult
from alzheimers_detection.speech.transcription import TranscriptionError

router = APIRouter()

_ALLOWED_CONTENT_TYPES = {"audio/wav", "audio/x-wav", "audio/mpeg", "audio/mp4", "audio/webm", "audio/ogg"}


@router.post(
    "/analyze",
    response_model=SpeechAnalysisResult,
    summary="Analyze a speech sample for acoustic and linguistic biomarkers",
)
async def analyze_speech(
    file: UploadFile = File(...),
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> SpeechAnalysisResult:
    if file.content_type and file.content_type not in _ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported content type '{file.content_type}'. "
            f"Expected one of: {sorted(_ALLOWED_CONTENT_TYPES)}",
        )

    audio_bytes = await file.read()
    if not audio_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    try:
        result = analyze_audio_bytes(audio_bytes, filename_hint=file.filename or "upload.wav")
    except TranscriptionError as e:
        raise HTTPException(status_code=422, detail=str(e)) from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    record = AnalysisRecord(
        user_id=user.id,
        modality="speech",
        status="complete",
        result_json=result.model_dump(mode="json"),
    )
    db.add(record)
    db.flush()

    record_audit_event(
        db, action="analysis_created", user_id=user.id, resource_type="analysis_record", resource_id=record.id,
        metadata={"modality": "speech", "risk_band": result.risk_band.value},
    )

    return result


@router.get("/results/{analysis_id}", response_model=SpeechAnalysisResult)
def get_result(
    analysis_id: str,
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> SpeechAnalysisResult:
    record = db.get(AnalysisRecord, analysis_id)
    if record is None or record.user_id != user.id or record.modality != "speech":
        raise HTTPException(status_code=404, detail="Result not found.")
    record_audit_event(
        db, action="analysis_viewed", user_id=user.id, resource_type="analysis_record", resource_id=analysis_id
    )
    return SpeechAnalysisResult.model_validate(record.result_json)


@router.delete("/results/{analysis_id}", status_code=204)
def delete_result(
    analysis_id: str,
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> None:
    record = db.get(AnalysisRecord, analysis_id)
    if record is None or record.user_id != user.id:
        raise HTTPException(status_code=404, detail="Result not found.")
    db.delete(record)
    record_audit_event(
        db, action="analysis_deleted", user_id=user.id, resource_type="analysis_record", resource_id=analysis_id
    )
