"""Registration, login (with optional TOTP 2FA), and account endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from alzheimers_detection.api.deps import get_current_user, get_db
from alzheimers_detection.api.schemas import (
    TokenResponse,
    TwoFactorConfirm,
    TwoFactorRequiredResponse,
    TwoFactorSetupResponse,
    TwoFactorVerify,
    UserCreate,
    UserLogin,
    UserRead,
)
from alzheimers_detection.core import twofa
from alzheimers_detection.core.audit import record_audit_event
from alzheimers_detection.core.models import User
from alzheimers_detection.core.security import (
    TokenError,
    create_access_token,
    create_twofa_pending_token,
    decode_access_token,
    hash_password,
    verify_password,
)

router = APIRouter()


@router.post("/register", response_model=TokenResponse, status_code=201)
def register(body: UserCreate, db: Session = Depends(get_db)) -> TokenResponse:
    existing = db.query(User).filter(User.email == body.email.lower()).first()
    if existing is not None:
        raise HTTPException(status_code=409, detail="An account with that email already exists.")

    user = User(email=body.email.lower(), hashed_password=hash_password(body.password))
    db.add(user)
    db.flush()

    record_audit_event(db, action="user_registered", user_id=user.id, resource_type="user", resource_id=user.id)

    token = create_access_token(subject=user.id)
    return TokenResponse(access_token=token, user=UserRead.model_validate(user))


@router.post("/login", response_model=TokenResponse | TwoFactorRequiredResponse)
def login(body: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email.lower()).first()
    invalid = HTTPException(status_code=401, detail="Incorrect email or password.")
    if user is None or not verify_password(body.password, user.hashed_password):
        raise invalid

    # Password is correct. If 2FA is on, don't hand out a real token yet,
    # issue a short-lived pending token that only /login/2fa accepts.
    if user.twofa_enabled:
        record_audit_event(db, action="login_password_ok_awaiting_2fa", user_id=user.id)
        return TwoFactorRequiredResponse(pending_token=create_twofa_pending_token(user.id))

    record_audit_event(db, action="user_login", user_id=user.id, resource_type="user", resource_id=user.id)
    token = create_access_token(subject=user.id)
    return TokenResponse(access_token=token, user=UserRead.model_validate(user))


@router.post("/login/2fa", response_model=TokenResponse)
def login_2fa(body: TwoFactorVerify, db: Session = Depends(get_db)) -> TokenResponse:
    """Second stage of a 2FA login: exchange (pending_token + TOTP or
    recovery code) for a real access token."""
    invalid_token = HTTPException(status_code=401, detail="Invalid or expired 2FA session. Please log in again.")
    try:
        payload = decode_access_token(body.pending_token)
    except TokenError as e:
        raise invalid_token from e
    if payload.get("purpose") != "twofa_pending":
        raise invalid_token

    user = db.get(User, payload.get("sub"))
    if user is None or not user.twofa_enabled or not user.totp_secret:
        raise invalid_token

    code_ok = twofa.verify_totp(user.totp_secret, body.code)
    used_recovery = False
    if not code_ok and user.recovery_code_hashes:
        code_ok, remaining = twofa.verify_and_consume_recovery_code(body.code, user.recovery_code_hashes)
        if code_ok:
            user.recovery_code_hashes = remaining
            db.add(user)
            used_recovery = True

    if not code_ok:
        record_audit_event(db, action="login_2fa_failed", user_id=user.id)
        raise HTTPException(status_code=401, detail="Incorrect authentication code.")

    record_audit_event(
        db, action="user_login_2fa", user_id=user.id,
        metadata={"used_recovery_code": used_recovery},
    )
    token = create_access_token(subject=user.id)
    return TokenResponse(access_token=token, user=UserRead.model_validate(user))


@router.post("/2fa/setup", response_model=TwoFactorSetupResponse)
def setup_2fa(user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> TwoFactorSetupResponse:
    """Begin 2FA enrollment. Generates and stores (encrypted) a TOTP secret
    and recovery codes, but does NOT enable 2FA yet, that requires
    confirming a code via /2fa/confirm, so a user who scans wrong can't
    lock themselves out."""
    if user.twofa_enabled:
        raise HTTPException(status_code=400, detail="Two-factor authentication is already enabled.")

    secret = twofa.generate_totp_secret()
    recovery_codes = twofa.generate_recovery_codes()

    user.totp_secret = secret
    user.recovery_code_hashes = twofa.hash_recovery_codes(recovery_codes)
    # twofa_enabled stays False until /2fa/confirm succeeds.
    db.add(user)

    record_audit_event(db, action="2fa_setup_started", user_id=user.id)

    return TwoFactorSetupResponse(
        provisioning_uri=twofa.provisioning_uri(secret, user.email),
        secret=secret,
        recovery_codes=recovery_codes,
    )


@router.post("/2fa/confirm", response_model=UserRead)
def confirm_2fa(body: TwoFactorConfirm, user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> UserRead:
    if user.twofa_enabled:
        raise HTTPException(status_code=400, detail="Two-factor authentication is already enabled.")
    if not user.totp_secret:
        raise HTTPException(status_code=400, detail="Start 2FA setup first via /2fa/setup.")
    if not twofa.verify_totp(user.totp_secret, body.code):
        raise HTTPException(status_code=401, detail="Incorrect code. Please try again.")

    user.twofa_enabled = True
    db.add(user)
    record_audit_event(db, action="2fa_enabled", user_id=user.id)
    return UserRead.model_validate(user)


@router.post("/2fa/disable", response_model=UserRead)
def disable_2fa(body: TwoFactorConfirm, user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> UserRead:
    """Disabling 2FA requires a current valid code, so a hijacked session
    (with the access token but not the authenticator) can't silently turn
    it off."""
    if not user.twofa_enabled:
        raise HTTPException(status_code=400, detail="Two-factor authentication is not enabled.")
    if not user.totp_secret or not twofa.verify_totp(user.totp_secret, body.code):
        raise HTTPException(status_code=401, detail="Incorrect code.")

    user.twofa_enabled = False
    user.totp_secret = None
    user.recovery_code_hashes = None
    db.add(user)
    record_audit_event(db, action="2fa_disabled", user_id=user.id)
    return UserRead.model_validate(user)


@router.get("/me", response_model=UserRead)
def me(user: User = Depends(get_current_user)) -> UserRead:
    return UserRead.model_validate(user)


@router.delete("/me", status_code=204)
def delete_account(user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> None:
    """Right-to-erasure endpoint. Cascades to the user's analyses and
    uploads via the ORM relationship cascade in core/models.py."""
    record_audit_event(db, action="account_deleted", user_id=user.id, resource_type="user", resource_id=user.id)
    db.delete(user)
