"""Upload endpoint for images and video.

Images (and now video) are accepted, encrypted, and stored so nothing is
lost while downstream analysis pipelines are built. Speech audio is NOT
handled here, that goes through /api/v1/speech/analyze, which processes
and discards it by default. We do NOT fabricate a video/image analysis
model here, uploaded files sit in "queued_for_analysis" until a real
pipeline exists (see CLAUDE.md and docs/DATASETS.md on why an unvalidated
model would be worse than an honest "not yet analyzed" state).
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from alzheimers_detection.api.deps import get_db, require_active_subscription
from alzheimers_detection.api.schemas import UploadedFileRead
from alzheimers_detection.core.audit import record_audit_event
from alzheimers_detection.core.models import UploadedFile, User

router = APIRouter()

_ALLOWED_IMAGE_TYPES = {"image/png", "image/jpeg", "image/webp", "image/heic"}
_ALLOWED_VIDEO_TYPES = {"video/mp4", "video/quicktime", "video/webm", "video/x-matroska"}
_ALLOWED_TYPES = _ALLOWED_IMAGE_TYPES | _ALLOWED_VIDEO_TYPES

# Video files are much larger than images, so the cap is per-modality.
_MAX_IMAGE_BYTES = 15 * 1024 * 1024   # 15 MB
_MAX_VIDEO_BYTES = 200 * 1024 * 1024  # 200 MB


def _modality_for(content_type: str) -> str:
    if content_type in _ALLOWED_IMAGE_TYPES:
        return "image"
    if content_type in _ALLOWED_VIDEO_TYPES:
        return "video"
    raise HTTPException(
        status_code=415,
        detail=f"Unsupported content type '{content_type}'. Expected an image "
        f"({sorted(_ALLOWED_IMAGE_TYPES)}) or video ({sorted(_ALLOWED_VIDEO_TYPES)}).",
    )


async def _store_upload(file: UploadFile, user: User, db: Session) -> UploadedFileRead:
    modality = _modality_for(file.content_type or "")
    max_bytes = _MAX_IMAGE_BYTES if modality == "image" else _MAX_VIDEO_BYTES

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
    if len(data) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"{modality.capitalize()} exceeds the {max_bytes // (1024 * 1024)}MB limit.",
        )

    record = UploadedFile(
        user_id=user.id,
        modality=modality,
        original_filename=file.filename or "upload",
        content_type=file.content_type,
        byte_size=len(data),
        blob=data,  # encrypted transparently by the EncryptedBlob column type
        status="queued_for_analysis",
    )
    db.add(record)
    db.flush()

    record_audit_event(
        db, action="file_uploaded", user_id=user.id, resource_type="uploaded_file", resource_id=record.id,
        metadata={"modality": modality, "byte_size": len(data)},
    )
    return UploadedFileRead.model_validate(record)


@router.post("/media", response_model=UploadedFileRead, status_code=201)
async def upload_media(
    file: UploadFile = File(...),
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> UploadedFileRead:
    """Accept a single image OR video file. Modality is inferred from the
    content type."""
    return await _store_upload(file, user, db)


@router.post("/image", response_model=UploadedFileRead, status_code=201)
async def upload_image(
    file: UploadFile = File(...),
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> UploadedFileRead:
    """Image-only endpoint, kept for backward compatibility. Rejects video."""
    if (file.content_type or "") not in _ALLOWED_IMAGE_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"This endpoint accepts images only. For video use /media. "
            f"Got '{file.content_type}'.",
        )
    return await _store_upload(file, user, db)


@router.get("", response_model=list[UploadedFileRead])
def list_uploads(
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> list[UploadedFileRead]:
    records = (
        db.query(UploadedFile)
        .filter(UploadedFile.user_id == user.id)
        .order_by(UploadedFile.created_at.desc())
        .all()
    )
    return [UploadedFileRead.model_validate(r) for r in records]


@router.delete("/{upload_id}", status_code=204)
def delete_upload(
    upload_id: str,
    user: User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
) -> None:
    record = db.get(UploadedFile, upload_id)
    if record is None or record.user_id != user.id:
        raise HTTPException(status_code=404, detail="Upload not found.")
    db.delete(record)
    record_audit_event(
        db, action="file_deleted", user_id=user.id, resource_type="uploaded_file", resource_id=upload_id
    )
