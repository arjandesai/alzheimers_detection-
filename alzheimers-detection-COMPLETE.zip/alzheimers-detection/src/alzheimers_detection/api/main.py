"""FastAPI application entry point.

Run locally with: uvicorn alzheimers_detection.api.main:app --reload
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from alzheimers_detection import __version__
from alzheimers_detection.api.routes import auth, billing, predict, speech, uploads
from alzheimers_detection.core import disclaimers
from alzheimers_detection.core.config import get_settings


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title="Alzheimer's Digital Biomarker Platform",
        description=disclaimers.GENERAL_DISCLAIMER,
        version=__version__,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.api_cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])
    app.include_router(billing.router, prefix="/api/v1/billing", tags=["billing"])
    app.include_router(speech.router, prefix="/api/v1/speech", tags=["speech"])
    app.include_router(uploads.router, prefix="/api/v1/uploads", tags=["uploads"])
    app.include_router(predict.router, prefix="/api/v1/predict", tags=["predict"])

    @app.on_event("startup")
    def _dev_db_init() -> None:
        # Dev-convenience only. Production schema management is via
        # Alembic (`alembic upgrade head`), run as a deploy step, not
        # implicitly at app startup -- see core/db.py::init_db docstring.
        if settings.environment != "production":
            from alzheimers_detection.core.db import init_db

            init_db()

    @app.get("/health", tags=["meta"])
    def health() -> dict:
        return {"status": "ok", "version": __version__}

    @app.get("/", tags=["meta"])
    def root() -> dict:
        return {
            "name": "alzheimers-detection",
            "version": __version__,
            "disclaimer": disclaimers.GENERAL_DISCLAIMER,
            "docs": "/docs",
        }

    return app


app = create_app()
