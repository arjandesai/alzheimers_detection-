"""Pydantic schemas for the auth, billing, and upload endpoints.
Kept separate from speech/schemas.py since these aren't biomarker data
contracts -- they're account/product schemas.
"""

from __future__ import annotations

import datetime as dt

from pydantic import BaseModel, EmailStr, Field


class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserRead(BaseModel):
    id: str
    email: EmailStr
    created_at: dt.datetime
    subscription_status: str
    has_active_subscription: bool
    twofa_enabled: bool = False

    model_config = {"from_attributes": True}


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserRead


class TwoFactorRequiredResponse(BaseModel):
    """Returned by /login when the account has 2FA enabled. Instead of a
    full access token, the client gets a short-lived pending token it must
    exchange (along with a TOTP code) at /login/2fa for a real token."""

    twofa_required: bool = True
    pending_token: str


class TwoFactorVerify(BaseModel):
    pending_token: str
    code: str = Field(description="6-digit TOTP code or a recovery code")


class TwoFactorSetupResponse(BaseModel):
    """Returned when a user begins 2FA enrollment: the provisioning URI
    (for the QR code) and the plaintext recovery codes, shown exactly
    once. The secret is embedded in the URI; it is not enabled until
    confirmed via /2fa/confirm."""

    provisioning_uri: str
    secret: str
    recovery_codes: list[str]


class TwoFactorConfirm(BaseModel):
    code: str = Field(description="6-digit TOTP code from the authenticator app to confirm setup")


class CheckoutSessionResponse(BaseModel):
    checkout_url: str


class BillingPortalResponse(BaseModel):
    portal_url: str


class UploadedFileRead(BaseModel):
    id: str
    modality: str
    original_filename: str
    content_type: str
    byte_size: int
    status: str
    created_at: dt.datetime

    model_config = {"from_attributes": True}
