"""Shared FastAPI dependencies: DB session, authenticated user, paywall gate."""

from __future__ import annotations

from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from alzheimers_detection.core.db import get_db
from alzheimers_detection.core.models import User
from alzheimers_detection.core.security import TokenError, decode_access_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


def get_current_user(
    token: str | None = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    unauthorized = HTTPException(status_code=401, detail="Could not validate credentials.")
    if token is None:
        raise unauthorized
    try:
        payload = decode_access_token(token)
    except TokenError as e:
        raise HTTPException(status_code=401, detail=str(e)) from e

    # A 2FA-pending token (purpose="twofa_pending") authenticates the
    # password step only, it must never grant real access. Anything that
    # isn't an explicit access token is rejected here.
    if payload.get("purpose") != "access":
        raise unauthorized

    user_id = payload.get("sub")
    if not user_id:
        raise unauthorized

    user = db.get(User, user_id)
    if user is None:
        raise unauthorized
    return user


def require_active_subscription(user: User = Depends(get_current_user)) -> User:
    """The paywall gate. Any route that should be behind the $5/month
    subscription depends on this instead of `get_current_user` directly.
    Returns 402 Payment Required (the semantically correct status for
    "you're authenticated, but you haven't paid"), not 403, so the
    frontend can distinguish "log in" from "subscribe" and route the
    user to the right page.
    """
    if not user.has_active_subscription:
        raise HTTPException(
            status_code=402,
            detail="An active subscription is required to use this feature.",
        )
    return user
