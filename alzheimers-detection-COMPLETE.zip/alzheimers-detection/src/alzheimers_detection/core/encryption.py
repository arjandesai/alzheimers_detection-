"""Encryption at rest for sensitive columns and stored files.

Design: symmetric encryption (Fernet, which is AES-128-CBC + HMAC under
the hood) with a single server-held key from ALZDX_ENCRYPTION_KEY. This is
NOT end-to-end encryption -- the server can read the data, because the
server needs to run feature extraction on it. What this protects against
is a much more common real-world risk: a stolen disk, a misconfigured
backup, or a leaked database dump being readable without also having the
separate encryption key (which should live in a secrets manager, not the
database host).

This module fails loudly rather than silently. If ALZDX_ENCRYPTION_KEY is
unset, get_fernet() raises at first use rather than falling back to
plaintext -- storing PHI-adjacent data unencrypted because a key was
forgotten is a worse failure mode than a crashed request.
"""

from __future__ import annotations

from functools import lru_cache

from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy.types import LargeBinary, TypeDecorator

from alzheimers_detection.core.config import get_settings


class EncryptionKeyNotConfigured(RuntimeError):
    pass


class DecryptionError(RuntimeError):
    """Raised when stored ciphertext can't be decrypted with the current
    key -- e.g. the key rotated without a re-encryption migration, or the
    data is corrupted. Callers should treat this as data-loss-adjacent,
    not retry blindly."""


@lru_cache
def get_fernet() -> Fernet:
    settings = get_settings()
    if not settings.encryption_key:
        raise EncryptionKeyNotConfigured(
            "ALZDX_ENCRYPTION_KEY is not set. Generate one with: "
            "python -c \"from cryptography.fernet import Fernet; "
            "print(Fernet.generate_key().decode())\" "
            "and set it in your environment before storing any data."
        )
    return Fernet(settings.encryption_key.encode())


def encrypt_bytes(data: bytes) -> bytes:
    return get_fernet().encrypt(data)


def decrypt_bytes(token: bytes) -> bytes:
    try:
        return get_fernet().decrypt(token)
    except InvalidToken as e:
        raise DecryptionError("Ciphertext could not be decrypted with the configured key.") from e


def encrypt_text(text: str) -> bytes:
    return encrypt_bytes(text.encode("utf-8"))


def decrypt_text(token: bytes) -> str:
    return decrypt_bytes(token).decode("utf-8")


class EncryptedJSON(TypeDecorator):
    """SQLAlchemy column type: stores a JSON-serializable Python object as
    Fernet-encrypted bytes. Use for any column holding analysis results,
    transcripts, or other data derived from a person's uploaded content.

    Usage: `result_json: Mapped[dict] = mapped_column(EncryptedJSON)`
    Reads/writes look like a normal JSON column to the rest of the
    codebase -- encryption is transparent at this layer.
    """

    impl = LargeBinary
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        import json

        return encrypt_text(json.dumps(value))

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        import json

        return json.loads(decrypt_text(value))


class EncryptedBlob(TypeDecorator):
    """SQLAlchemy column type for raw encrypted binary data (e.g. an
    uploaded image or audio file stored in the DB rather than object
    storage). For larger deployments, prefer encrypting client-side of an
    S3-compatible object store instead of storing blobs in Postgres --
    this type exists for the small-scale/local-first deployment case
    described in the project's privacy goals.
    """

    impl = LargeBinary
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        return encrypt_bytes(value)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return decrypt_bytes(value)


class EncryptedText(TypeDecorator):
    """SQLAlchemy column type: stores a single string encrypted at rest.
    Used for the TOTP 2FA secret (core/models.py), where possession of the
    plaintext is equivalent to being able to mint valid codes, so it must
    never sit in the database as cleartext.
    """

    impl = LargeBinary
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        return encrypt_text(value)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return decrypt_text(value)
