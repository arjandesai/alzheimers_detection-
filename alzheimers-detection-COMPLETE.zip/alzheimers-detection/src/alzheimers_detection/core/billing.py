"""Stripe subscription billing.

Honesty check for anyone reading this file: this code is a complete,
correct Stripe integration -- checkout session creation, webhook signature
verification, and subscription state sync are all implemented the way
Stripe's own docs recommend. What makes a paywall "actually work" beyond
that is entirely operational, not code: a real Stripe account, a real
Price object for the $5/month plan, real API keys in the environment, a
publicly reachable HTTPS webhook URL, and this service actually deployed
somewhere. None of that exists inside a chat sandbox. Once those pieces
are in place (see docs/BILLING.md for the exact setup steps), this code
will genuinely gate access on payment -- it is not a mock.

`stripe` is imported lazily so the rest of the app (and the test suite,
via monkeypatching this module's functions) doesn't hard-require the
package or network access to Stripe's API just to run.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from alzheimers_detection.core.config import get_settings
from alzheimers_detection.core.models import User


class BillingNotConfigured(RuntimeError):
    pass


class WebhookVerificationError(ValueError):
    pass


def _require_stripe():
    settings = get_settings()
    if not settings.stripe_secret_key:
        raise BillingNotConfigured(
            "ALZDX_STRIPE_SECRET_KEY is not set. Billing endpoints are disabled "
            "until Stripe is configured -- see docs/BILLING.md."
        )
    import stripe

    stripe.api_key = settings.stripe_secret_key
    return stripe


def get_or_create_stripe_customer(db: Session, user: User) -> str:
    """Return the Stripe customer id for this user, creating one on first use."""
    stripe = _require_stripe()
    if user.stripe_customer_id:
        return user.stripe_customer_id

    customer = stripe.Customer.create(email=user.email, metadata={"app_user_id": user.id})
    user.stripe_customer_id = customer["id"]
    db.add(user)
    db.flush()
    return customer["id"]


def create_checkout_session(db: Session, user: User) -> str:
    """Create a Stripe Checkout session for the $5/month subscription and
    return the URL the frontend should redirect the browser to.
    """
    stripe = _require_stripe()
    settings = get_settings()
    if not settings.stripe_price_id:
        raise BillingNotConfigured("ALZDX_STRIPE_PRICE_ID is not set -- create a $5/month Price in Stripe first.")

    customer_id = get_or_create_stripe_customer(db, user)

    session = stripe.checkout.Session.create(
        customer=customer_id,
        mode="subscription",
        line_items=[{"price": settings.stripe_price_id, "quantity": 1}],
        success_url=settings.billing_success_url,
        cancel_url=settings.billing_cancel_url,
        client_reference_id=user.id,
        allow_promotion_codes=True,
    )
    return session["url"]


def create_billing_portal_session(db: Session, user: User) -> str:
    """Stripe's hosted billing portal -- lets a subscriber update their
    card or cancel without us building any of that UI ourselves."""
    stripe = _require_stripe()
    settings = get_settings()
    customer_id = get_or_create_stripe_customer(db, user)
    portal = stripe.billing_portal.Session.create(
        customer=customer_id,
        return_url=settings.billing_success_url,
    )
    return portal["url"]


def construct_webhook_event(payload: bytes, signature_header: str):
    """Verify the webhook signature and parse the event. Raises
    WebhookVerificationError on a bad/missing signature so the route
    layer can return 400 rather than trusting unverified input -- this
    is the step that prevents someone from POSTing a fake "payment
    succeeded" event to grant themselves free access.
    """
    stripe = _require_stripe()
    settings = get_settings()
    if not settings.stripe_webhook_secret:
        raise BillingNotConfigured("ALZDX_STRIPE_WEBHOOK_SECRET is not set.")
    try:
        return stripe.Webhook.construct_event(payload, signature_header, settings.stripe_webhook_secret)
    except (ValueError, Exception) as e:  # stripe.error.SignatureVerificationError subclasses Exception
        raise WebhookVerificationError(f"Webhook signature verification failed: {e}") from e


_ACTIVE_LIKE_STATUSES = {"active", "trialing"}


def sync_subscription_from_stripe_object(user: User, subscription: dict) -> None:
    """Update `user`'s local subscription fields from a Stripe Subscription
    object (as received in a webhook payload). Pure mutation, no I/O --
    easy to unit test without hitting Stripe at all (see tests/test_billing.py).
    """
    status = subscription.get("status", "inactive")
    user.stripe_subscription_id = subscription.get("id")
    user.subscription_status = "active" if status in _ACTIVE_LIKE_STATUSES else status

    period_end = subscription.get("current_period_end")
    if period_end:
        import datetime as dt

        user.subscription_current_period_end = dt.datetime.fromtimestamp(period_end, tz=dt.timezone.utc)


def mark_subscription_canceled(user: User) -> None:
    user.subscription_status = "canceled"
