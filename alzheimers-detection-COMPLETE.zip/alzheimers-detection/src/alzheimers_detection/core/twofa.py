"""Two-factor authentication (TOTP, RFC 6238).

Design choice: TOTP (authenticator-app codes, e.g. Google Authenticator,
Authy, 1Password) rather than SMS. SMS 2FA needs a paid third-party
provider (Twilio etc.), is vulnerable to SIM-swap attacks, and adds an
external dependency and per-message cost. TOTP is self-contained, free,
and more secure, the user scans a QR code once and their app generates
codes offline forever after.

The TOTP secret is stored encrypted at rest (see core/models.py using the
EncryptedText column type), because possession of the secret is
equivalent to being able to generate valid codes, it's as sensitive as a
password and must never be stored in plaintext.

Recovery codes: single-use backup codes for when a user loses their
authenticator device. Stored as bcrypt hashes (same one-way treatment as
passwords), never recoverable, only verifiable. Losing both the
authenticator and the recovery codes means account recovery has to happen
out of band (support), which is the correct security posture, not a bug.
"""

from __future__ import annotations

import secrets

import pyotp

from alzheimers_detection.core.security import hash_password, verify_password

_ISSUER_NAME = "Bushido"  # shown in the user's authenticator app
_RECOVERY_CODE_COUNT = 10


def generate_totp_secret() -> str:
    """A new base32 TOTP secret. Store this (encrypted) against the user."""
    return pyotp.random_base32()


def provisioning_uri(secret: str, account_email: str) -> str:
    """The otpauth:// URI encoded into the QR code the user scans. Contains
    the secret, so treat any surface that renders it as sensitive (serve
    over HTTPS only, never log it)."""
    return pyotp.TOTP(secret).provisioning_uri(name=account_email, issuer_name=_ISSUER_NAME)


def verify_totp(secret: str, code: str) -> bool:
    """Verify a 6-digit code. `valid_window=1` accepts the immediately
    previous/next 30s window too, which tolerates minor clock skew
    between the server and the user's device without meaningfully
    weakening security."""
    if not code or not code.strip().isdigit():
        return False
    return pyotp.TOTP(secret).verify(code.strip(), valid_window=1)


def generate_recovery_codes(n: int = _RECOVERY_CODE_COUNT) -> list[str]:
    """Human-friendly single-use backup codes, e.g. '3f9a-2b7c'. Returned
    in plaintext ONCE at setup time for the user to save; only their
    hashes are persisted."""
    codes = []
    for _ in range(n):
        raw = secrets.token_hex(4)  # 8 hex chars
        codes.append(f"{raw[:4]}-{raw[4:]}")
    return codes


def hash_recovery_codes(codes: list[str]) -> list[str]:
    return [hash_password(c) for c in codes]


def verify_and_consume_recovery_code(code: str, hashed_codes: list[str]) -> tuple[bool, list[str]]:
    """Check `code` against the list of stored hashes. On a match, returns
    (True, remaining_hashes_with_that_one_removed) so the caller can
    persist the shortened list, enforcing single-use. On no match returns
    (False, unchanged_hashes).
    """
    normalized = code.strip().lower()
    for i, h in enumerate(hashed_codes):
        if verify_password(normalized, h):
            remaining = hashed_codes[:i] + hashed_codes[i + 1 :]
            return True, remaining
    return False, hashed_codes
