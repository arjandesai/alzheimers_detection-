"""ORM models.

`AnalysisRecord` is deliberately modality-generic (a `modality` string
column, not a `speech_analyses` table) so Milestone 3+ modalities reuse
this table instead of each needing their own -- see CLAUDE.md's note on
why premature per-modality tables would be worse than one shared shape.

Sensitive payloads (`AnalysisRecord.result_json`, `UploadedFile.blob`) use
the encrypted column types from core/encryption.py -- encryption is
transparent to everything above the ORM layer.
"""

from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import DateTime, ForeignKey, Integer, JSON, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from alzheimers_detection.core.db import Base
from alzheimers_detection.core.encryption import EncryptedBlob, EncryptedJSON, EncryptedText


def _uuid() -> str:
    return str(uuid.uuid4())


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(100), nullable=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)

    # --- Two-factor auth (TOTP) ---
    # totp_secret is null until the user begins 2FA setup; twofa_enabled
    # stays False until they confirm setup with a valid code (so a
    # half-finished setup can't lock them out). Recovery codes are stored
    # as a JSON list of bcrypt hashes (see core/twofa.py).
    totp_secret: Mapped[str | None] = mapped_column(EncryptedText, nullable=True)
    twofa_enabled: Mapped[bool] = mapped_column(default=False)
    recovery_code_hashes: Mapped[list | None] = mapped_column(JSON, nullable=True)

    # --- Billing (Stripe) ---
    stripe_customer_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    stripe_subscription_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    # inactive | active | past_due | canceled -- mirrors Stripe subscription
    # statuses closely enough for gating logic; see core/billing.py.
    subscription_status: Mapped[str] = mapped_column(String(20), default="inactive")
    subscription_current_period_end: Mapped[dt.datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    analyses: Mapped[list["AnalysisRecord"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    uploads: Mapped[list["UploadedFile"]] = relationship(back_populates="user", cascade="all, delete-orphan")

    @property
    def has_active_subscription(self) -> bool:
        if self.subscription_status != "active":
            return False
        if self.subscription_current_period_end is None:
            return True
        return self.subscription_current_period_end > _now()


class AnalysisRecord(Base):
    __tablename__ = "analysis_records"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), index=True, nullable=False)
    modality: Mapped[str] = mapped_column(String(20), nullable=False)  # "speech", "image", ...
    status: Mapped[str] = mapped_column(String(20), default="complete")  # complete | queued | failed
    result_json: Mapped[dict | None] = mapped_column(EncryptedJSON, nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)

    user: Mapped[User] = relationship(back_populates="analyses")


class UploadedFile(Base):
    """Raw uploaded content pending or supporting analysis. Speech audio
    is NOT stored here by default (see ALZDX_KEEP_UPLOADED_AUDIO -- the
    speech pipeline processes in a temp file and deletes it). This table
    is for modalities without an analysis pipeline yet (e.g. images for
    the not-yet-built Clock Drawing Test), so uploads aren't lost while
    Milestone 3 is being built, and for anyone who explicitly opts in to
    keeping audio.
    """

    __tablename__ = "uploaded_files"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), index=True, nullable=False)
    modality: Mapped[str] = mapped_column(String(20), nullable=False)
    original_filename: Mapped[str] = mapped_column(String(255))
    content_type: Mapped[str] = mapped_column(String(100))
    byte_size: Mapped[int] = mapped_column(Integer)
    blob: Mapped[bytes] = mapped_column(EncryptedBlob)
    status: Mapped[str] = mapped_column(String(30), default="queued_for_analysis")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)

    user: Mapped[User] = relationship(back_populates="uploads")


class AuditLogEntry(Base):
    """Append-only audit trail. Deliberately NOT encrypted -- it holds
    operational metadata (who did what, when) rather than clinical
    content, and needs to stay queryable for compliance review. Never put
    transcript text, image bytes, or other user content in `metadata_json`.
    """

    __tablename__ = "audit_log"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("users.id"), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(50), nullable=False)
    resource_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    resource_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    metadata_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now, index=True)
