"""Password hashing and JWT access tokens.

Password hashing uses bcrypt directly (not passlib -- passlib is in
maintenance mode and its bcrypt backend has had version-detection issues
with recent bcrypt releases). bcrypt has a 72-byte input limit; we encode
to UTF-8 and truncate defensively rather than erroring on unusually long
passphrases, since rejecting a long-but-valid password is worse UX than
silently ignoring bytes past 72.

JWT: short-lived (default 60 min) HMAC-signed access tokens. No refresh
token flow yet -- see docs/BILLING.md and CLAUDE.md for what's deliberately
out of scope in this pass.
"""

from __future__ import annotations

import datetime as dt

import bcrypt
import jwt

from alzheimers_detection.core.config import get_settings

_BCRYPT_MAX_BYTES = 72


def hash_password(plain_password: str) -> str:
    truncated = plain_password.encode("utf-8")[:_BCRYPT_MAX_BYTES]
    hashed = bcrypt.hashpw(truncated, bcrypt.gensalt())
    return hashed.decode("utf-8")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    truncated = plain_password.encode("utf-8")[:_BCRYPT_MAX_BYTES]
    try:
        return bcrypt.checkpw(truncated, hashed_password.encode("utf-8"))
    except ValueError:
        # Malformed hash in the DB (shouldn't happen outside of a bad
        # migration) -- treat as auth failure, not a 500.
        return False


def create_access_token(subject: str, extra_claims: dict | None = None) -> str:
    """`subject` is the user id (as a string). Encoded as the standard
    JWT `sub` claim."""
    settings = get_settings()
    now = dt.datetime.now(dt.timezone.utc)
    payload = {
        "sub": subject,
        "iat": now,
        "exp": now + dt.timedelta(minutes=settings.jwt_access_token_expire_minutes),
        "purpose": "access",
    }
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


def create_twofa_pending_token(subject: str) -> str:
    """A short-lived (5 min) token issued after a correct password when the
    account has 2FA enabled. It carries purpose="twofa_pending" so it can
    NOT be used as a normal access token, get_current_user rejects any
    token whose purpose isn't "access". Its only valid use is being
    exchanged at /login/2fa for a real access token."""
    settings = get_settings()
    now = dt.datetime.now(dt.timezone.utc)
    payload = {
        "sub": subject,
        "iat": now,
        "exp": now + dt.timedelta(minutes=5),
        "purpose": "twofa_pending",
    }
    return jwt.encode(payload, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


class TokenError(ValueError):
    pass


def decode_access_token(token: str) -> dict:
    settings = get_settings()
    try:
        return jwt.decode(token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
    except jwt.ExpiredSignatureError as e:
        raise TokenError("Token has expired.") from e
    except jwt.InvalidTokenError as e:
        raise TokenError("Token is invalid.") from e
