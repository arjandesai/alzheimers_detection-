"""Consistent audit-log writes.

Every route that touches a user's account, subscription, or analysis
records should call `record_audit_event` rather than writing an
`AuditLogEntry` inline -- keeps the field set consistent and makes it
easy to grep for every audit call site during a compliance review.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from alzheimers_detection.core.models import AuditLogEntry


def record_audit_event(
    db: Session,
    *,
    action: str,
    user_id: str | None = None,
    resource_type: str | None = None,
    resource_id: str | None = None,
    metadata: dict | None = None,
) -> AuditLogEntry:
    entry = AuditLogEntry(
        user_id=user_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        metadata_json=metadata,
    )
    db.add(entry)
    db.flush()  # get entry.id populated without needing a full commit here
    return entry
