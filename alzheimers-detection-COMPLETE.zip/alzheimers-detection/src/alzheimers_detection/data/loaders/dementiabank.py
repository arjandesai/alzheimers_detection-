"""Loader for locally-held DementiaBank / Pitt Corpus CHAT (.cha) files.

IMPORTANT -- READ BEFORE USING:
This module does NOT download, embed, redistribute, or ship any
DementiaBank/Pitt Corpus data. That corpus is access-controlled by
TalkBank and requires registration and approval
(see https://dementia.talkbank.org and https://talkbank.org/share/rules.html).
Nothing in this repository or its CI includes DementiaBank data, and no
contributor should commit any .cha/.mp3 files from that corpus to this
repo -- that would violate TalkBank's data use rules.

What this module IS for: once *you* have your own approved access and
have placed CHAT-format transcript files in a local, gitignored directory
(see `.gitignore` -- `data/` is excluded), this loader parses that CHAT
format into the same Transcript/Word shape produced by
speech/transcription.py, so the rest of the pipeline (feature extraction,
scoring) can run identically over real corpus data or over
locally-recorded audio. Point ALZDX_DATA_DIR (see core/config.py) at your
approved local copy.

CHAT format reference: https://talkbank.org/manuals/CHAT.pdf
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from alzheimers_detection.speech.schemas import Transcript, Word

# CHAT timestamps appear inline as e.g. "•515_890•" (bullet-delimited,
# start_end in milliseconds) attached to an utterance.
_TIMESTAMP_RE = re.compile(r"\x15(\d+)_(\d+)\x15")
_SPEAKER_LINE_RE = re.compile(r"^\*(?P<speaker>[A-Z]{3}):\t(?P<text>.*)$")


@dataclass
class ChatUtterance:
    speaker: str
    text: str
    start_ms: int | None
    end_ms: int | None


class DementiaBankParseError(ValueError):
    """Raised when a .cha file doesn't match the expected CHAT structure."""


def parse_chat_file(path: Path) -> list[ChatUtterance]:
    """Parse a single CHAT (.cha) transcript into speaker-tagged utterances.

    This is a minimal parser covering the subset of CHAT syntax needed for
    speaker turns + inline millisecond timestamps. It does NOT attempt to
    parse the full CHAT annotation grammar (error codes, retracing markers,
    morphological tiers, etc.) -- see docs/DATASETS.md limitations. For
    research requiring full CHAT fidelity, use TalkBank's own `pylangacq`
    or CLAN tools instead of this loader.
    """
    if not path.exists():
        raise DementiaBankParseError(f"File not found: {path}")

    utterances: list[ChatUtterance] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            match = _SPEAKER_LINE_RE.match(line.rstrip("\n"))
            if not match:
                continue
            speaker = match.group("speaker")
            raw_text = match.group("text")

            ts_match = _TIMESTAMP_RE.search(raw_text)
            start_ms = end_ms = None
            if ts_match:
                start_ms, end_ms = int(ts_match.group(1)), int(ts_match.group(2))
                raw_text = _TIMESTAMP_RE.sub("", raw_text)

            clean_text = raw_text.strip()
            if clean_text:
                utterances.append(ChatUtterance(speaker=speaker, text=clean_text, start_ms=start_ms, end_ms=end_ms))

    if not utterances:
        raise DementiaBankParseError(f"No parseable utterances found in {path} -- is this a valid CHAT file?")

    return utterances


def chat_utterances_to_transcript(
    utterances: list[ChatUtterance],
    participant_speaker_code: str = "PAR",
) -> Transcript:
    """Build a Transcript from parsed utterances, keeping only the
    participant's speech (excludes investigator/interviewer turns,
    conventionally coded "INV" in DementiaBank).

    Note: this produces utterance-level, not word-level, timestamps unless
    the source .cha file has word-level timing bullets, which most
    DementiaBank Pitt transcripts do not. `Word.start`/`Word.end` are set
    to the enclosing utterance's bounds as an approximation -- pause
    detection on DementiaBank-derived transcripts is therefore coarser
    than on freshly-recorded audio run through speech/transcription.py.
    This is documented in pipeline.LIMITATIONS when this loader is the
    Transcript source.
    """
    participant_utts = [u for u in utterances if u.speaker == participant_speaker_code]
    if not participant_utts:
        raise DementiaBankParseError(
            f"No utterances found for speaker code '{participant_speaker_code}'. "
            f"Speakers present: {sorted({u.speaker for u in utterances})}"
        )

    words: list[Word] = []
    text_parts: list[str] = []
    for utt in participant_utts:
        text_parts.append(utt.text)
        start = (utt.start_ms or 0) / 1000
        end = (utt.end_ms or (utt.start_ms or 0) + 1000) / 1000
        tokens = utt.text.split()
        if not tokens:
            continue
        span = (end - start) / len(tokens) if tokens else 0
        for i, tok in enumerate(tokens):
            words.append(Word(text=tok, start=start + i * span, end=start + (i + 1) * span))

    last_end = words[-1].end if words else 0.0
    return Transcript(
        text=" ".join(text_parts),
        words=words,
        language="en",
        audio_duration_seconds=last_end,
        asr_backend="dementiabank_chat_transcript",
        asr_model="human-transcribed",
    )


def load_transcript(path: Path, participant_speaker_code: str = "PAR") -> Transcript:
    """Convenience one-shot: parse a .cha file straight to a Transcript."""
    utterances = parse_chat_file(path)
    return chat_utterances_to_transcript(utterances, participant_speaker_code=participant_speaker_code)
