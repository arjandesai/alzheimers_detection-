"""CLAP (Contrastive Language-Audio Pretraining) audio embeddings.

Grounding: Elizalde et al., "CLAP: Learning Audio Concepts From Natural
Language Supervision" (ICASSP 2023) introduced CLAP; using CLAP embeddings
specifically for dementia/cognitive-decline detection is exploratory, not
an established baseline the way openSMILE eGeMAPS is -- see "Dementia
Insights: A Context-Based MultiModal Approach" (arXiv:2503.01226), which
uses CLAP among several pretrained audio/text encoders for this task.
Treat CLAP features here the way docs/BIOMARKERS.md treats them:
Exploratory confidence, not Established.

Model choice: laion/clap-htsat-unfused via Hugging Face Transformers'
ClapModel. Apache-2.0 licensed (unlike openSMILE's dual license -- see
opensmile_features.py docstring), so no separate commercial-use
restriction applies to this half of the fused feature vector. 512-dim
audio embedding, L2-normalized by the model itself.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

CLAP_EMBEDDING_DIM = 512
_DEFAULT_MODEL_NAME = "laion/clap-htsat-unfused"
_CLAP_SAMPLE_RATE = 48_000  # what the pretrained HTSAT audio tower expects


class ClapNotInstalled(RuntimeError):
    pass


def _require_clap_deps():
    try:
        import torch  # noqa: F401
        from transformers import ClapModel, ClapProcessor
    except ImportError as e:
        raise ClapNotInstalled(
            "torch/transformers are not installed. Install the 'ml' extra: "
            "pip install 'alzheimers-detection[ml]'"
        ) from e
    return ClapModel, ClapProcessor


class ClapEmbedder:
    """Loads the CLAP model once and reuses it across calls -- constructing
    this per-file would re-download/re-load ~600MB of weights repeatedly,
    which is exactly the kind of mistake that makes a training script
    that should take minutes take hours.
    """

    def __init__(self, model_name: str = _DEFAULT_MODEL_NAME, device: str = "cpu"):
        self.model_name = model_name
        self.device = device
        self._model = None
        self._processor = None

    def _load(self):
        if self._model is None:
            ClapModel, ClapProcessor = _require_clap_deps()
            self._model = ClapModel.from_pretrained(self.model_name).to(self.device)
            self._model.eval()
            self._processor = ClapProcessor.from_pretrained(self.model_name)
        return self._model, self._processor

    def embed_file(self, audio_path: Path) -> np.ndarray:
        """Return a (512,) L2-normalized audio embedding for one file."""
        model, processor = self._load()  # raises ClapNotInstalled first if torch/transformers are missing

        import soundfile as sf
        import torch
        signal, sr = sf.read(str(audio_path))
        if signal.ndim > 1:  # downmix stereo to mono
            signal = signal.mean(axis=1)
        if sr != _CLAP_SAMPLE_RATE:
            signal = _resample(signal, sr, _CLAP_SAMPLE_RATE)

        inputs = processor(audios=signal, sampling_rate=_CLAP_SAMPLE_RATE, return_tensors="pt")
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        with torch.inference_mode():
            audio_features = model.get_audio_features(**inputs)
        return audio_features.squeeze(0).cpu().numpy().astype(np.float32)

    def embed_batch(self, audio_paths: list[Path]) -> np.ndarray:
        """Convenience loop, not a true batched forward pass -- fine for
        dataset-prep scripts run once; not meant for low-latency serving.
        """
        return np.stack([self.embed_file(p) for p in audio_paths])


def _resample(signal: np.ndarray, orig_sr: int, target_sr: int) -> np.ndarray:
    """Simple polyphase resampling via scipy, avoiding an extra
    dependency (e.g. librosa/torchaudio) just for this one operation.
    """
    from scipy.signal import resample_poly
    from math import gcd

    g = gcd(orig_sr, target_sr)
    up, down = target_sr // g, orig_sr // g
    return resample_poly(signal, up, down).astype(np.float32)
