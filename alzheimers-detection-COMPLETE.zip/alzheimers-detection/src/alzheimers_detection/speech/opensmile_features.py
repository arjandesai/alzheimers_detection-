"""openSMILE-based acoustic feature extraction.

This is a separate, richer feature family from acoustic_features.py's
hand-rolled timing/pitch features. Where acoustic_features.py computes a
small, fully-interpretable set of measures for the explainable pipeline
report, this module extracts the full eGeMAPS / ComParE functional
feature sets via the official `opensmile` Python wrapper -- these are the
standard baseline features in the ADReSS/ADReSSo speech literature, used
directly as reported: eGeMAPS (88 functionals) and ComParE_2016 (6373
functionals) extracted with openSMILE were the acoustic baseline in
multiple published ADReSS-benchmark studies, including the original
ADReSS Challenge paper (Luz et al., 2020, "Alzheimer's Dementia
Recognition through Spontaneous Speech: The ADReSS Challenge",
arXiv:2004.06833) and later work combining eGeMAPS+ComParE+EmoBase into a
single ~6900-7400 feature space (arXiv:2502.03484).

These functionals feed the trainable classifier in `ml/`, not the
rule-based Milestone-1 pipeline in `speech/pipeline.py` -- keep that
separation. A learned model over thousands of correlated functionals is
exactly the kind of thing that needs held-out validation before its
outputs mean anything; it does not belong in the transparent,
per-feature-explainable report path.

IMPORTANT LICENSING NOTE: openSMILE is dual-licensed. The open-source
build used by the `opensmile` PyPI package is free for private, research,
and educational use, but its license does NOT permit use in a commercial
product without a separate commercial license from audEERING
(https://www.audeering.com). This project has a paid ($5/month)
subscription tier (see docs/BILLING.md) -- if openSMILE-derived features
are ever used to serve *paying* users in production, get a commercial
license first. Don't treat this module as clear for that use just because
it's "open source". See docs/TRAINING.md for the fuller discussion.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

EGEMAPS_DIM = 88
COMPARE_DIM = 6373


class OpenSmileNotInstalled(RuntimeError):
    pass


def _require_opensmile():
    try:
        import opensmile
    except ImportError as e:
        raise OpenSmileNotInstalled(
            "The 'opensmile' package is not installed. Install the 'ml' extra: "
            "pip install 'alzheimers-detection[ml]'. Note this pulls in the "
            "openSMILE binaries, which are free for research/non-commercial "
            "use only -- see this module's docstring before using in production."
        ) from e
    return opensmile


_SMILE_CACHE: dict[str, object] = {}


def _get_extractor(feature_set: str):
    """Cache the Smile extractor object per feature set -- constructing it
    loads/parses openSMILE's config files, which is wasteful to repeat
    per-file when extracting features over a whole dataset.
    """
    if feature_set not in _SMILE_CACHE:
        opensmile = _require_opensmile()
        fs = {
            "eGeMAPSv02": opensmile.FeatureSet.eGeMAPSv02,
            "ComParE_2016": opensmile.FeatureSet.ComParE_2016,
        }[feature_set]
        _SMILE_CACHE[feature_set] = opensmile.Smile(
            feature_set=fs,
            feature_level=opensmile.FeatureLevel.Functionals,
        )
    return _SMILE_CACHE[feature_set]


def extract_egemaps(audio_path: Path) -> np.ndarray:
    """88-dimensional eGeMAPSv02 functional feature vector. This is the
    minimal, physiologically-motivated set (F0, jitter/shimmer, formants,
    spectral slope, etc. as summary statistics) used as a standard
    baseline across the ADReSS literature cited in this module's docstring.
    """
    smile = _get_extractor("eGeMAPSv02")
    df = smile.process_file(str(audio_path))
    return df.to_numpy().reshape(-1).astype(np.float32)


def extract_compare(audio_path: Path) -> np.ndarray:
    """6373-dimensional ComParE_2016 functional feature vector -- the
    large, high-dimensional feature set from the same literature. Expect
    this to need feature selection/dimensionality reduction before
    feeding a small classifier trained on a dataset the size of ADReSS
    (~150-200 samples); see docs/TRAINING.md.
    """
    smile = _get_extractor("ComParE_2016")
    df = smile.process_file(str(audio_path))
    return df.to_numpy().reshape(-1).astype(np.float32)


def feature_names(feature_set: str = "eGeMAPSv02") -> list[str]:
    smile = _get_extractor(feature_set)
    return list(smile.feature_names)
