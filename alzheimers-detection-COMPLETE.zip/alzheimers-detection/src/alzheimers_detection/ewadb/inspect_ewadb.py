"""Inspect an EWA-DB download and report its ACTUAL structure.

Run this FIRST, before training, on your downloaded EWA-DB folder. It
doesn't assume any particular layout, it walks whatever you point it at
and tells you: the folder depth, where JSON/WAV files live, what keys the
JSON files actually contain, and where numeric feature blocks (GeMAPS
etc.) are nested. The loader (ewadb_dataset.py) uses the same discovery
logic, so if this inspector finds features, the loader will too.

Usage:
    python -m alzheimers_detection.ewadb.inspect_ewadb --root /path/to/ewa-db

Why this exists: EWA-DB is redistributed in several forms (Zenodo, ELRA,
Kaggle mirrors), and the exact folder nesting and JSON key names vary
between them. Rather than hardcode one release's layout and fail on the
others, this reports the real layout so training just works.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path


def _walk_summary(root: Path, max_depth: int = 4) -> None:
    print(f"\n=== FOLDER STRUCTURE (up to depth {max_depth}) ===")
    root = root.resolve()
    shown = 0
    for path in sorted(root.rglob("*")):
        if not path.is_dir():
            continue
        depth = len(path.relative_to(root).parts)
        if depth > max_depth:
            continue
        n_files = sum(1 for c in path.iterdir() if c.is_file())
        print("  " * depth + f"{path.name}/  ({n_files} files)")
        shown += 1
        if shown > 120:
            print("  ... (truncated)")
            break


def _file_type_census(root: Path) -> None:
    print("\n=== FILE TYPE CENSUS ===")
    ext_counts: Counter[str] = Counter()
    for p in root.rglob("*"):
        if p.is_file():
            ext_counts[p.suffix.lower() or "(no ext)"] += 1
    for ext, n in ext_counts.most_common():
        print(f"  {ext:12s} {n}")


def _find_numeric_blocks(obj, prefix="", found=None, depth=0):
    """Recursively locate dicts of mostly-numeric values inside a JSON
    object, returning (jsonpath, n_numeric_keys) for each candidate
    feature block. This is what lets the loader find GeMAPS features no
    matter what the surrounding structure calls them."""
    if found is None:
        found = []
    if depth > 6:
        return found
    if isinstance(obj, dict):
        numeric = [k for k, v in obj.items() if isinstance(v, (int, float))]
        if len(numeric) >= 5:  # a plausible feature block
            found.append((prefix or "(root)", len(numeric), numeric[:5]))
        for k, v in obj.items():
            _find_numeric_blocks(v, f"{prefix}.{k}" if prefix else k, found, depth + 1)
    elif isinstance(obj, list) and obj and isinstance(obj[0], dict):
        _find_numeric_blocks(obj[0], f"{prefix}[0]", found, depth + 1)
    return found


def _inspect_sample_jsons(root: Path, n_samples: int = 3) -> None:
    print("\n=== SAMPLE JSON INSPECTION ===")
    json_files = list(root.rglob("*.json"))
    print(f"total JSON files: {len(json_files)}")
    if not json_files:
        print("  NO JSON FILES FOUND. If features live in CSV/txt instead, tell the assistant.")
        return

    for jf in json_files[:n_samples]:
        try:
            obj = json.loads(jf.read_text(encoding="utf-8"))
        except Exception as e:  # noqa: BLE001
            print(f"\n  {jf.name}: could not parse ({e})")
            continue
        print(f"\n  FILE: {jf.relative_to(root)}")
        if isinstance(obj, dict):
            print(f"  top-level keys: {list(obj.keys())[:20]}")
        blocks = _find_numeric_blocks(obj)
        if blocks:
            print("  numeric feature blocks found:")
            for path_str, n, sample in blocks:
                print(f"    - at '{path_str}': {n} numeric values, e.g. {sample}")
        else:
            print("  no numeric feature block of >=5 values found in this JSON")


def _guess_group_folders(root: Path) -> None:
    print("\n=== TOP-LEVEL FOLDERS (candidate clinical groups) ===")
    top = sorted(p.name for p in root.iterdir() if p.is_dir())
    print(f"  {top}")
    print("  (The loader maps AD/Alzheimer -> patient, HC/control/healthy -> control,")
    print("   and skips MCI/PD. If your group folders use different names, the loader")
    print("   matches case-insensitively and by substring.)")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--root", type=Path, required=True, help="Path to the extracted EWA-DB folder")
    p.add_argument("--max-depth", type=int, default=4)
    args = p.parse_args(argv)

    root = args.root
    if not root.exists():
        raise SystemExit(f"Path not found: {root}")

    # If they pointed at a folder that just contains the real root, descend.
    entries = [e for e in root.iterdir() if e.is_dir()]
    if len(entries) == 1 and not any(f.suffix == ".json" for f in root.rglob("*.json") if len(f.relative_to(root).parts) <= 2):
        print(f"[note] '{root}' contains a single subfolder '{entries[0].name}'. "
              f"You may need to point --root at that instead.")

    print(f"Inspecting EWA-DB at: {root.resolve()}")
    _file_type_census(root)
    _guess_group_folders(root)
    _walk_summary(root, max_depth=args.max_depth)
    _inspect_sample_jsons(root)

    print("\n=== NEXT STEP ===")
    print("If numeric feature blocks were found above, run training directly:")
    print("  python -m alzheimers_detection.ewadb.train_ewadb --root <this same path> --epochs 20")
    print("If NO features were found, or groups look unusual, paste this output back to the assistant.")
    return 0


if __name__ == "__main__":
    import sys

    sys.exit(main())
