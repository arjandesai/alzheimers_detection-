"""Loader for the EWA-DB Slovak neurodegenerative-speech database.

EWA-DB (Rusko et al., "Slovak database of speech affected by
neurodegenerative diseases", Scientific Data 11:1320, 2024;
Zenodo record 10952480). 1649 speakers total; per the paper, audio is
published for 1003 of them, and per-speaker JSON files carry pre-computed
features including openSMILE with GeMAPS settings and Neurospeech
features.

THREE THINGS TO KNOW BEFORE USING THIS (all from the paper):

1. SEVERE CLASS IMBALANCE. The AD group is tiny: N=27 AD patients, N=30
   MCI, against 1323 healthy controls. That is roughly a 48:1 imbalance
   for AD-vs-HC. A model that always predicts "healthy" scores ~98%
   accuracy while catching zero AD cases. This loader and the training
   script that uses it therefore NEVER report bare accuracy as the
   headline metric, balanced accuracy, per-class recall, and AUC are
   what matter here. See train_ewadb.py.

2. SLOVAK LANGUAGE. English-tuned linguistic features (filler-word lists,
   pronoun-to-noun ratios from speech/linguistic_features.py) do NOT
   transfer. This loader reads the LANGUAGE-INDEPENDENT acoustic GeMAPS
   features that EWA-DB ships pre-computed. It does not attempt Slovak
   NLP.

3. NOT SHIPPED HERE. This repo contains no EWA-DB data. Download it from
   Zenodo (10952480) or ELRA (ELRA-S0489), point this loader at the
   extracted EWA-DB folder. See docs/EWADB.md.

Structure this loader expects (from the paper's "Structure of EWA-DB"):
    EWA-DB/
      <group>/                    # one folder per clinical group + controls
        <speaker_code>/           # randomly generated per-speaker code
          phonation/  pataka/  naming/  picture description/
            *.json                # ASR, annotation, speaker info, GeMAPS, ...
            *.wav                 # only if the speaker consented to audio

Because EWA-DB's exact JSON key layout can vary by release, this loader is
defensive: it searches each speaker's JSON files for a GeMAPS feature
block under several plausible keys and records which speakers it could and
could not parse, rather than crashing on the first surprise. If your
release nests the features differently, adjust GEMAPS_KEYS below, the rest
of the pipeline stays the same.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

# Group-folder name -> label. Names vary by release; we match
# case-insensitively and also accept common abbreviations. Anything that
# maps to None is skipped (e.g. PD, or AD+PD combined, which are out of
# scope for an AD-vs-HC task).
GROUP_LABELS: dict[str, int | None] = {
    "hc": 0, "healthy": 0, "control": 0, "controls": 0, "healthy_controls": 0,
    "ad": 1, "alzheimer": 1, "alzheimers": 1, "alzheimer_disease": 1,
    # Explicitly out of scope for AD-vs-HC (kept here so they're skipped, not guessed):
    "mci": None, "pd": None, "parkinson": None, "parkinsons": None, "ad_pd": None,
}

# JSON keys under which a GeMAPS feature dict/list might live. Tried FIRST
# (as a fast path / to prefer the right block when several exist). If none
# match, the loader falls back to auto-discovering ANY sufficiently large
# numeric block anywhere in the JSON, so it adapts to release variations.
GEMAPS_KEYS = ("gemaps", "GeMAPS", "egemaps", "eGeMAPS", "opensmile", "openSMILE",
               "os_gemaps", "acoustic_gemaps", "features", "acoustic_features")

# A numeric block needs at least this many numeric values to count as a
# feature vector (guards against picking up small metadata dicts like
# {"age": 70, "mmse": 24}).
_MIN_FEATURE_BLOCK = 8


class EwaLoadError(ValueError):
    pass


@dataclass
class EwaData:
    X: np.ndarray                      # (n_speakers, n_features)
    y: np.ndarray                      # 1 = AD, 0 = healthy
    speaker_ids: list[str]
    feature_names: list[str]
    skipped: list[tuple[str, str]] = field(default_factory=list)  # (speaker, reason)


def _label_for_group(group_folder_name: str) -> int | None:
    key = group_folder_name.strip().lower().replace(" ", "_").replace("-", "_")
    # exact match first, then substring (folder might be "AD_patients" etc.)
    if key in GROUP_LABELS:
        return GROUP_LABELS[key]
    for k, v in GROUP_LABELS.items():
        if k in key:
            return v
    return None  # unknown group -> skip, never guess


def _flatten_numeric(block: dict) -> dict[str, float]:
    return {k: float(v) for k, v in block.items() if isinstance(v, (int, float)) and not isinstance(v, bool)}


def _discover_numeric_blocks(obj, prefix="", found=None, depth=0):
    """Recursively find every dict of numeric values in a JSON object.
    Returns a list of (jsonpath, flat_feature_dict). This is what makes
    the loader robust to how a given EWA-DB release nests its features:
    we don't need to know the key name in advance."""
    if found is None:
        found = []
    if depth > 6:
        return found
    if isinstance(obj, dict):
        flat = _flatten_numeric(obj)
        if len(flat) >= _MIN_FEATURE_BLOCK:
            found.append((prefix or "(root)", flat))
        for k, v in obj.items():
            _discover_numeric_blocks(v, f"{prefix}.{k}" if prefix else k, found, depth + 1)
    elif isinstance(obj, list) and obj and isinstance(obj[0], dict):
        _discover_numeric_blocks(obj[0], f"{prefix}[0]", found, depth + 1)
    return found


def _extract_gemaps_from_json(obj: dict) -> dict[str, float] | None:
    """Find a flat {feature_name: value} feature dict inside one JSON object.

    Strategy: (1) try the known GEMAPS_KEYS for a clean, named hit;
    (2) if none match, auto-discover the LARGEST numeric block anywhere in
    the JSON (GeMAPS is 88 values, eGeMAPS 88, ComParE 6373, so the
    feature vector is almost always the biggest numeric block, far bigger
    than any metadata dict). Returns None only if nothing numeric of
    sufficient size exists."""
    if not isinstance(obj, dict):
        return None

    # Fast path: a recognized key holding a numeric dict.
    for key in GEMAPS_KEYS:
        if key in obj and isinstance(obj[key], dict):
            flat = _flatten_numeric(obj[key])
            if len(flat) >= _MIN_FEATURE_BLOCK:
                return flat

    # Fallback: auto-discover. Pick the largest numeric block found.
    blocks = _discover_numeric_blocks(obj)
    if not blocks:
        return None
    blocks.sort(key=lambda pf: len(pf[1]), reverse=True)
    return blocks[0][1]


def _gemaps_for_speaker(speaker_dir: Path) -> dict[str, float] | None:
    """Aggregate GeMAPS features for one speaker.

    A speaker has several task folders, each possibly with a JSON carrying
    GeMAPS. We use the picture-description task's features when available
    (the connected-speech task most associated with AD in the literature),
    and fall back to averaging across whatever tasks do have GeMAPS. This
    keeps one fixed-length vector per speaker regardless of which tasks are
    present.
    """
    # Prefer picture description; the paper names those files big3..big7.
    preferred_dirs = [d for d in speaker_dir.iterdir() if d.is_dir()
                      and "picture" in d.name.lower() or "description" in d.name.lower()]
    search_dirs = preferred_dirs or [d for d in speaker_dir.iterdir() if d.is_dir()]

    collected: list[dict[str, float]] = []
    for d in search_dirs:
        for jf in d.glob("*.json"):
            try:
                obj = json.loads(jf.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            g = _extract_gemaps_from_json(obj)
            if g:
                collected.append(g)

    if not collected:
        return None

    # Average across collected task-level GeMAPS dicts, over the shared keys.
    common = set(collected[0])
    for g in collected[1:]:
        common &= set(g)
    if not common:
        return None
    return {k: float(np.mean([g[k] for g in collected])) for k in sorted(common)}


def load_ewadb(root: Path, task: str = "auto") -> EwaData:
    """Walk an extracted EWA-DB folder and build (X, y) for AD vs HC.

    Only AD and healthy-control speakers are included; MCI/PD/AD+PD are
    skipped (recorded in `.skipped`), since this is an AD-vs-HC task. Use a
    separate call/config if you later want MCI-vs-HC.
    """
    root = Path(root)
    if not root.exists():
        raise EwaLoadError(
            f"EWA-DB root not found at {root}. This dataset is not shipped with the repo; "
            "download it from Zenodo (record 10952480) or ELRA (ELRA-S0489) and pass the "
            "extracted folder path. See docs/EWADB.md."
        )

    speaker_features: list[dict[str, float]] = []
    labels: list[int] = []
    ids: list[str] = []
    skipped: list[tuple[str, str]] = []

    for group_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        label = _label_for_group(group_dir.name)
        if label is None:
            skipped.append((group_dir.name, "group not AD or HC (skipped for AD-vs-HC task)"))
            continue
        for speaker_dir in sorted(p for p in group_dir.iterdir() if p.is_dir()):
            g = _gemaps_for_speaker(speaker_dir)
            if g is None:
                skipped.append((speaker_dir.name, "no GeMAPS features found (audio consent not given?)"))
                continue
            speaker_features.append(g)
            labels.append(label)
            ids.append(speaker_dir.name)

    if not speaker_features:
        raise EwaLoadError(
            "No AD/HC speakers with GeMAPS features were found. Check the folder structure and "
            "the GEMAPS_KEYS in ewadb_dataset.py against your EWA-DB release. "
            f"({len(skipped)} entries skipped.)"
        )

    # Align to the intersection of feature names across all speakers, so X
    # is rectangular even if releases differ slightly per speaker.
    common_feats = set(speaker_features[0])
    for g in speaker_features[1:]:
        common_feats &= set(g)
    if not common_feats:
        raise EwaLoadError("Speakers had GeMAPS blocks but no feature name was shared across all of them.")
    feature_names = sorted(common_feats)

    X = np.array([[g[f] for f in feature_names] for g in speaker_features], dtype=np.float64)
    y = np.array(labels, dtype=np.int64)

    return EwaData(X=X, y=y, speaker_ids=ids, feature_names=feature_names, skipped=skipped)
