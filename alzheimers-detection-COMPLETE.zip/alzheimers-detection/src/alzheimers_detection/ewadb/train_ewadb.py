"""Train an AD-vs-healthy classifier on EWA-DB GeMAPS features.

This script is built around ONE dominant fact: EWA-DB has ~27 AD patients
vs ~1300 healthy controls (see ewadb_dataset.py and docs/EWADB.md). That
~48:1 imbalance shapes every choice here:

- ACCURACY IS NOT THE HEADLINE METRIC. A model predicting "healthy" for
  everyone gets ~98% accuracy and catches zero AD cases. We report
  BALANCED ACCURACY, per-class RECALL (especially AD recall / sensitivity),
  and AUC. Raw accuracy is printed only alongside these, clearly marked as
  misleading on its own.
- CLASS WEIGHTING. Models use class_weight='balanced' so the 27 AD cases
  aren't drowned out by 1300 controls.
- STRATIFIED CROSS-VALIDATION, not a single split. With only ~27 positives,
  a single test split might contain 5 AD patients; one misclassification
  swings "accuracy" by whole points. Stratified k-fold keeps AD cases
  spread across folds and averages over them. Even so, expect WIDE error
  bars, honestly reported.
- HONEST EXPECTATION. Do not expect DARWIN-like numbers. Detecting AD from
  27 examples is hard. A respectable result here is decent AUC / balanced
  accuracy with visible variance, not a shiny 95%. If this script prints
  accuracy that looks great but AD-recall is near zero, that's the
  imbalance fooling you, and the output says so.

The MLP path honors the requested 20-epoch budget; a class-weighted
logistic-regression baseline is reported alongside because on ~27
positives a simple linear model is often as good as, and more stable than,
a neural net.
"""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import numpy as np


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--root", type=Path, required=True, help="Path to the extracted EWA-DB folder")
    p.add_argument("--epochs", type=int, default=20, help="MLP epochs (default 20)")
    p.add_argument("--folds", type=int, default=5, help="Stratified CV folds (default 5)")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--output-dir", type=Path, default=Path("./runs/ewadb"))
    return p


def run(args: argparse.Namespace) -> dict:
    from sklearn.exceptions import ConvergenceWarning
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import (
        balanced_accuracy_score,
        recall_score,
        roc_auc_score,
    )
    from sklearn.model_selection import StratifiedKFold
    from sklearn.neural_network import MLPClassifier
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler

    from alzheimers_detection.ewadb.ewadb_dataset import load_ewadb

    data = load_ewadb(args.root)
    n_ad = int((data.y == 1).sum())
    n_hc = int((data.y == 0).sum())
    ratio = (n_hc / n_ad) if n_ad else float("inf")
    print(f"[data] EWA-DB loaded: {len(data.y)} speakers ({n_ad} AD / {n_hc} HC), "
          f"{data.X.shape[1]} GeMAPS features")
    print(f"[data] class imbalance: {ratio:.1f} : 1 (HC : AD). {len(data.skipped)} entries skipped "
          f"(MCI/PD/no-audio).")
    if n_ad < 10:
        print(f"[WARNING] Only {n_ad} AD cases. Any metric here has very wide uncertainty; "
              f"treat results as exploratory, not conclusive.")

    # Baseline that must be beaten: always predict the majority (healthy).
    majority_acc = n_hc / len(data.y)
    print(f"[baseline] 'always predict healthy' accuracy = {majority_acc:.3f} "
          f"(balanced accuracy = 0.500, AD recall = 0.000). THIS is why raw accuracy lies here.")

    def evaluate_model(make_model, name: str) -> dict:
        skf = StratifiedKFold(n_splits=args.folds, shuffle=True, random_state=args.seed)
        bal_accs, ad_recalls, hc_recalls, aucs, raw_accs = [], [], [], [], []
        for tr, te in skf.split(data.X, data.y):
            m = make_model()
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", ConvergenceWarning)
                m.fit(data.X[tr], data.y[tr])
            pred = m.predict(data.X[te])
            try:
                prob = m.predict_proba(data.X[te])[:, 1]
                aucs.append(roc_auc_score(data.y[te], prob))
            except (AttributeError, ValueError):
                pass
            bal_accs.append(balanced_accuracy_score(data.y[te], pred))
            ad_recalls.append(recall_score(data.y[te], pred, pos_label=1, zero_division=0))
            hc_recalls.append(recall_score(data.y[te], pred, pos_label=0, zero_division=0))
            raw_accs.append((pred == data.y[te]).mean())

        result = {
            "model": name,
            "balanced_accuracy_mean": float(np.mean(bal_accs)),
            "balanced_accuracy_std": float(np.std(bal_accs)),
            "ad_recall_mean": float(np.mean(ad_recalls)),      # sensitivity: fraction of AD caught
            "hc_recall_mean": float(np.mean(hc_recalls)),      # specificity
            "auc_mean": float(np.mean(aucs)) if aucs else None,
            "raw_accuracy_mean": float(np.mean(raw_accs)),
        }
        auc_str = f"{result['auc_mean']:.3f}" if result["auc_mean"] is not None else "n/a"
        print(f"\n[{name}] balanced_acc = {result['balanced_accuracy_mean']:.3f} "
              f"+/- {result['balanced_accuracy_std']:.3f}")
        print(f"[{name}] AD recall (sensitivity) = {result['ad_recall_mean']:.3f}   "
              f"HC recall (specificity) = {result['hc_recall_mean']:.3f}   AUC = {auc_str}")
        print(f"[{name}] (raw accuracy = {result['raw_accuracy_mean']:.3f}  <- misleading alone; "
              f"compare to {majority_acc:.3f} majority baseline)")
        return result

    # Class-weighted logistic regression: stable, strong baseline on few positives.
    lr = evaluate_model(
        lambda: make_pipeline(
            StandardScaler(),
            LogisticRegression(class_weight="balanced", max_iter=1000, random_state=args.seed),
        ),
        "logreg (class-weighted)",
    )

    # MLP for the requested 20 epochs. Note: sklearn's MLPClassifier has no
    # class_weight param, so on this imbalance the logreg above is often the
    # more trustworthy number; the MLP is reported for the requested
    # epoch-based run, not because deeper is better on 27 positives.
    mlp = evaluate_model(
        lambda: make_pipeline(
            StandardScaler(),
            MLPClassifier(hidden_layer_sizes=(32,), max_iter=args.epochs, alpha=1e-2,
                          random_state=args.seed, early_stopping=False),
        ),
        f"mlp ({args.epochs} epochs)",
    )

    # Honest verdict
    best_bal = max(lr["balanced_accuracy_mean"], mlp["balanced_accuracy_mean"])
    if best_bal < 0.6:
        verdict = ("Balanced accuracy near chance (0.5). With ~27 AD cases this is a plausible, "
                   "honest outcome, the signal may simply be too thin in this language/feature set. "
                   "Not a failure of the code; a limit of the data.")
    elif best_bal > 0.9:
        verdict = ("Balanced accuracy > 0.9 on ~27 AD cases is suspiciously high. Check for leakage "
                   "(e.g. a speaker's tasks split across train and test, or a feature encoding group) "
                   "before trusting it.")
    else:
        verdict = ("Balanced accuracy in a plausible range for a small, imbalanced AD-vs-HC set. "
                   "Report it WITH its wide error bars and the AD-recall, never as bare accuracy.")
    print(f"\n[verdict] {verdict}")

    summary = {
        "dataset": "EWA-DB",
        "n_speakers": len(data.y),
        "n_ad": n_ad,
        "n_hc": n_hc,
        "imbalance_ratio_hc_to_ad": ratio,
        "n_features": int(data.X.shape[1]),
        "majority_baseline_accuracy": majority_acc,
        "logreg": lr,
        "mlp": mlp,
        "verdict": verdict,
        "note": "Slovak-language acoustic GeMAPS features only (language-independent). "
                "Severe class imbalance (~27 AD). Balanced accuracy / AD-recall / AUC are the "
                "real metrics; raw accuracy is misleading. Research use only, not a diagnostic.",
        "n_skipped": len(data.skipped),
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / "ewadb_results.json").open("w") as f:
        json.dump(summary, f, indent=2, default=float)
    print(f"\n[done] wrote {args.output_dir / 'ewadb_results.json'}")
    return summary


def main(argv: list[str] | None = None) -> int:
    args = _build_arg_parser().parse_args(argv)
    run(args)
    return 0


if __name__ == "__main__":
    import sys

    sys.exit(main())
