# Speech Biomarkers: What's Established vs. What's Exploratory

This tracks the evidence basis for each feature implemented in
`src/alzheimers_detection/speech/`. "Confidence" is a qualitative summary of
how consistently a direction of effect has been reported, not a formal
meta-analytic estimate, treat it as a starting point for literature review,
not a substitute for it.

| Feature | Direction reported in AD/MCI literature | Confidence | Notes |
|---|---|---|---|
| Speech rate (wpm) | Reduced vs. healthy controls | Established | One of the most replicated findings in spontaneous-speech AD studies |
| Pause frequency / long-pause ratio | Increased | Established | Associated with word-finding difficulty and reduced fluency |
| Articulation rate vs. speech rate gap | Widens (more pause-dominated) | Moderate | Less consistently isolated from overall speech rate across studies |
| Lexical diversity (TTR / MATTR) | Reduced | Established | Confounded by transcript length if raw TTR is used, MATTR preferred |
| Filler word rate | Increased | Moderate | Also affected by individual speaking style, not disease-specific alone |
| Pronoun-to-noun ratio | Increased | Moderate | Reflects "semantic emptying" of language; effect sizes vary across studies |
| Pitch variation (F0 std) | Reduced (flatter prosody) | Exploratory | Reported in some studies; less consistently replicated than timing features |
| Jitter / shimmer | Mixed findings | Exploratory | Primarily voice-quality/dysarthria markers; AD-specific signal is weaker and less established than in e.g. Parkinsonian speech |
| Repetition rate | Increased | Moderate | Requires careful distinction from normal disfluency; our regex-based detector is a coarse proxy (see Limitations) |
| openSMILE eGeMAPS (88-dim functionals) | Used as-is, not a single "direction" | Established (as a baseline feature set) | Standard acoustic baseline in the ADReSS Challenge itself (Luz et al., 2020, arXiv:2004.06833) and multiple follow-up studies (arXiv:2502.03484, arXiv:2402.01824) |
| openSMILE ComParE_2016 (6373-dim functionals) | Used as-is, not a single "direction" | Established (as a baseline feature set), but high-dimensional relative to typical ADReSS-scale sample sizes | Same literature as eGeMAPS above; combined eGeMAPS+ComParE+EmoBase feature spaces of ~7000+ dims are reported fused for classification (arXiv:2502.03484) -- expect to need feature selection or regularization, not raw use, on a ~150-200 sample dataset |
| CLAP audio embeddings (512-dim, laion/clap-htsat-unfused) | Used as-is (learned embedding, not a hand-designed direction) | Exploratory | CLAP itself (Elizalde et al., 2023, ICASSP) is a general audio-language foundation model, not dementia-specific; its application to dementia/cognitive-decline detection specifically is recent and comparatively less validated (see "Dementia Insights: A Context-Based MultiModal Approach", arXiv:2503.01226, which uses CLAP among several pretrained encoders) |

## Foundation-model context (why CLAP is one option among several)

A 2026 benchmarking study comparing foundation speech/language models for
ADRD (Alzheimer's Disease and Related Dementias) detection found the
Whisper-medium encoder outperformed both traditional acoustic
feature-based models and several other embedding models on their dataset
(sciencedirect.com/science/article/pii/S2561326X26003501; also see the
related PREPARE-challenge benchmarking work at arXiv:2506.11119, which
reported Whisper-medium at 0.731 accuracy / 0.802 AUC for 3-way HC/MCI/AD
classification). This project uses CLAP specifically because it was
requested and has direct precedent in dementia-detection literature (see
table above), not because it's shown to be the strongest available
embedding for this task -- Whisper-encoder embeddings are a reasonable
alternative worth benchmarking against once real training runs are
possible (see docs/TRAINING.md).

## How this maps to code

Each field in `speech/schemas.py::AcousticFeatures` and `::LinguisticFeatures`
carries a docstring summarizing the *direction* reported in the literature.
None of these are wired to a validated per-feature clinical threshold yet ,
the `_REFERENCE_RANGES` dict in `speech/pipeline.py` is explicitly marked as
an **unvalidated placeholder** pending either (a) published reference ranges
with proper citations, or (b) a validation pass against approved
DementiaBank/ADReSS data once access is available. Do not treat the current
ranges as clinically meaningful, they exist so the explainability plumbing
(risk bands, contributing-feature reports) has something to compute over
during early development.

## Regulatory framing

This document is a literature summary for engineering purposes, not a
clinical evidence dossier. An actual regulatory submission would need a
systematic literature review, formal effect-size/meta-analysis, and
validation on held-out clinical data, well beyond what a codebase README
can establish.
