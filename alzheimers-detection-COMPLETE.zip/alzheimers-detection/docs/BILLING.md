# Billing setup (Stripe, $5/month subscription)

The integration code in `core/billing.py` and `api/routes/billing.py` is
complete and correct. What turns it into a working paywall is entirely
configuration, not code. Follow these steps in order.

## 1. Create the Stripe objects

1. Create a [Stripe account](https://dashboard.stripe.com/register) if you
   don't have one. Use test mode for development.
2. In the Dashboard, create a **Product** (e.g. "Attend subscription") with
   a recurring **Price** of $5.00/month. Copy the Price ID (`price_...`).
3. Get your API keys from Developers → API keys: a secret key (`sk_test_...`)
   and a publishable key (`pk_test_...`).

## 2. Configure the webhook

The webhook is how Stripe tells this app "this person paid" or "this
person's card failed" -- without it, `subscription_status` never updates.

- **Local development**: install the [Stripe CLI](https://stripe.com/docs/stripe-cli),
  then run:
  ```bash
  stripe listen --forward-to localhost:8000/api/v1/billing/webhook
  ```
  This prints a `whsec_...` value -- use that as `ALZDX_STRIPE_WEBHOOK_SECRET`.
- **Production**: in the Dashboard, add an endpoint at
  `https://your-domain.com/api/v1/billing/webhook`, listening for at
  least: `checkout.session.completed`, `customer.subscription.created`,
  `customer.subscription.updated`, `customer.subscription.deleted`. Copy
  the signing secret it gives you into `ALZDX_STRIPE_WEBHOOK_SECRET`.

## 3. Set environment variables

```bash
ALZDX_STRIPE_SECRET_KEY=sk_test_...
ALZDX_STRIPE_PUBLISHABLE_KEY=pk_test_...
ALZDX_STRIPE_WEBHOOK_SECRET=whsec_...
ALZDX_STRIPE_PRICE_ID=price_...
ALZDX_BILLING_SUCCESS_URL=https://your-domain.com/dashboard.html?checkout=success
ALZDX_BILLING_CANCEL_URL=https://your-domain.com/pricing.html?checkout=cancelled
```

The frontend (`site/pricing.html`) needs `ALZDX_STRIPE_PUBLISHABLE_KEY`
too -- it's safe to expose client-side by design (that's what
"publishable" means), unlike the secret key.

## 4. How the flow works end to end

1. A logged-in user clicks "Subscribe" on the pricing page.
2. Frontend calls `POST /api/v1/billing/checkout-session` (requires a
   valid access token). Backend creates or reuses a Stripe Customer for
   that user, then creates a Checkout Session and returns its URL.
3. Frontend redirects the browser to that URL. The user enters payment
   details on Stripe's own hosted page -- **this app never sees or
   handles a card number**, which is both a security and PCI-compliance
   requirement, not a nicety.
4. On success, Stripe redirects back to `ALZDX_BILLING_SUCCESS_URL` *and*
   independently sends a `checkout.session.completed` /
   `customer.subscription.created` webhook to this app.
5. The webhook handler verifies the signature, looks up the user by
   `stripe_customer_id`, and calls `sync_subscription_from_stripe_object`
   to set `subscription_status = "active"` and the current period end.
6. From that point, any endpoint behind `require_active_subscription`
   (see `api/deps.py`) works for that user -- until Stripe sends a
   `customer.subscription.deleted` or a `.updated` event with a
   non-active status (payment failure, cancellation), at which point
   access is revoked automatically on the next webhook delivery.

Step 4 is important: **the redirect alone does not grant access.** Access
is granted only by the verified webhook. This means a user can't spoof
success by manually navigating to the success URL -- the signature check
in `billing.construct_webhook_event` is what makes the paywall actually
enforceable, not decorative.

## 5. Managing an existing subscription

`POST /api/v1/billing/portal` returns a URL to Stripe's hosted Billing
Portal, where a subscriber can update their card or cancel, without this
app building any of that UI. Cancellation flows back through the same
webhook path as step 5 above.

## What this does NOT include

- Free trials, proration, multiple pricing tiers, or annual billing --
  all straightforward Stripe Price/Checkout configuration if you want
  them later, just not built into this pass.
- Dunning emails / failed-payment retry logic beyond what Stripe's
  Smart Retries already does by default.
- Refund handling. Issue refunds from the Stripe Dashboard; there's no
  in-app refund flow.
