# Training the fusion classifier (openSMILE + CLAP)

## Read this first

**No model has been trained as part of building this pipeline, and no
training results, accuracy numbers, or metrics appear anywhere in this
repository.** The code in `src/alzheimers_detection/ml/` is a complete,
correct training pipeline, verified by:
- reviewing it against the real `opensmile` and `transformers` (CLAP)
  APIs, confirmed via their official documentation (cited below),
- syntax-checking every file,
- and independently re-deriving the resampling math (`clap_features.py`)
  in plain SciPy in the environment that wrote this, since torch itself
  couldn't be installed there.

It has **not** been executed end-to-end, because the environment that
wrote it has no network access (can't install `torch`/`transformers`/
`opensmile`, can't download the CLAP checkpoint), no GPU, and no access
to labeled AD/control audio, which is gated (see below). Running it is
the next step for whoever has that access and a compute environment --
not something achieved by writing the code.

If you see this document claim a specific accuracy or AUC number anywhere
else in this repo without a `run_summary.json` / `test_metrics.json` file
next to it to back that number up, treat that as an error and open an
issue -- it would mean someone fabricated a result, which is exactly the
failure mode this project has tried to avoid throughout (see CLAUDE.md's
"Hard rules").

## What the pipeline does

1. **Feature extraction** (`speech/opensmile_features.py`,
   `speech/clap_features.py`): for each audio file, extract an 88-dim
   openSMILE eGeMAPSv02 functional vector and/or a 512-dim CLAP
   (`laion/clap-htsat-unfused`) audio embedding. Concatenated together:
   a 600-dim fused feature vector per sample.
2. **Caching** (`ml/dataset.py::build_feature_cache`): each file's
   features are cached to `.npz` so re-running training doesn't redo the
   slow extraction step every time.
3. **Participant-level, stratified train/val split**
   (`ml/dataset.py::participant_level_split`): splits by participant, not
   recording, and balances AD/control across the split. Speaker-level
   leakage between train and validation is a well-known way to inflate
   apparent accuracy in this literature -- this function exists
   specifically to avoid that.
4. **Training** (`ml/train.py`): a small 3-layer MLP
   (`ml/model.py::FusionClassifier`) trained with Adam, cross-entropy
   loss, for **20 epochs by default** (`--epochs 20`), no early stopping
   unless you explicitly pass `--early-stopping-patience`. Per-epoch
   loss/accuracy/precision/recall/F1/AUC are printed and written to
   `metrics_history.csv`; the best checkpoint by validation loss is saved
   to `best_model.pt`.
5. **Evaluation** (`ml/evaluate.py`): loads a checkpoint and scores it
   against a separate held-out manifest (e.g. the official ADReSS test
   split, distributed separately from train), writing a confusion matrix
   and metrics to `test_metrics.json`.

## Prerequisites you have to provide

### 1. Data access
You need your own approved access to a labeled AD/control speech dataset
-- ADReSS or ADReSSo (recommended: purpose-built as a balanced ML
benchmark) or the extended DementiaBank Pitt Corpus. See
**docs/DATASETS.md** for exactly how to request access; none of it is
included in this repository or downloadable by any code here.

### 2. A manifest CSV
Build a CSV yourself, pointing at your own local copy of the audio:

```csv
participant_id,file_path,label
S001,/abs/path/to/S001.wav,0
S002,/abs/path/to/S002.wav,1
```

`label` is `0` for control, `1` for AD -- matching ADReSS's own `cc`
(control) / `cd` (cognitive decline) naming convention. One row per
participant. Keep train and test manifests separate if you're using the
official ADReSS train/test split (recommended, since it's what makes
your results comparable to published ADReSS Challenge numbers).

### 3. Environment
```bash
pip install -e ".[dev,ml]"
```
This pulls in `torch`, `transformers` (for CLAP), `opensmile`, and
`scikit-learn`. CPU works; a GPU makes the CLAP embedding extraction step
faster but isn't required for a dataset this size.

## Running it

```bash
# Extract + cache features only, to sanity-check the manifest before a
# full training run:
python -m alzheimers_detection.ml.train \
    --manifest /path/to/adress_train_manifest.csv \
    --cache-dir ./feature_cache \
    --extract-only

# Full training run, 20 epochs (the default -- explicit here for clarity):
python -m alzheimers_detection.ml.train \
    --manifest /path/to/adress_train_manifest.csv \
    --cache-dir ./feature_cache \
    --output-dir ./runs/adress-fusion-v1 \
    --epochs 20

# Evaluate the resulting checkpoint against the official held-out test set:
python -m alzheimers_detection.ml.evaluate \
    --checkpoint ./runs/adress-fusion-v1/best_model.pt \
    --manifest /path/to/adress_test_manifest.csv \
    --cache-dir ./feature_cache_test
```

## Licensing -- read before using in production

**openSMILE has a dual license.** The `opensmile` PyPI package (used for
eGeMAPS/ComParE extraction) wraps openSMILE binaries that are free for
private, research, and educational use, but its license explicitly
**prohibits use in a commercial product** without a separate commercial
license from audEERING (audeering.com). This project has a paid
subscription tier (see docs/BILLING.md). **Do not wire eGeMAPS/ComParE
features into a code path that serves paying subscribers without first
getting a commercial openSMILE license** -- doing the feature engineering
and training entirely for internal research/benchmarking is fine under
the existing license; serving it as part of a $5/month product to
customers is not, as currently licensed.

CLAP (`laion/clap-htsat-unfused` via Hugging Face) is Apache-2.0 licensed
and does not have this restriction.

## Why 20 epochs, and what "done" looks like

20 epochs was the requested default and is a reasonable starting point
for a small MLP over a few-hundred-dimensional fused feature vector on a
dataset with ~100-160 training participants -- large enough for the loss
to stabilize, small enough that a from-scratch run takes minutes once
features are cached, not hours. It is a starting point to tune from, not
a number backed by a learning-curve analysis on real data (which, again,
hasn't been run here). If `metrics_history.csv` from a real run shows
validation loss still improving at epoch 20, increase `--epochs`; if it
shows validation loss climbing well before epoch 20 while training loss
keeps falling, that's overfitting on a small dataset, and the fix is
usually more regularization or fewer features (e.g. eGeMAPS only, drop
ComParE) rather than more epochs.

A trained model is only meaningful once it's been evaluated against a
genuinely held-out test set (participant-level, not seen during training
or hyperparameter selection) and the resulting metrics are reported
honestly, including failure cases -- not cherry-picked. `ml/evaluate.py`
is built to support that; using it against the ADReSS *test* split (not
re-scoring the validation split from training) is how a result becomes
citable rather than just a training-loss number.

## References
- Luz, Haider, de la Fuente, Fromm, MacWhinney. "Alzheimer's Dementia
  Recognition through Spontaneous Speech: The ADReSS Challenge."
  INTERSPEECH 2020 / arXiv:2004.06833.
- Elizalde, Deshmukh, Al Ismail, Wang. "CLAP: Learning Audio Concepts
  From Natural Language Supervision." ICASSP 2023.
- "Dementia Insights: A Context-Based MultiModal Approach." arXiv:2503.01226.
- audeering/opensmile-python documentation:
  https://audeering.github.io/opensmile-python/
- Hugging Face CLAP model card: https://huggingface.co/laion/clap-htsat-unfused
