# Privacy and security design

This document covers what's actually implemented, matching the original
project brief's privacy goals (local inference, encrypted storage,
HIPAA/GDPR-conscious design, consent, deletion, audit logging) against what
exists in code today.

## Encryption

### In transit
Not handled by this application -- terminate TLS at your reverse
proxy/load balancer (nginx, Caddy, a cloud provider's HTTPS termination).
Never run this API directly exposed over plain HTTP outside local dev.

### At rest
Implemented via `core/encryption.py`, using Fernet (AES-128-CBC + HMAC)
with a server-held key (`ALZDX_ENCRYPTION_KEY`):
- `AnalysisRecord.result_json` -- every stored analysis result (transcript
  text, extracted features, risk band) is encrypted before it touches the
  database.
- `UploadedFile.blob` -- every uploaded image (or audio, if
  `ALZDX_KEEP_UPLOADED_AUDIO` is enabled) is encrypted before storage.
- Password storage uses bcrypt hashing (`core/security.py`), which is a
  one-way hash, not reversible encryption -- this app can never recover or
  display a user's actual password, by design.

**What this protects against**: a stolen disk image, a leaked database
backup, or read access to the Postgres host without also having the
separate encryption key (which should live in a secrets manager, not
alongside the database).

**What this does NOT protect against**: the running application server
itself can decrypt this data, because it has to in order to run feature
extraction and serve results back to the user. This is standard
server-side encryption at rest, not end-to-end encryption. If a threat
model requires the server operator to never see plaintext content, that's
a materially different architecture (client-side encryption before
upload, with keys the server never holds) and isn't what's built here.

### Key management
`ALZDX_ENCRYPTION_KEY` is a single static key in this pass -- no
rotation, no per-user keys, no KMS integration. `core/encryption.py`
fails loudly (raises `EncryptionKeyNotConfigured`) rather than silently
storing plaintext if the key is missing. Key rotation would require a
re-encryption migration script that isn't built yet -- don't rotate the
key in place against existing data without one.

## Consent

Not yet implemented as an explicit, logged consent flow. The signup form
presents a clear statement of what's collected and why (see
`site/signup.html`), but there's no "consent version" tracking or
re-consent-on-change flow. Treat this as a gap, not a solved requirement,
if this ever handles real users' health-adjacent data.

## Right to erasure (GDPR-style deletion)

`DELETE /api/v1/auth/me` deletes the user account and cascades (via
SQLAlchemy `cascade="all, delete-orphan"`) to that user's
`AnalysisRecord`s and `UploadedFile`s. It does **not**:
- Cancel an active Stripe subscription -- cancel via the billing portal
  first (`POST /api/v1/billing/portal`) if billing should also stop.
- Delete `AuditLogEntry` rows referencing the user -- these are kept
  deliberately (see below) as an operational record that an account
  existed and what happened on it, without retaining the account's
  actual content.

## Audit logging

`AuditLogEntry` (`core/audit.py`) records who did what and when:
registration, login, analysis creation/view/deletion, file
upload/deletion, subscription lifecycle events, account deletion.
Deliberately **not encrypted** -- it holds operational metadata (user id,
action, resource id, timestamp), never transcript text, image bytes, or
other clinical content, so it can stay queryable for compliance review
without needing decryption. Deliberately **not deleted on account
erasure** -- an audit trail that disappears when the account it's
auditing is deleted defeats much of its purpose.

## Local-first / minimal retention posture

- `ALZDX_KEEP_UPLOADED_AUDIO=false` (default): speech audio is processed
  in a temp file and deleted immediately after feature extraction --
  never persisted at all, encrypted or not.
- Only the derived `AnalysisRecord` (features + risk band, not raw audio)
  is stored by default.
- Image uploads ARE persisted (encrypted) because there's no analysis
  pipeline yet to derive features from them and discard the original --
  see docs/ARCHITECTURE.md Milestone 3.

## What's still a gap

- No rate limiting on auth endpoints (brute-force login protection).
- No email verification on registration.
- No per-user encryption keys (single shared server key).
- No documented incident-response or breach-notification process --
  necessary before this could reasonably handle real health-adjacent data
  at any scale, and out of scope for what a codebase alone can solve.
