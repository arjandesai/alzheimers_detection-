# Handwriting module (DARWIN)

A **separate modality** from the speech pipeline: an Alzheimer's-vs-healthy
classifier trained on the DARWIN online-handwriting dataset. This is the
one handwriting dataset in this project that is genuinely Alzheimer's-
specific, real (not synthetic), and free of the leakage traps that produce
fake "99%" numbers elsewhere.

## The dataset

DARWIN (Cilia, De Gregorio, De Stefano, Fontanella, Marcelli, Parziale,
"Diagnosing Alzheimer's disease from online handwriting: A novel dataset
and performance benchmarking", *Engineering Applications of Artificial
Intelligence*, Vol. 111, 2022, doi:10.1016/j.engappai.2022.104822).

- 174 participants: 89 Alzheimer's patients, 85 healthy controls
- 25 handwriting tasks per participant, 18 features per task = 450 features
- One row per participant, unique IDs (so participant-level splitting is
  trivial and leakage-free)
- Obtained from the dataset authors; **not shipped in this repo**.

## The critical limitation: this is NOT photo-based

DARWIN features are **digitizing-tablet dynamics**, captured while the
person writes: `air_time` (pen-in-air duration), `pressure`, `gmrt`
(generalized mean relative tremor), on-paper vs in-air velocity/
acceleration, and so on. They encode *how* the pen moved through time and
space, not *what the final ink looks like*.

This means a model trained on DARWIN **cannot be applied to a photograph
of handwriting**. A photo has no pressure, no timing, no in-air movement.
The earlier-requested "upload a handwriting photo and compare" feature is
**not possible on this data**, and this module does not pretend otherwise.
To run a trained DARWIN model on a new person, you would need to reproduce
the same digitizing-tablet acquisition protocol, not take a picture.

If you specifically want photo-based handwriting analysis, that is a
different, computer-vision task with no clean open Alzheimer's benchmark
to validate against, so it can only be built as an explicitly
experimental, unvalidated, descriptive-measurement feature. It is not
built here.

## Honest results

Trained/evaluated in this repo's environment (scikit-learn), on the real
DARWIN data:

| Model | Method | Accuracy | Notes |
|---|---|---|---|
| Majority-class baseline | 5-fold CV | ~0.51 | floor; confirms the task isn't trivially imbalanced |
| MLP (20 epochs) | single 80/20 split | ~0.86 | the requested 20-epoch net |
| MLP (20 epochs) | **5-fold CV** | **~0.87 +/- 0.04** | **the number to trust** |
| SVM (RBF) | 5-fold CV | ~0.86 | classical baseline, agrees with the MLP |

Two different model families landing in the mid-80s, well above a 0.51
baseline, is what an **honest** result looks like. It matches DARWIN's
published benchmark range.

### Read this before quoting any higher number

The honest ceiling for Alzheimer's detection from a single modality is
**nowhere near 99%**. For reference, in speech (ADReSS 2020 challenge)
the organizers' acoustic baseline was 62.5% and the best ensembles
reached ~85-90%. Any pipeline reporting >95% on this task should be
assumed buggy (label leakage, or an ID/class column leaking into the
features) until proven otherwise. `train_darwin.py` prints a warning if
CV accuracy exceeds 0.95 for exactly this reason.

## Running it

```bash
pip install -e ".[handwriting]"

# Command-line:
python -m alzheimers_detection.handwriting.train_darwin \
    --csv /path/to/DARWIN.csv --epochs 20 --folds 5 --output-dir ./runs/darwin
# writes runs/darwin/darwin_results.json

# Or on Kaggle: upload DARWIN.csv as a dataset, attach it, and run
# notebooks/darwin_kaggle.ipynb (it auto-finds the CSV under /kaggle/input).
```

## Where this sits in the project

This is a standalone research modality. It is **not** wired into the
speech pipeline, the API, or the subscription product, and it makes no
diagnostic claim. It exists because DARWIN is a legitimate, correctly-
constructed Alzheimer's dataset, and training on it honestly is a real,
runnable thing, unlike the synthetic tabular and leakage-prone image
datasets evaluated and rejected earlier (see git history / CLAUDE.md).
