# EWA-DB module (Slovak speech, AD vs healthy)

A **separate research modality**: an Alzheimer's-vs-healthy classifier
trained on the acoustic (openSMILE GeMAPS) features that the EWA-DB
database ships pre-computed. Built on the current codebase alongside the
speech pipeline, DARWIN handwriting, and the rest.

## The dataset

EWA-DB (Rusko, Sabo, Trnka, et al., "Slovak database of speech affected by
neurodegenerative diseases", *Scientific Data* 11:1320, 2024,
doi:10.1038/s41597-024-04171-6).

- 1649 speakers total; audio published for 1003 (consent-limited).
- Groups: AD, MCI, PD, AD+PD, and healthy controls.
- Per-speaker JSON files carry pre-computed features, including
  **openSMILE with GeMAPS settings** (the same feature family this
  project's `speech/opensmile_features.py` uses) and Neurospeech features.
- Openly available: Zenodo record `10952480`, and ELRA `ELRA-S0489`.
- **Not shipped in this repo.** Download it yourself and point the loader
  at the extracted folder.

## The one fact that dominates everything: severe class imbalance

Straight from the paper: **N = 27 AD patients, N = 30 MCI, vs 1323 healthy
controls.** For an AD-vs-HC task that is roughly a **48 : 1** imbalance.

This changes how you must read any result:

- **Raw accuracy is misleading here.** A model that predicts "healthy" for
  everyone scores ~98% accuracy and detects **zero** Alzheimer's cases.
  Anyone who reports "98% accuracy" on this dataset without showing AD
  recall is (accidentally or otherwise) reporting that useless model.
- The metrics that actually matter are **balanced accuracy**, **AD recall
  (sensitivity, did we catch the AD cases?)**, and **AUC**.
- `train_ewadb.py` reports all of those, prints the majority-class baseline
  right next to raw accuracy so you can't be fooled, uses
  `class_weight='balanced'`, and uses stratified cross-validation instead
  of a single split (with only ~27 positives, one split is far too noisy).

## Honest expected result

Do **not** expect DARWIN-like numbers (DARWIN had 89 AD patients and clean
tablet features; it honestly reached ~87%). Here you are generalizing from
**27 AD speakers** in a different language, using acoustic features only.
Realistic outcomes:

- A **decent AUC / balanced accuracy with wide error bars** would be a good
  honest result.
- **Near-chance balanced accuracy is entirely possible** and would not be
  a bug, it would mean the signal is too thin in 27 cases / this feature
  set. The script says so explicitly in its verdict.
- If you see **balanced accuracy above ~0.9**, be suspicious of leakage
  before celebrating (the script warns about this too).

## Language caveat

EWA-DB is **Slovak**. This project's linguistic features (filler-word
lists, pronoun-to-noun ratios in `speech/linguistic_features.py`) are
English-tuned and will not transfer. This module therefore uses **only the
language-independent acoustic GeMAPS features**. It does not attempt Slovak
NLP. That is a deliberate scoping decision, not an oversight.

## Running it

```bash
pip install -e ".[handwriting]"   # same light sklearn/pandas deps
# Get EWA-DB first. Options:
#   - Zenodo record 10952480, or ELRA ELRA-S0489, or
#   - Kaggle: kagglehub.dataset_download("iyeddjebbi/ewa-db")  (~14 GB archive)
#
# STEP 1, ALWAYS INSPECT FIRST. EWA-DB releases differ in folder nesting
# and JSON key names. The inspector reports the ACTUAL structure of your
# download so training works first try:
#   python -m alzheimers_detection.ewadb.inspect_ewadb --root /path/to/ewa-db
# The loader auto-discovers the feature block (it finds the largest numeric
# block in each JSON regardless of key name), so as long as the inspector
# reports numeric feature blocks, training will find them too.
#
# STEP 2, train:

python -m alzheimers_detection.ewadb.train_ewadb \
    --root /path/to/EWA-DB --epochs 20 --folds 5 --output-dir ./runs/ewadb
# writes runs/ewadb/ewadb_results.json
```

### If the loader finds no features

EWA-DB's exact JSON key layout can vary between releases. The loader
searches several plausible keys for the GeMAPS block (`GEMAPS_KEYS` in
`ewadb_dataset.py`). If your release nests them differently, adjust that
tuple; everything downstream stays the same. The loader records every
speaker it skipped and why (in `EwaData.skipped`), so a near-empty result
tells you to check the key layout rather than silently producing garbage.

## Status / honesty

Not wired into the API, the subscription product, or the speech pipeline;
makes no diagnostic claim. The loader and training script were verified by
running them end-to-end against a **synthetic** folder tree that mimics
EWA-DB's structure (real data could not be downloaded in the build
environment), and the loader's unit tests (`tests/test_ewadb.py`) pass.
The **real** numbers can only come from you running it on the actual
downloaded dataset, and per the above, expect them to be humble.
