"""initial schema: users, analysis_records, uploaded_files, audit_log

Revision ID: 0001_initial
Revises:
Create Date: 2026-07-07

NOTE: this migration was hand-authored to mirror core/models.py because no
live Postgres instance was available in the environment that wrote it (see
CLAUDE.md for that caveat). Before relying on this in a real deployment,
regenerate it properly:

    alembic revision --autogenerate -m "regenerate initial schema"

...against a real empty Postgres database, diff the result against this
file, and replace this file if they disagree. Encrypted columns
(`analysis_records.result_json`, `uploaded_files.blob`) are declared as
LargeBinary here because that's the actual on-the-wire column type once
core/encryption.py's TypeDecorators encrypt the Python value -- Alembic
autogenerate would produce the same thing, since it inspects the
TypeDecorator's `impl`, not the logical type.
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("email", sa.String(length=320), nullable=False),
        sa.Column("hashed_password", sa.String(length=100), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("stripe_customer_id", sa.String(length=64), nullable=True),
        sa.Column("stripe_subscription_id", sa.String(length=64), nullable=True),
        sa.Column("subscription_status", sa.String(length=20), nullable=False, server_default="inactive"),
        sa.Column("subscription_current_period_end", sa.DateTime(timezone=True), nullable=True),
        # Two-factor auth. totp_secret is encrypted at the application
        # layer (EncryptedText -> LargeBinary on the wire).
        sa.Column("totp_secret", sa.LargeBinary(), nullable=True),
        sa.Column("twofa_enabled", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("recovery_code_hashes", sa.JSON(), nullable=True),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)
    op.create_index("ix_users_stripe_customer_id", "users", ["stripe_customer_id"])

    op.create_table(
        "analysis_records",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("user_id", sa.String(length=36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("modality", sa.String(length=20), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="complete"),
        sa.Column("result_json", sa.LargeBinary(), nullable=True),  # encrypted at the application layer
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_analysis_records_user_id", "analysis_records", ["user_id"])

    op.create_table(
        "uploaded_files",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("user_id", sa.String(length=36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("modality", sa.String(length=20), nullable=False),
        sa.Column("original_filename", sa.String(length=255), nullable=False),
        sa.Column("content_type", sa.String(length=100), nullable=False),
        sa.Column("byte_size", sa.Integer(), nullable=False),
        sa.Column("blob", sa.LargeBinary(), nullable=False),  # encrypted at the application layer
        sa.Column("status", sa.String(length=30), nullable=False, server_default="queued_for_analysis"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_uploaded_files_user_id", "uploaded_files", ["user_id"])

    op.create_table(
        "audit_log",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("user_id", sa.String(length=36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("action", sa.String(length=50), nullable=False),
        sa.Column("resource_type", sa.String(length=50), nullable=True),
        sa.Column("resource_id", sa.String(length=36), nullable=True),
        sa.Column("metadata_json", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_audit_log_user_id", "audit_log", ["user_id"])
    op.create_index("ix_audit_log_created_at", "audit_log", ["created_at"])


def downgrade() -> None:
    op.drop_table("audit_log")
    op.drop_table("uploaded_files")
    op.drop_table("analysis_records")
    op.drop_index("ix_users_stripe_customer_id", table_name="users")
    op.drop_index("ix_users_email", table_name="users")
    op.drop_table("users")
