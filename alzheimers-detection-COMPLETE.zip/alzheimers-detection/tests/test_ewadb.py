"""Tests for the EWA-DB loader. Builds a tiny synthetic folder tree that
mimics EWA-DB's structure (group/speaker/task/*.json with a gemaps block),
NOT real data (which isn't shipped). Verifies group->label mapping, the
MCI/PD skip, GeMAPS extraction, and the imbalance is preserved.
"""

import json

import numpy as np
import pytest

from alzheimers_detection.ewadb.ewadb_dataset import EwaLoadError, load_ewadb


def _make_speaker(group_dir, sid, feat_shift, n_feats=10):
    for task in ["phonation", "naming", "picture description"]:
        d = group_dir / sid / task
        d.mkdir(parents=True, exist_ok=True)
        feats = {f"gemaps_f{i}": float(feat_shift + i) for i in range(n_feats)}
        (d / f"{task}_1.json").write_text(json.dumps({"gemaps": feats, "speaker_info": {"code": sid}}))


def _build_tree(tmp_path, n_ad=6, n_hc=20, n_mci=5):
    root = tmp_path / "EWA-DB"
    for i in range(n_ad):
        _make_speaker(root / "AD", f"ad_{i}", feat_shift=1.0)
    for i in range(n_hc):
        _make_speaker(root / "HC", f"hc_{i}", feat_shift=0.0)
    for i in range(n_mci):
        _make_speaker(root / "MCI", f"mci_{i}", feat_shift=0.5)
    return root


def test_missing_root_raises(tmp_path):
    with pytest.raises(EwaLoadError):
        load_ewadb(tmp_path / "does_not_exist")


def test_loads_ad_and_hc_only(tmp_path):
    root = _build_tree(tmp_path, n_ad=6, n_hc=20, n_mci=5)
    data = load_ewadb(root)
    assert (data.y == 1).sum() == 6      # AD
    assert (data.y == 0).sum() == 20     # HC
    assert len(data.y) == 26             # MCI excluded from X/y


def test_mci_group_is_skipped(tmp_path):
    root = _build_tree(tmp_path, n_ad=6, n_hc=20, n_mci=5)
    data = load_ewadb(root)
    # MCI recorded in skipped, not in the label array
    assert any("mci" in s[0].lower() or "mci" in s[1].lower() for s in data.skipped)
    assert 2 not in data.y  # only 0/1 labels


def test_feature_matrix_shape(tmp_path):
    root = _build_tree(tmp_path, n_ad=6, n_hc=20, n_mci=0)
    data = load_ewadb(root)
    assert data.X.shape == (26, 10)
    assert not np.isnan(data.X).any()


def test_imbalance_preserved(tmp_path):
    # mirror the real dataset's severe imbalance direction
    root = _build_tree(tmp_path, n_ad=3, n_hc=60, n_mci=0)
    data = load_ewadb(root)
    n_ad = int((data.y == 1).sum())
    n_hc = int((data.y == 0).sum())
    assert n_hc / n_ad == 20.0


def test_speaker_with_no_gemaps_is_skipped(tmp_path):
    root = tmp_path / "EWA-DB"
    # one HC speaker with a valid gemaps block
    _make_speaker(root / "HC", "hc_ok", feat_shift=0.0)
    # one AD speaker whose JSON has NO gemaps block (mimics audio-consent-not-given)
    d = root / "AD" / "ad_nogemaps" / "phonation"
    d.mkdir(parents=True, exist_ok=True)
    (d / "phonation_1.json").write_text(json.dumps({"asr": "text only, no features"}))

    data = load_ewadb(root)
    assert "ad_nogemaps" in [s[0] for s in data.skipped]
    assert data.speaker_ids == ["hc_ok"]
