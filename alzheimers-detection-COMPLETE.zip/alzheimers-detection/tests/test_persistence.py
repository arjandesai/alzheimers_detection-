import io


def _png_bytes():
    # Minimal valid-looking PNG header + junk payload -- the upload
    # endpoint only checks content_type and size, not actual image
    # validity (no image analysis pipeline exists yet in this milestone).
    return b"\x89PNG\r\n\x1a\n" + b"0" * 128


def test_upload_image_requires_subscription(app_client, registered_user):
    token, _ = registered_user
    resp = app_client.post(
        "/api/v1/uploads/image",
        files={"file": ("clock.png", io.BytesIO(_png_bytes()), "image/png")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 402


def test_upload_image_success_when_subscribed(app_client, subscribed_user):
    token, _ = subscribed_user
    resp = app_client.post(
        "/api/v1/uploads/image",
        files={"file": ("clock.png", io.BytesIO(_png_bytes()), "image/png")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 201, resp.text
    body = resp.json()
    assert body["modality"] == "image"
    assert body["status"] == "queued_for_analysis"
    assert body["byte_size"] == len(_png_bytes())


def test_upload_image_rejects_bad_content_type(app_client, subscribed_user):
    token, _ = subscribed_user
    resp = app_client.post(
        "/api/v1/uploads/image",
        files={"file": ("notes.txt", io.BytesIO(b"hello"), "text/plain")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 415


def test_list_uploads_only_returns_own_files(app_client, subscribed_user, db_session):
    token, user_json = subscribed_user
    headers = {"Authorization": f"Bearer {token}"}
    app_client.post(
        "/api/v1/uploads/image",
        files={"file": ("a.png", io.BytesIO(_png_bytes()), "image/png")},
        headers=headers,
    )

    # a second, unrelated subscribed user should see an empty list
    import datetime as dt

    from alzheimers_detection.core.models import User

    other = User(email="other@example.com", hashed_password="x")
    other.subscription_status = "active"
    other.subscription_current_period_end = dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=30)
    db_session.add(other)
    db_session.commit()

    from alzheimers_detection.core.security import create_access_token

    other_token = create_access_token(subject=other.id)

    own_list = app_client.get("/api/v1/uploads", headers=headers)
    assert own_list.status_code == 200
    assert len(own_list.json()) == 1

    other_list = app_client.get("/api/v1/uploads", headers={"Authorization": f"Bearer {other_token}"})
    assert other_list.status_code == 200
    assert len(other_list.json()) == 0


def test_delete_upload_requires_ownership(app_client, subscribed_user, db_session):
    token, _ = subscribed_user
    headers = {"Authorization": f"Bearer {token}"}
    upload_resp = app_client.post(
        "/api/v1/uploads/image",
        files={"file": ("a.png", io.BytesIO(_png_bytes()), "image/png")},
        headers=headers,
    )
    upload_id = upload_resp.json()["id"]

    import datetime as dt

    from alzheimers_detection.core.models import User
    from alzheimers_detection.core.security import create_access_token

    other = User(email="thief@example.com", hashed_password="x")
    other.subscription_status = "active"
    other.subscription_current_period_end = dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=30)
    db_session.add(other)
    db_session.commit()
    other_token = create_access_token(subject=other.id)

    forbidden = app_client.delete(
        f"/api/v1/uploads/{upload_id}", headers={"Authorization": f"Bearer {other_token}"}
    )
    assert forbidden.status_code == 404  # not 403 -- don't confirm the resource exists to a non-owner

    allowed = app_client.delete(f"/api/v1/uploads/{upload_id}", headers=headers)
    assert allowed.status_code == 204


def test_account_deletion_cascades_to_uploads(app_client, subscribed_user, db_session):
    token, user_json = subscribed_user
    headers = {"Authorization": f"Bearer {token}"}
    app_client.post(
        "/api/v1/uploads/image",
        files={"file": ("a.png", io.BytesIO(_png_bytes()), "image/png")},
        headers=headers,
    )

    from alzheimers_detection.core.models import UploadedFile

    before = db_session.query(UploadedFile).filter(UploadedFile.user_id == user_json["id"]).count()
    assert before == 1

    delete_resp = app_client.delete("/api/v1/auth/me", headers=headers)
    assert delete_resp.status_code == 204

    db_session.expire_all()
    after = db_session.query(UploadedFile).filter(UploadedFile.user_id == user_json["id"]).count()
    assert after == 0
