import pytest

from alzheimers_detection.core.encryption import (
    DecryptionError,
    decrypt_bytes,
    decrypt_text,
    encrypt_bytes,
    encrypt_text,
)

# Note: tests/conftest.py sets ALZDX_ENCRYPTION_KEY before any package
# import, so get_fernet() below resolves against a real (test-only) key.


def test_text_roundtrip():
    ciphertext = encrypt_text("hello world")
    assert ciphertext != b"hello world"
    assert decrypt_text(ciphertext) == "hello world"


def test_bytes_roundtrip():
    blob = bytes([1, 2, 3, 4, 250, 251, 0, 0, 9])
    ciphertext = encrypt_bytes(blob)
    assert ciphertext != blob
    assert decrypt_bytes(ciphertext) == blob


def test_decrypt_rejects_garbage():
    with pytest.raises(DecryptionError):
        decrypt_bytes(b"not-a-real-fernet-token")


def test_encrypted_json_column_roundtrip(db_session):
    """Exercises the actual SQLAlchemy TypeDecorator, not just the raw
    encrypt/decrypt functions -- writes an AnalysisRecord with a dict
    result_json and confirms it comes back decrypted and equal, via a
    real (in-memory) database round-trip.
    """
    from alzheimers_detection.core.models import AnalysisRecord, User

    user = User(email="enc-test@example.com", hashed_password="x")
    db_session.add(user)
    db_session.flush()

    payload = {"risk_band": "low", "features": {"speech_rate_wpm": 132.5}}
    record = AnalysisRecord(user_id=user.id, modality="speech", status="complete", result_json=payload)
    db_session.add(record)
    db_session.commit()

    db_session.expire_all()  # force a real re-read from the DB, not the identity map
    reloaded = db_session.get(AnalysisRecord, record.id)
    assert reloaded.result_json == payload


def test_encrypted_blob_column_roundtrip(db_session):
    from alzheimers_detection.core.models import UploadedFile, User

    user = User(email="blob-test@example.com", hashed_password="x")
    db_session.add(user)
    db_session.flush()

    raw = b"\x89PNG\r\n\x1a\n" + b"fake-image-bytes"
    upload = UploadedFile(
        user_id=user.id,
        modality="image",
        original_filename="clock.png",
        content_type="image/png",
        byte_size=len(raw),
        blob=raw,
    )
    db_session.add(upload)
    db_session.commit()

    db_session.expire_all()
    reloaded = db_session.get(UploadedFile, upload.id)
    assert reloaded.blob == raw
