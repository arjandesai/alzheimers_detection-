"""2FA tests.

The pure-logic tests (secret/URI/recovery-code helpers) need `pyotp`,
which is an install-time dependency, so they skip cleanly if it's absent
(as in the minimal sandbox). The flow tests go through the real API with
the app_client fixture; where they need a valid TOTP code, they compute
it with pyotp too, so they also skip without it rather than hardcoding a
code that only works for 30 seconds.
"""

import pytest

pyotp = pytest.importorskip("pyotp")

from alzheimers_detection.core import twofa  # noqa: E402


def test_generate_secret_is_valid_base32():
    secret = twofa.generate_totp_secret()
    assert len(secret) >= 16
    # base32 decodes without error
    import base64
    base64.b32decode(secret)


def test_provisioning_uri_is_otpauth():
    secret = twofa.generate_totp_secret()
    uri = twofa.provisioning_uri(secret, "warrior@example.com")
    assert uri.startswith("otpauth://totp/")
    assert "secret=" in uri
    assert "Bushido" in uri


def test_verify_totp_accepts_current_code():
    secret = twofa.generate_totp_secret()
    code = pyotp.TOTP(secret).now()
    assert twofa.verify_totp(secret, code)


def test_verify_totp_rejects_wrong_code():
    secret = twofa.generate_totp_secret()
    # '000000' is astronomically unlikely to be the current code; guard anyway
    current = pyotp.TOTP(secret).now()
    wrong = "000000" if current != "000000" else "111111"
    assert not twofa.verify_totp(secret, wrong)


def test_verify_totp_rejects_non_numeric():
    secret = twofa.generate_totp_secret()
    assert not twofa.verify_totp(secret, "abcdef")
    assert not twofa.verify_totp(secret, "")


def test_recovery_codes_generate_hash_and_verify_once():
    codes = twofa.generate_recovery_codes(5)
    assert len(codes) == 5
    hashes = twofa.hash_recovery_codes(codes)

    # A valid code verifies and is consumed (removed from remaining).
    ok, remaining = twofa.verify_and_consume_recovery_code(codes[0], hashes)
    assert ok
    assert len(remaining) == 4

    # The same code no longer works against the shortened list.
    ok2, _ = twofa.verify_and_consume_recovery_code(codes[0], remaining)
    assert not ok2


def test_recovery_code_wrong_value_rejected():
    codes = twofa.generate_recovery_codes(3)
    hashes = twofa.hash_recovery_codes(codes)
    ok, remaining = twofa.verify_and_consume_recovery_code("dead-beef", hashes)
    assert not ok
    assert len(remaining) == 3  # nothing consumed on failure


# ---- Full login flow through the API ----


def _register(app_client, email="tfa-user@example.com"):
    resp = app_client.post("/api/v1/auth/register", json={"email": email, "password": "correct-horse-battery"})
    assert resp.status_code == 201, resp.text
    return resp.json()["access_token"]


def test_enabling_2fa_changes_login_to_two_stage(app_client, db_session):
    token = _register(app_client)
    headers = {"Authorization": f"Bearer {token}"}

    # Begin setup
    setup = app_client.post("/api/v1/auth/2fa/setup", headers=headers)
    assert setup.status_code == 200
    secret = setup.json()["secret"]
    assert len(setup.json()["recovery_codes"]) == 10

    # Confirm with a real code
    code = pyotp.TOTP(secret).now()
    confirm = app_client.post("/api/v1/auth/2fa/confirm", headers=headers, json={"code": code})
    assert confirm.status_code == 200
    assert confirm.json()["twofa_enabled"] is True

    # Now a fresh login returns a 2FA challenge, not a token
    login = app_client.post(
        "/api/v1/auth/login", json={"email": "tfa-user@example.com", "password": "correct-horse-battery"}
    )
    assert login.status_code == 200
    assert login.json().get("twofa_required") is True
    pending = login.json()["pending_token"]
    assert "access_token" not in login.json()

    # The pending token cannot be used as a real access token
    forbidden = app_client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {pending}"})
    assert forbidden.status_code == 401

    # Completing 2FA with a fresh code yields a real token
    code2 = pyotp.TOTP(secret).now()
    stage2 = app_client.post("/api/v1/auth/login/2fa", json={"pending_token": pending, "code": code2})
    assert stage2.status_code == 200
    assert "access_token" in stage2.json()


def test_2fa_login_rejects_wrong_code(app_client):
    token = _register(app_client, email="tfa2@example.com")
    headers = {"Authorization": f"Bearer {token}"}
    setup = app_client.post("/api/v1/auth/2fa/setup", headers=headers)
    secret = setup.json()["secret"]
    app_client.post("/api/v1/auth/2fa/confirm", headers=headers, json={"code": pyotp.TOTP(secret).now()})

    login = app_client.post("/api/v1/auth/login", json={"email": "tfa2@example.com", "password": "correct-horse-battery"})
    pending = login.json()["pending_token"]

    bad = app_client.post("/api/v1/auth/login/2fa", json={"pending_token": pending, "code": "000000"})
    assert bad.status_code == 401


def test_recovery_code_works_at_login(app_client):
    token = _register(app_client, email="tfa3@example.com")
    headers = {"Authorization": f"Bearer {token}"}
    setup = app_client.post("/api/v1/auth/2fa/setup", headers=headers)
    secret = setup.json()["secret"]
    recovery = setup.json()["recovery_codes"]
    app_client.post("/api/v1/auth/2fa/confirm", headers=headers, json={"code": pyotp.TOTP(secret).now()})

    login = app_client.post("/api/v1/auth/login", json={"email": "tfa3@example.com", "password": "correct-horse-battery"})
    pending = login.json()["pending_token"]

    # Use a recovery code instead of a TOTP code
    stage2 = app_client.post("/api/v1/auth/login/2fa", json={"pending_token": pending, "code": recovery[0]})
    assert stage2.status_code == 200
    assert "access_token" in stage2.json()
