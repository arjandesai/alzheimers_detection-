"""Tests for core/billing.py.

`_require_stripe()` is monkeypatched to return a small fake object with
the same call shape as the real `stripe` module, so these tests exercise
our integration logic (customer creation, checkout session assembly,
webhook signature handling, subscription state sync) without needing the
`stripe` package installed or any network access to Stripe's API. The
pure state-sync functions (sync_subscription_from_stripe_object,
mark_subscription_canceled) don't touch Stripe at all and are tested
directly.
"""

from __future__ import annotations

import datetime as dt

import pytest

from alzheimers_detection.core import billing
from alzheimers_detection.core.models import User


class _FakeCustomers:
    def create(self, email, metadata):
        return {"id": f"cus_fake_{email.replace('@', '_')}"}


class _FakeCheckoutSession:
    def create(self, **kwargs):
        assert kwargs["mode"] == "subscription"
        return {"url": f"https://checkout.stripe.com/fake/{kwargs['client_reference_id']}"}


class _FakeCheckout:
    def __init__(self):
        self.Session = _FakeCheckoutSession()


class _FakePortalSession:
    def create(self, **kwargs):
        return {"url": f"https://billing.stripe.com/fake-portal/{kwargs['customer']}"}


class _FakeBillingPortal:
    def __init__(self):
        self.Session = _FakePortalSession()


class _FakeWebhook:
    def __init__(self, valid=True, event=None):
        self._valid = valid
        self._event = event

    def construct_event(self, payload, sig_header, secret):
        if not self._valid:
            raise ValueError("invalid signature")
        return self._event


class _FakeStripe:
    def __init__(self, webhook_valid=True, webhook_event=None):
        self.Customer = _FakeCustomers()
        self.checkout = _FakeCheckout()
        self.billing_portal = _FakeBillingPortal()
        self.Webhook = _FakeWebhook(valid=webhook_valid, event=webhook_event)


@pytest.fixture
def fake_stripe(monkeypatch):
    fake = _FakeStripe()
    monkeypatch.setattr(billing, "_require_stripe", lambda: fake)
    return fake


def _user(db_session, email="billing-test@example.com"):
    user = User(email=email, hashed_password="x")
    db_session.add(user)
    db_session.flush()
    return user


def test_billing_not_configured_without_stripe_secret_key(db_session):
    # No fake_stripe fixture here -- exercises the real _require_stripe()
    # guard, which should refuse to proceed when no Stripe secret key is
    # configured (the default in the test environment).
    user = _user(db_session, email="unconfigured@example.com")
    with pytest.raises(billing.BillingNotConfigured):
        billing.create_checkout_session(db_session, user)


def test_get_or_create_stripe_customer_creates_once(db_session, fake_stripe):
    user = _user(db_session)
    customer_id = billing.get_or_create_stripe_customer(db_session, user)
    assert customer_id.startswith("cus_fake_")
    assert user.stripe_customer_id == customer_id

    # Second call should reuse the stored id, not create another customer.
    again = billing.get_or_create_stripe_customer(db_session, user)
    assert again == customer_id


def test_create_checkout_session_without_price_id_raises(db_session, fake_stripe, monkeypatch):
    from alzheimers_detection.core.config import get_settings

    monkeypatch.setattr(get_settings(), "stripe_price_id", "")
    user = _user(db_session)
    with pytest.raises(billing.BillingNotConfigured):
        billing.create_checkout_session(db_session, user)


def test_create_checkout_session_returns_url(db_session, fake_stripe, monkeypatch):
    from alzheimers_detection.core.config import get_settings

    monkeypatch.setattr(get_settings(), "stripe_price_id", "price_123")
    user = _user(db_session)
    url = billing.create_checkout_session(db_session, user)
    assert url.startswith("https://checkout.stripe.com/fake/")
    assert user.id in url  # client_reference_id round-tripped into the fake URL


def test_sync_subscription_marks_active_for_active_status():
    user = User(email="sync1@example.com", hashed_password="x")
    period_end = int(dt.datetime(2030, 1, 1, tzinfo=dt.timezone.utc).timestamp())
    billing.sync_subscription_from_stripe_object(
        user, {"id": "sub_1", "status": "active", "current_period_end": period_end}
    )
    assert user.subscription_status == "active"
    assert user.stripe_subscription_id == "sub_1"
    assert user.has_active_subscription is True


def test_sync_subscription_marks_active_for_trialing_status():
    user = User(email="sync2@example.com", hashed_password="x")
    billing.sync_subscription_from_stripe_object(user, {"id": "sub_2", "status": "trialing"})
    assert user.subscription_status == "active"


def test_sync_subscription_preserves_non_active_status_verbatim():
    user = User(email="sync3@example.com", hashed_password="x")
    billing.sync_subscription_from_stripe_object(user, {"id": "sub_3", "status": "past_due"})
    assert user.subscription_status == "past_due"
    assert user.has_active_subscription is False


def test_mark_subscription_canceled():
    user = User(email="sync4@example.com", hashed_password="x")
    user.subscription_status = "active"
    billing.mark_subscription_canceled(user)
    assert user.subscription_status == "canceled"
    assert user.has_active_subscription is False


def test_has_active_subscription_false_when_period_expired():
    user = User(email="sync5@example.com", hashed_password="x")
    user.subscription_status = "active"
    user.subscription_current_period_end = dt.datetime(2000, 1, 1, tzinfo=dt.timezone.utc)
    assert user.has_active_subscription is False


def test_construct_webhook_event_rejects_bad_signature(monkeypatch):
    fake = _FakeStripe(webhook_valid=False)
    monkeypatch.setattr(billing, "_require_stripe", lambda: fake)
    from alzheimers_detection.core.config import get_settings

    monkeypatch.setattr(get_settings(), "stripe_webhook_secret", "whsec_test")
    with pytest.raises(billing.WebhookVerificationError):
        billing.construct_webhook_event(b"{}", "bad-signature")


def test_construct_webhook_event_returns_event_on_valid_signature(monkeypatch):
    event = {"type": "customer.subscription.updated", "data": {"object": {"id": "sub_x"}}}
    fake = _FakeStripe(webhook_valid=True, webhook_event=event)
    monkeypatch.setattr(billing, "_require_stripe", lambda: fake)
    from alzheimers_detection.core.config import get_settings

    monkeypatch.setattr(get_settings(), "stripe_webhook_secret", "whsec_test")
    result = billing.construct_webhook_event(b"{}", "good-signature")
    assert result == event
