import time

import pytest

from alzheimers_detection.core.security import (
    TokenError,
    create_access_token,
    decode_access_token,
    hash_password,
    verify_password,
)


def test_hash_and_verify_roundtrip():
    hashed = hash_password("correct-horse-battery-staple")
    assert verify_password("correct-horse-battery-staple", hashed)


def test_verify_rejects_wrong_password():
    hashed = hash_password("correct-horse-battery-staple")
    assert not verify_password("wrong-password", hashed)


def test_hash_is_not_plaintext():
    hashed = hash_password("my-password")
    assert hashed != "my-password"
    assert hashed.startswith("$2b$")  # bcrypt identifier


def test_verify_handles_malformed_hash_gracefully():
    assert not verify_password("anything", "not-a-real-bcrypt-hash")


def test_access_token_roundtrip():
    token = create_access_token(subject="user-123")
    payload = decode_access_token(token)
    assert payload["sub"] == "user-123"


def test_access_token_carries_extra_claims():
    token = create_access_token(subject="user-123", extra_claims={"scope": "test"})
    payload = decode_access_token(token)
    assert payload["scope"] == "test"


def test_decode_rejects_tampered_token():
    token = create_access_token(subject="user-123")
    tampered = token[:-2] + ("aa" if not token.endswith("aa") else "bb")
    with pytest.raises(TokenError):
        decode_access_token(tampered)


def test_decode_rejects_garbage():
    with pytest.raises(TokenError):
        decode_access_token("not.a.jwt")
