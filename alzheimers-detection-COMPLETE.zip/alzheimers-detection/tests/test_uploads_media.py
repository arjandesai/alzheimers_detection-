import io


def _png():
    return b"\x89PNG\r\n\x1a\n" + b"0" * 128


def _mp4():
    # A tiny fake MP4-ish blob. The endpoint checks content_type + size,
    # not container validity (no analysis pipeline decodes it yet).
    return b"\x00\x00\x00\x18ftypmp42" + b"0" * 256


def test_upload_media_accepts_image(app_client, subscribed_user):
    token, _ = subscribed_user
    resp = app_client.post(
        "/api/v1/uploads/media",
        files={"file": ("clock.png", io.BytesIO(_png()), "image/png")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 201, resp.text
    assert resp.json()["modality"] == "image"


def test_upload_media_accepts_video(app_client, subscribed_user):
    token, _ = subscribed_user
    resp = app_client.post(
        "/api/v1/uploads/media",
        files={"file": ("gait.mp4", io.BytesIO(_mp4()), "video/mp4")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 201, resp.text
    assert resp.json()["modality"] == "video"


def test_upload_media_rejects_unknown_type(app_client, subscribed_user):
    token, _ = subscribed_user
    resp = app_client.post(
        "/api/v1/uploads/media",
        files={"file": ("notes.txt", io.BytesIO(b"hello"), "text/plain")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 415


def test_upload_media_requires_subscription(app_client, registered_user):
    token, _ = registered_user
    resp = app_client.post(
        "/api/v1/uploads/media",
        files={"file": ("clock.png", io.BytesIO(_png()), "image/png")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 402


def test_image_endpoint_rejects_video(app_client, subscribed_user):
    token, _ = subscribed_user
    resp = app_client.post(
        "/api/v1/uploads/image",
        files={"file": ("gait.mp4", io.BytesIO(_mp4()), "video/mp4")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 415


def test_uploaded_video_appears_in_list(app_client, subscribed_user):
    token, _ = subscribed_user
    headers = {"Authorization": f"Bearer {token}"}
    app_client.post(
        "/api/v1/uploads/media",
        files={"file": ("gait.mp4", io.BytesIO(_mp4()), "video/mp4")},
        headers=headers,
    )
    listing = app_client.get("/api/v1/uploads", headers=headers)
    assert listing.status_code == 200
    assert any(u["modality"] == "video" for u in listing.json())
