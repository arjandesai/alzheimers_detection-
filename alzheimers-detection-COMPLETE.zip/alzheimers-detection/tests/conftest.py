"""Shared fixtures.

Real ASR (faster-whisper/openai-whisper) needs multi-hundred-MB model
downloads, which we don't want as a hard requirement for running the unit
test suite (including in this sandbox, and in fast CI jobs). FakeASREngine
implements the same ASREngine interface with deterministic, hand-authored
output so pipeline/API tests can exercise the full flow without network
access or GPU/CPU-heavy inference.

Tests that need to validate real ASR accuracy belong in a separate,
explicitly-marked integration suite (see pyproject.toml `slow` marker)
that CI can skip by default and run nightly instead.
"""

from __future__ import annotations

import os

# IMPORTANT: these must be set before the first `from alzheimers_detection...`
# import anywhere in the test session, because core/db.py builds its engine
# from get_settings() (an lru_cache'd singleton) at module import time.
# conftest.py is always collected first by pytest, so this ordering is safe
# as long as no earlier-imported plugin pulls in the app first.
os.environ.setdefault("ALZDX_DATABASE_URL", "sqlite:///:memory:")
os.environ.setdefault("ALZDX_ENCRYPTION_KEY", "AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8=")
os.environ.setdefault("ALZDX_JWT_SECRET_KEY", "test-only-secret-not-for-production-use")
os.environ.setdefault("ALZDX_ENVIRONMENT", "test")

from pathlib import Path

import pytest

from alzheimers_detection.speech.schemas import Transcript, Word
from alzheimers_detection.speech.transcription import ASREngine, TranscriptionError


class FakeASREngine(ASREngine):
    name = "fake"

    def __init__(self, transcript: Transcript | None = None, raise_error: bool = False):
        self._transcript = transcript
        self._raise_error = raise_error

    def transcribe(self, audio_path: Path) -> Transcript:
        if self._raise_error:
            raise TranscriptionError("simulated ASR failure")
        if self._transcript is not None:
            return self._transcript
        # Default: a plausible short utterance, evenly timed.
        text = "the boy is climbing on the stool and the water is running over"
        tokens = text.split()
        words = [Word(text=t, start=i * 0.4, end=i * 0.4 + 0.35) for i, t in enumerate(tokens)]
        return Transcript(
            text=text,
            words=words,
            language="en",
            audio_duration_seconds=words[-1].end + 0.5,
            asr_backend=self.name,
            asr_model="fake-v1",
        )


@pytest.fixture
def fake_asr_engine():
    return FakeASREngine()


@pytest.fixture
def failing_asr_engine():
    return FakeASREngine(raise_error=True)


@pytest.fixture
def tiny_wav_bytes():
    """A minimal valid WAV file (silence, ~1s) for tests that need real
    bytes to upload, without depending on any external audio asset."""
    import io
    import wave

    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(16000)
        wf.writeframes(b"\x00\x00" * 16000)  # 1 second of silence
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Database / auth fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def db_session():
    """A fresh set of tables on the shared in-memory SQLite engine for each
    test, torn down afterward so tests don't leak state into each other.
    """
    from alzheimers_detection.core.db import Base, SessionLocal, engine
    from alzheimers_detection.core import models  # noqa: F401 - populate metadata

    Base.metadata.create_all(bind=engine)
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def app_client(db_session, monkeypatch, fake_asr_engine):
    """A TestClient wired to the same DB session as the test (so a test can
    both call the API and inspect/seed rows directly) and a fake ASR engine
    (so speech endpoints don't need a real model).
    """
    from fastapi.testclient import TestClient

    from alzheimers_detection.api.deps import get_db
    from alzheimers_detection.api.main import app

    monkeypatch.setattr(
        "alzheimers_detection.speech.pipeline.get_asr_engine",
        lambda backend, model_size: fake_asr_engine,
    )

    def _override_get_db():
        yield db_session
        db_session.commit()

    app.dependency_overrides[get_db] = _override_get_db
    with TestClient(app) as client:
        yield client
    app.dependency_overrides.clear()


@pytest.fixture
def registered_user(app_client):
    """Registers a user via the real API and returns (client, token, user_json)."""
    resp = app_client.post(
        "/api/v1/auth/register", json={"email": "reader@example.com", "password": "correct-horse-battery"}
    )
    assert resp.status_code == 201, resp.text
    body = resp.json()
    return body["access_token"], body["user"]


@pytest.fixture
def subscribed_user(app_client, registered_user, db_session):
    """Same as registered_user, but with an active subscription set
    directly in the DB -- bypasses Stripe entirely, which is the point:
    paywall-gating *logic* should be testable without a live Stripe
    account. Stripe's own integration is exercised separately in
    tests/test_billing.py against mocked Stripe responses.
    """
    import datetime as dt

    from alzheimers_detection.core.models import User

    token, user_json = registered_user
    user = db_session.get(User, user_json["id"])
    user.subscription_status = "active"
    user.subscription_current_period_end = dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=30)
    db_session.add(user)
    db_session.commit()
    return token, user_json
