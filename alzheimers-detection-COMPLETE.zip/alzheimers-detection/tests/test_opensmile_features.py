"""These tests exercise the "not installed" path deliberately, since that
IS the path exercised in this project's default CI job (no 'ml' extra
installed). A separate, explicitly-marked test with real audio and a real
opensmile install would belong in an integration suite -- not written
here, since it can't be verified in this environment either (see
docs/TRAINING.md's honesty note).
"""

import pytest

from alzheimers_detection.speech.opensmile_features import (
    COMPARE_DIM,
    EGEMAPS_DIM,
    OpenSmileNotInstalled,
    extract_egemaps,
)


def test_dimension_constants_match_documented_egemaps_and_compare_sizes():
    # eGeMAPSv02 = 88 functionals, ComParE_2016 = 6373 functionals --
    # per the opensmile-python docs and the ADReSS literature cited in
    # this module's docstring. A change to these constants should be
    # deliberate, not a typo -- hence pinning them in a test.
    assert EGEMAPS_DIM == 88
    assert COMPARE_DIM == 6373


def test_extract_egemaps_raises_clear_error_without_opensmile_installed(tmp_path):
    fake_audio = tmp_path / "sample.wav"
    fake_audio.write_bytes(b"\x00" * 100)
    try:
        import opensmile  # noqa: F401

        pytest.skip("opensmile is installed in this environment; not testing the absent-dependency path")
    except ImportError:
        pass

    with pytest.raises(OpenSmileNotInstalled, match="ml"):
        extract_egemaps(fake_audio)
