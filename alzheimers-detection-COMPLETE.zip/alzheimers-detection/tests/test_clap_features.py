import numpy as np
import pytest

from alzheimers_detection.speech.clap_features import (
    CLAP_EMBEDDING_DIM,
    ClapEmbedder,
    ClapNotInstalled,
    _resample,
)


def test_embedding_dim_matches_documented_clap_htsat_unfused_size():
    # laion/clap-htsat-unfused produces a 512-dim audio embedding per the
    # Hugging Face model card -- pinned here so a wrong constant doesn't
    # silently break downstream fusion-vector shape assumptions.
    assert CLAP_EMBEDDING_DIM == 512


def test_resample_changes_length_correctly():
    orig_sr, target_sr = 16000, 48000
    signal = np.random.default_rng(0).standard_normal(16000).astype(np.float32)
    out = _resample(signal, orig_sr, target_sr)
    assert len(out) == int(round(len(signal) * target_sr / orig_sr))


def test_resample_is_a_noop_in_length_when_rates_match():
    signal = np.random.default_rng(0).standard_normal(4800).astype(np.float32)
    out = _resample(signal, 48000, 48000)
    assert len(out) == len(signal)


def test_embed_file_raises_clear_error_without_deps_installed(tmp_path):
    try:
        import torch  # noqa: F401
        from transformers import ClapModel  # noqa: F401

        pytest.skip("torch/transformers are installed in this environment; not testing the absent-dependency path")
    except ImportError:
        pass

    fake_audio = tmp_path / "sample.wav"
    fake_audio.write_bytes(b"\x00" * 100)
    embedder = ClapEmbedder()
    with pytest.raises(ClapNotInstalled, match="ml"):
        embedder.embed_file(fake_audio)
