def test_register_creates_user_and_returns_token(app_client):
    resp = app_client.post(
        "/api/v1/auth/register", json={"email": "new@example.com", "password": "correct-horse-battery"}
    )
    assert resp.status_code == 201, resp.text
    body = resp.json()
    assert body["user"]["email"] == "new@example.com"
    assert body["user"]["subscription_status"] == "inactive"
    assert body["user"]["has_active_subscription"] is False
    assert body["access_token"]


def test_register_rejects_duplicate_email(app_client):
    payload = {"email": "dup@example.com", "password": "correct-horse-battery"}
    first = app_client.post("/api/v1/auth/register", json=payload)
    assert first.status_code == 201
    second = app_client.post("/api/v1/auth/register", json=payload)
    assert second.status_code == 409


def test_register_rejects_short_password(app_client):
    resp = app_client.post("/api/v1/auth/register", json={"email": "short@example.com", "password": "abc"})
    assert resp.status_code == 422


def test_login_with_correct_credentials(app_client):
    app_client.post("/api/v1/auth/register", json={"email": "login@example.com", "password": "correct-horse-battery"})
    resp = app_client.post("/api/v1/auth/login", json={"email": "login@example.com", "password": "correct-horse-battery"})
    assert resp.status_code == 200
    assert resp.json()["access_token"]


def test_login_with_wrong_password(app_client):
    app_client.post("/api/v1/auth/register", json={"email": "login2@example.com", "password": "correct-horse-battery"})
    resp = app_client.post("/api/v1/auth/login", json={"email": "login2@example.com", "password": "wrong-password"})
    assert resp.status_code == 401


def test_login_with_unknown_email(app_client):
    resp = app_client.post("/api/v1/auth/login", json={"email": "nobody@example.com", "password": "whatever123"})
    assert resp.status_code == 401


def test_me_requires_token(app_client):
    resp = app_client.get("/api/v1/auth/me")
    assert resp.status_code == 401


def test_me_returns_current_user(app_client, registered_user):
    token, user_json = registered_user
    resp = app_client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert resp.status_code == 200
    assert resp.json()["id"] == user_json["id"]


def test_me_rejects_garbage_token(app_client):
    resp = app_client.get("/api/v1/auth/me", headers={"Authorization": "Bearer not-a-real-token"})
    assert resp.status_code == 401


def test_delete_account_erases_user(app_client, registered_user):
    token, user_json = registered_user
    headers = {"Authorization": f"Bearer {token}"}
    delete_resp = app_client.delete("/api/v1/auth/me", headers=headers)
    assert delete_resp.status_code == 204

    # token now refers to a user that no longer exists
    me_resp = app_client.get("/api/v1/auth/me", headers=headers)
    assert me_resp.status_code == 401
