import pytest

torch = pytest.importorskip("torch")

from alzheimers_detection.ml.model import FusionClassifier, build_model  # noqa: E402


def test_forward_pass_shape_matches_num_classes():
    model = build_model(input_dim=600, num_classes=2)
    x = torch.randn(4, 600)
    out = model(x)
    assert out.shape == (4, 2)


def test_forward_pass_with_egemaps_only_input_dim():
    model = build_model(input_dim=88, num_classes=2)
    x = torch.randn(3, 88)
    out = model(x)
    assert out.shape == (3, 2)


def test_model_is_trainable_single_step_reduces_loss_on_trivial_data():
    # Not a real training guarantee -- just confirms gradients flow and a
    # single optimizer step doesn't error out or leave loss unchanged on
    # an easily-separable toy problem.
    torch.manual_seed(0)
    model = FusionClassifier(input_dim=4, hidden_dims=(8,), num_classes=2)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.05)
    criterion = torch.nn.CrossEntropyLoss()

    x = torch.cat([torch.randn(20, 4) - 2, torch.randn(20, 4) + 2])
    y = torch.cat([torch.zeros(20, dtype=torch.long), torch.ones(20, dtype=torch.long)])

    model.train()
    first_loss = None
    last_loss = None
    for _ in range(30):
        optimizer.zero_grad()
        logits = model(x)
        loss = criterion(logits, y)
        loss.backward()
        optimizer.step()
        if first_loss is None:
            first_loss = loss.item()
        last_loss = loss.item()

    assert last_loss < first_loss


def test_batchnorm_requires_batch_size_greater_than_one_in_train_mode():
    # Documents a real PyTorch BatchNorm1d constraint that ml/train.py's
    # DataLoader batch_size needs to respect: a batch of size 1 in
    # training mode raises, because batch statistics are undefined for
    # a single sample. Eval mode (used for validation) doesn't have this
    # restriction since it uses running statistics instead.
    model = FusionClassifier(input_dim=4, hidden_dims=(8,))
    model.train()
    with pytest.raises(ValueError):
        model(torch.randn(1, 4))

    model.eval()
    out = model(torch.randn(1, 4))  # fine in eval mode
    assert out.shape == (1, 2)
