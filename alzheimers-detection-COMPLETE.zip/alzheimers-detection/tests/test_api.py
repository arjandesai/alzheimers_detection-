"""API-level tests for meta endpoints and the now-gated speech endpoint."""


def test_health_check(app_client):
    resp = app_client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_root_includes_disclaimer(app_client):
    resp = app_client.get("/")
    assert resp.status_code == 200
    assert "not" in resp.json()["disclaimer"].lower()


def test_analyze_speech_requires_auth(app_client, tiny_wav_bytes):
    resp = app_client.post(
        "/api/v1/speech/analyze",
        files={"file": ("clip.wav", tiny_wav_bytes, "audio/wav")},
    )
    assert resp.status_code == 401


def test_analyze_speech_requires_subscription(app_client, registered_user, tiny_wav_bytes):
    token, _ = registered_user
    resp = app_client.post(
        "/api/v1/speech/analyze",
        files={"file": ("clip.wav", tiny_wav_bytes, "audio/wav")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 402


def test_analyze_speech_success_when_subscribed(app_client, subscribed_user, tiny_wav_bytes):
    token, _ = subscribed_user
    resp = app_client.post(
        "/api/v1/speech/analyze",
        files={"file": ("clip.wav", tiny_wav_bytes, "audio/wav")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert "disclaimer" in body
    assert "risk_band" in body
    assert body["transcript"]["asr_backend"] == "fake"


def test_analyze_speech_rejects_empty_file(app_client, subscribed_user):
    token, _ = subscribed_user
    resp = app_client.post(
        "/api/v1/speech/analyze",
        files={"file": ("empty.wav", b"", "audio/wav")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 400


def test_analyze_speech_rejects_unsupported_content_type(app_client, subscribed_user, tiny_wav_bytes):
    token, _ = subscribed_user
    resp = app_client.post(
        "/api/v1/speech/analyze",
        files={"file": ("clip.txt", tiny_wav_bytes, "text/plain")},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 415


def test_analyze_speech_persists_and_is_retrievable(app_client, subscribed_user, tiny_wav_bytes):
    token, _ = subscribed_user
    headers = {"Authorization": f"Bearer {token}"}
    create_resp = app_client.post(
        "/api/v1/speech/analyze",
        files={"file": ("clip.wav", tiny_wav_bytes, "audio/wav")},
        headers=headers,
    )
    assert create_resp.status_code == 200

    # The analyze endpoint itself doesn't return the record id in this
    # milestone's response shape, so fetch it back via the DB in the audit
    # trail instead -- covered directly in test_persistence.py. Here we
    # just confirm the unauthenticated/unsubscribed paths stay blocked
    # even after a successful analysis by this same user's token has been
    # issued (i.e. the token doesn't grant more than it should).
    other_client_resp = app_client.get("/api/v1/uploads")
    assert other_client_resp.status_code == 401
