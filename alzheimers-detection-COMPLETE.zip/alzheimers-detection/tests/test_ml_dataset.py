import csv

import pytest

from alzheimers_detection.ml.dataset import (
    ManifestError,
    load_manifest,
    participant_level_split,
)


def _write_manifest(tmp_path, rows):
    path = tmp_path / "manifest.csv"
    with path.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["participant_id", "file_path", "label"])
        writer.writerows(rows)
    return path


def test_load_manifest_missing_file_raises(tmp_path):
    with pytest.raises(ManifestError):
        load_manifest(tmp_path / "does_not_exist.csv")


def test_load_manifest_parses_rows(tmp_path):
    (tmp_path / "S001.wav").touch()
    (tmp_path / "S002.wav").touch()
    path = _write_manifest(tmp_path, [["S001", "S001.wav", "0"], ["S002", "S002.wav", "1"]])
    rows = load_manifest(path)
    assert len(rows) == 2
    assert rows[0].participant_id == "S001"
    assert rows[0].label == 0
    assert rows[1].label == 1
    # relative paths resolve against the manifest's own directory
    assert rows[0].file_path == tmp_path / "S001.wav"


def test_load_manifest_rejects_bad_label(tmp_path):
    path = _write_manifest(tmp_path, [["S001", "S001.wav", "2"]])
    with pytest.raises(ManifestError):
        load_manifest(path)


def test_load_manifest_rejects_non_integer_label(tmp_path):
    path = _write_manifest(tmp_path, [["S001", "S001.wav", "AD"]])
    with pytest.raises(ManifestError):
        load_manifest(path)


def test_load_manifest_rejects_missing_columns(tmp_path):
    path = tmp_path / "bad.csv"
    path.write_text("id,path\nS001,foo.wav\n")
    with pytest.raises(ManifestError):
        load_manifest(path)


def test_load_manifest_rejects_empty_file(tmp_path):
    path = tmp_path / "empty.csv"
    path.write_text("participant_id,file_path,label\n")
    with pytest.raises(ManifestError):
        load_manifest(path)


def _fake_rows(n_control, n_ad, tmp_path):
    rows = []
    for i in range(n_control):
        rows.append([f"C{i:03d}", f"C{i:03d}.wav", "0"])
    for i in range(n_ad):
        rows.append([f"A{i:03d}", f"A{i:03d}.wav", "1"])
    path = _write_manifest(tmp_path, rows)
    return load_manifest(path)


def test_participant_level_split_is_stratified(tmp_path):
    rows = _fake_rows(n_control=20, n_ad=20, tmp_path=tmp_path)
    train, val = participant_level_split(rows, val_fraction=0.2, seed=0)

    train_labels = [r.label for r in train]
    val_labels = [r.label for r in val]

    # Both classes present in both splits, and roughly balanced within each.
    assert 0 in train_labels and 1 in train_labels
    assert 0 in val_labels and 1 in val_labels
    assert val_labels.count(0) == val_labels.count(1)  # exactly balanced given equal group sizes


def test_participant_level_split_no_overlap(tmp_path):
    rows = _fake_rows(n_control=15, n_ad=10, tmp_path=tmp_path)
    train, val = participant_level_split(rows, val_fraction=0.25, seed=1)

    train_ids = {r.participant_id for r in train}
    val_ids = {r.participant_id for r in val}
    assert train_ids.isdisjoint(val_ids)
    assert train_ids | val_ids == {r.participant_id for r in rows}


def test_participant_level_split_covers_all_rows_when_multiple_per_participant(tmp_path):
    # Manifest with two recordings for the same participant -- the split
    # must keep both rows on the same side, never split a participant
    # across train and val.
    rows = [
        ["S001", "S001a.wav", "0"],
        ["S001", "S001b.wav", "0"],
        ["S002", "S002a.wav", "1"],
        ["S002", "S002b.wav", "1"],
    ]
    for fname in ["S001a.wav", "S001b.wav", "S002a.wav", "S002b.wav"]:
        (tmp_path / fname).touch()
    path = _write_manifest(tmp_path, rows)
    manifest_rows = load_manifest(path)

    train, val = participant_level_split(manifest_rows, val_fraction=0.5, seed=2)
    train_ids = {r.participant_id for r in train}
    val_ids = {r.participant_id for r in val}
    # Neither participant appears on both sides.
    assert train_ids.isdisjoint(val_ids)
