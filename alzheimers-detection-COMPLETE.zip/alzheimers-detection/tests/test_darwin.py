"""Tests for the DARWIN loader. Uses a tiny hand-written CSV fixture that
mimics the DARWIN structure (ID + feature columns + class), NOT the real
dataset (which isn't shipped). Verifies parsing, label mapping, leakage
guards, and the stratified split.
"""

import numpy as np
import pytest

from alzheimers_detection.handwriting.darwin_dataset import (
    DarwinLoadError,
    load_darwin_csv,
    stratified_participant_split,
)


def _write_darwin(tmp_path, n_patient=6, n_healthy=6, n_features=4):
    header = ["ID"] + [f"feat{i}" for i in range(n_features)] + ["class"]
    lines = [",".join(header)]
    rng = np.random.default_rng(0)
    idx = 1
    for _ in range(n_patient):
        feats = rng.normal(2, 1, n_features)
        lines.append(",".join([f"id_{idx}"] + [f"{v:.3f}" for v in feats] + ["P"]))
        idx += 1
    for _ in range(n_healthy):
        feats = rng.normal(-2, 1, n_features)
        lines.append(",".join([f"id_{idx}"] + [f"{v:.3f}" for v in feats] + ["H"]))
        idx += 1
    path = tmp_path / "DARWIN.csv"
    path.write_text("\n".join(lines) + "\n")
    return path


def test_load_missing_file_raises(tmp_path):
    with pytest.raises(DarwinLoadError):
        load_darwin_csv(tmp_path / "nope.csv")


def test_load_parses_features_and_labels(tmp_path):
    path = _write_darwin(tmp_path, n_patient=6, n_healthy=6, n_features=4)
    data = load_darwin_csv(path)
    assert data.X.shape == (12, 4)
    assert data.y.sum() == 6  # 6 patients labeled 1
    assert (data.y == 0).sum() == 6
    assert "ID" not in data.feature_names
    assert "class" not in data.feature_names
    assert len(data.participant_ids) == 12


def test_label_mapping_patient_is_one(tmp_path):
    path = _write_darwin(tmp_path, n_patient=3, n_healthy=3)
    data = load_darwin_csv(path)
    # first 3 rows are patients -> label 1
    assert data.y[0] == 1
    assert data.y[-1] == 0


def test_bad_class_value_raises(tmp_path):
    path = tmp_path / "DARWIN.csv"
    path.write_text("ID,feat0,class\nid_1,1.0,X\n")
    with pytest.raises(DarwinLoadError):
        load_darwin_csv(path)


def test_wrong_header_raises(tmp_path):
    path = tmp_path / "DARWIN.csv"
    path.write_text("wrong,feat0,label\nid_1,1.0,P\n")
    with pytest.raises(DarwinLoadError):
        load_darwin_csv(path)


def test_duplicate_ids_raise(tmp_path):
    path = tmp_path / "DARWIN.csv"
    path.write_text("ID,feat0,class\nid_1,1.0,P\nid_1,2.0,H\n")
    with pytest.raises(DarwinLoadError):
        load_darwin_csv(path)


def test_non_numeric_feature_raises(tmp_path):
    path = tmp_path / "DARWIN.csv"
    path.write_text("ID,feat0,class\nid_1,notanumber,P\n")
    with pytest.raises(DarwinLoadError):
        load_darwin_csv(path)


def test_stratified_split_preserves_class_balance(tmp_path):
    path = _write_darwin(tmp_path, n_patient=20, n_healthy=20)
    data = load_darwin_csv(path)
    train_idx, test_idx = stratified_participant_split(data, test_fraction=0.25, seed=1)

    assert len(set(train_idx.tolist()) & set(test_idx.tolist())) == 0  # no overlap
    assert len(train_idx) + len(test_idx) == 40
    # both classes present in test
    test_labels = data.y[test_idx]
    assert (test_labels == 0).any() and (test_labels == 1).any()


def test_split_is_deterministic_with_seed(tmp_path):
    path = _write_darwin(tmp_path, n_patient=15, n_healthy=15)
    data = load_darwin_csv(path)
    a1, b1 = stratified_participant_split(data, seed=42)
    a2, b2 = stratified_participant_split(data, seed=42)
    assert np.array_equal(a1, a2) and np.array_equal(b1, b2)
