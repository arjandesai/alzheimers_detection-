import numpy as np
import pytest

torch = pytest.importorskip("torch")

from alzheimers_detection.ml.train import _compute_metrics, _standardize, run_epoch  # noqa: E402
from alzheimers_detection.ml.model import build_model  # noqa: E402


def test_standardize_train_stats_applied_to_val():
    train_X = np.array([[0.0, 10.0], [2.0, 20.0], [4.0, 30.0]])
    val_X = np.array([[2.0, 20.0]])
    train_scaled, val_scaled, mean, std = _standardize(train_X, val_X)

    assert np.allclose(train_scaled.mean(axis=0), 0.0, atol=1e-6)
    # val_X's single row equals the train mean, so after scaling with
    # train statistics it should land at (approximately) zero too.
    assert np.allclose(val_scaled, 0.0, atol=1e-6)
    assert np.allclose(mean, [2.0, 20.0])


def test_standardize_handles_zero_variance_column():
    train_X = np.array([[5.0, 1.0], [5.0, 2.0], [5.0, 3.0]])  # first column constant
    val_X = np.array([[5.0, 4.0]])
    train_scaled, val_scaled, mean, std = _standardize(train_X, val_X)
    assert not np.isnan(train_scaled).any()
    assert not np.isnan(val_scaled).any()
    assert std[0] == 1.0  # guarded against divide-by-zero, not left at 0


def test_compute_metrics_perfect_predictions():
    labels = [0, 0, 1, 1]
    preds = [0, 0, 1, 1]
    probs = [0.1, 0.2, 0.8, 0.9]
    m = _compute_metrics(avg_loss=0.05, labels=labels, preds=preds, probs=probs)
    assert m["accuracy"] == 1.0
    assert m["f1"] == 1.0
    assert m["auc"] == 1.0


def test_compute_metrics_all_wrong():
    labels = [0, 0, 1, 1]
    preds = [1, 1, 0, 0]
    probs = [0.9, 0.9, 0.1, 0.1]
    m = _compute_metrics(avg_loss=1.0, labels=labels, preds=preds, probs=probs)
    assert m["accuracy"] == 0.0
    assert m["auc"] == 0.0


def test_compute_metrics_single_class_auc_is_nan_not_error():
    labels = [0, 0, 0]
    preds = [0, 0, 0]
    probs = [0.1, 0.2, 0.15]
    m = _compute_metrics(avg_loss=0.1, labels=labels, preds=preds, probs=probs)
    assert np.isnan(m["auc"])
    assert m["accuracy"] == 1.0  # accuracy is still well-defined even though AUC isn't


def test_run_epoch_eval_mode_does_not_update_weights():
    from torch.utils.data import DataLoader, TensorDataset

    torch.manual_seed(0)
    model = build_model(input_dim=4, num_classes=2)
    x = torch.randn(8, 4)
    y = torch.randint(0, 2, (8,))
    loader = DataLoader(TensorDataset(x, y), batch_size=4)
    criterion = torch.nn.CrossEntropyLoss()

    before = [p.clone() for p in model.parameters()]
    run_epoch(model, loader, criterion, optimizer=None, device="cpu", training=False)
    after = list(model.parameters())

    for b, a in zip(before, after):
        assert torch.allclose(b, a), "eval-mode run_epoch must not modify model weights"


def test_run_epoch_train_mode_updates_weights():
    from torch.utils.data import DataLoader, TensorDataset

    torch.manual_seed(0)
    model = build_model(input_dim=4, num_classes=2)
    x = torch.randn(8, 4)
    y = torch.randint(0, 2, (8,))
    loader = DataLoader(TensorDataset(x, y), batch_size=4, drop_last=True)
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    before = [p.clone() for p in model.parameters()]
    run_epoch(model, loader, criterion, optimizer=optimizer, device="cpu", training=True)
    after = list(model.parameters())

    changed = any(not torch.allclose(b, a) for b, a in zip(before, after))
    assert changed, "train-mode run_epoch should update at least some weights"


def test_20_epoch_synthetic_run_converges_on_trivially_separable_data(tmp_path):
    """Full miniature version of ml/train.py's training loop (bypassing
    file-based feature caching -- this constructs tensors directly) on a
    synthetic, trivially linearly-separable dataset, run for exactly 20
    epochs. This proves the training mechanics (loop, optimizer step,
    metric computation) are correct; it says nothing about real-world
    AD/control classification performance, which needs real data (see
    docs/TRAINING.md).
    """
    from torch.utils.data import DataLoader, TensorDataset

    torch.manual_seed(0)
    rng = np.random.default_rng(0)
    n_per_class = 40
    X = np.concatenate(
        [rng.normal(loc=-3, scale=0.5, size=(n_per_class, 6)), rng.normal(loc=3, scale=0.5, size=(n_per_class, 6))]
    ).astype(np.float32)
    y = np.array([0] * n_per_class + [1] * n_per_class, dtype=np.int64)

    perm = rng.permutation(len(X))
    X, y = X[perm], y[perm]
    split = int(0.8 * len(X))
    train_X, val_X = X[:split], X[split:]
    train_y, val_y = y[:split], y[split:]

    model = build_model(input_dim=6, num_classes=2)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    criterion = torch.nn.CrossEntropyLoss()
    train_loader = DataLoader(TensorDataset(torch.from_numpy(train_X), torch.from_numpy(train_y)), batch_size=8, drop_last=True)
    val_loader = DataLoader(TensorDataset(torch.from_numpy(val_X), torch.from_numpy(val_y)), batch_size=8)

    val_accuracies = []
    for _epoch in range(20):
        run_epoch(model, train_loader, criterion, optimizer, "cpu", training=True)
        val_metrics = run_epoch(model, val_loader, criterion, optimizer=None, device="cpu", training=False)
        val_accuracies.append(val_metrics["accuracy"])

    assert len(val_accuracies) == 20
    # On data this cleanly separable, accuracy should end high -- this is
    # a sanity check on the mechanics, not a claim about ADReSS-scale
    # real-world performance.
    assert val_accuracies[-1] >= 0.85
